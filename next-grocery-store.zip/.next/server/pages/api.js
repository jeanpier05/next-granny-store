module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/pages/api/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/data.js":
/*!*********************!*\
  !*** ./src/data.js ***!
  \*********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ([{
  id: "1",
  title: "Apples x lb",
  price: 2.1,
  offerPrice: null,
  stock: 12,
  img: "apples.jpg",
  category: "fruits"
}, {
  id: "2",
  title: "bliquam feugiat dui non",
  price: 4.88,
  offerPrice: 3.88,
  stock: 12,
  img: "baby.jpg",
  category: "vegetable"
}, {
  id: "3",
  title: "abciquam feugiat beans",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "beans.jpg",
  category: "vegetable"
}, {
  id: "4",
  title: "Lorem am beans dui non",
  price: 1.88,
  offerPrice: null,
  stock: 12,
  img: "beans2.jpg",
  category: "vegetable"
}, {
  id: "5",
  title: "Berry es feugiat mollis",
  price: 2.3,
  offerPrice: null,
  stock: 12,
  img: "berry.jpg",
  category: "fruits"
}, {
  id: "6",
  title: "berry feugiat dui non mollis",
  price: 2.22,
  offerPrice: null,
  stock: 12,
  img: "berry2.jpg",
  category: "fruits"
}, {
  id: "7",
  title: "brussels feugiat dui non mollis",
  price: 2.88,
  offerPrice: null,
  stock: 12,
  img: "brussels.jpg",
  category: "vegetable"
}, {
  id: "8",
  title: "carrot feugiat dui non mollis",
  price: 3.88,
  offerPrice: null,
  stock: 12,
  img: "carrot.jpg",
  category: "vegetable"
}, {
  id: "9",
  title: "celery feugiat dui non mollis",
  price: 5.88,
  offerPrice: null,
  stock: 12,
  img: "celery.jpg",
  category: "vegetable"
}, {
  id: "11",
  title: "cherry feugiat dui non mollis",
  price: 7.88,
  offerPrice: 6.88,
  stock: 12,
  img: "cherry.jpg",
  category: "fruits"
}, {
  id: "22",
  title: "chicken feugiat dui non mollis",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "chicken.jpg",
  category: "meat"
}, {
  id: "33",
  title: "Aliquam feugiat non chicken",
  price: 8.88,
  offerPrice: null,
  stock: 12,
  img: "chicken2.jpg",
  category: "meat"
}, {
  id: "44",
  title: "clemen feugiat dui",
  price: 4.99,
  offerPrice: null,
  stock: 12,
  img: "clemen.jpg",
  category: "fruits"
}, {
  id: "55",
  title: "cod feugiat dui non",
  price: 9.88,
  offerPrice: null,
  stock: 12,
  img: "cod.jpg",
  category: "meat"
}, {
  id: "66",
  title: "corn feugiat non mollis",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "corn.jpg",
  category: "vegetable"
}, {
  id: "77",
  title: "cucumber feugiat dui non",
  price: 4.88,
  offerPrice: 2.5,
  stock: 12,
  img: "cucumber.jpg",
  category: "vegetable"
}, {
  id: "88",
  title: "dates feugiat non duilis",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "dates.jpg",
  category: "fruits"
}, {
  id: "99",
  title: "fresh fish feugiat dui",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "fish.jpg",
  category: "meat"
}, {
  id: "00",
  title: "fish lorem ipsum",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "fish2.jpg",
  category: "meat"
}, {
  id: "111",
  title: "fish non mollis feugiat dui",
  price: 4.88,
  offerPrice: 3.25,
  stock: 12,
  img: "fish3.jpg",
  category: "meat"
}, {
  id: "222",
  title: "lemon non mollis",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "lemon.jpg",
  category: "fuits"
}, {
  id: "333",
  title: "Aliquam lime dui non mollis",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "lime.jpg",
  category: "fruits"
}, {
  id: "444",
  title: "Aliquam mango dui non",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "mango.jpg",
  category: "fruits"
}, {
  id: "555",
  title: "Aliquam meat dui non mollis",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "meat.jpg",
  category: "meat"
}, {
  id: "666",
  title: "meat feugiat dui non mollis",
  price: 4.88,
  offerPrice: 4.0,
  stock: 12,
  img: "meat2.jpg",
  category: "meat"
}, {
  id: "777",
  title: "Aliquam feugiat dui non meat",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "meat3.jpg",
  category: "meat"
}, {
  id: "888",
  title: "mix vegetables feugiat dui non mollis",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "mix.jpg",
  category: "vegetable"
}, {
  id: "999",
  title: "pears feugiat dui non mollis",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "pears.jpg",
  category: "fruits"
}, {
  id: "000",
  title: "Aliquam pepper dui non mollis",
  price: 4.88,
  offerPrice: 3.99,
  stock: 12,
  img: "pepper.jpg",
  category: "vegetable"
}, {
  id: "1111",
  title: "Aliquam salmon dui non mollis",
  price: 4.88,
  offerPrice: null,
  stock: 12,
  img: "salmon.jpg",
  category: "meat"
}, {
  id: "bread1",
  title: "Sprouts Classic Seedsational Bread 14 oz",
  price: 2.25,
  offerPrice: null,
  stock: 12,
  img: "bread.jpg",
  category: "bakery"
}, {
  id: "bread2",
  title: "Traditional Corn Special Bread",
  price: 1.75,
  offerPrice: null,
  stock: 12,
  img: "bread2.jpg",
  category: "bakery"
}, {
  id: "bread3",
  title: "Sprouts Classic Seedsational Bread",
  price: 2.25,
  offerPrice: null,
  stock: 12,
  img: "bread3.jpg",
  category: "bakery"
}, {
  id: "toast",
  title: "Oven Baked Garlic & Cheese Toast",
  price: 1.7,
  offerPrice: null,
  stock: 12,
  img: "toast.jpg",
  category: "bakery"
}, {
  id: "toast2",
  title: "Oven Baked Italian Herb with Olive Oil Toast",
  price: 2.25,
  offerPrice: null,
  stock: 12,
  img: "toast2.jpg",
  category: "bakery"
}, {
  id: "cookies",
  title: "Raspberry Crumble Cookies",
  price: 2.25,
  offerPrice: null,
  stock: 12,
  img: "cookies.jpg",
  category: "bakery"
}, {
  id: "cookies2",
  title: "Chocolate Chip Cookies",
  price: 3.0,
  offerPrice: null,
  stock: 12,
  img: "cookies2.jpg",
  category: "bakery"
}, {
  id: "cookies3",
  title: "Freshly Baked Chocolate Chip Cookie",
  price: 2.5,
  offerPrice: null,
  stock: 12,
  img: "cookies3.jpg",
  category: "bakery"
}, {
  id: "muffin",
  title: "Thomas Cinnamon Raisin English Muffins",
  price: 2.25,
  offerPrice: null,
  stock: 12,
  img: "muffin.jpg",
  category: "bakery"
}, {
  id: "muffin2",
  title: "Mini Zucchini & Carrot Muffin",
  price: 2.25,
  offerPrice: null,
  stock: 12,
  img: "muffin2.jpg",
  category: "bakery"
}, {
  id: "muffin3",
  title: "Double Chocolate Oat Muffin ",
  price: 2.25,
  offerPrice: null,
  stock: 12,
  img: "muffin3.jpg",
  category: "bakery"
}, {
  id: "tea",
  title: "Freshly Brewed Organic Green Tea",
  price: 0.75,
  offerPrice: null,
  stock: 12,
  img: "tea.jpg",
  category: "drink"
}, {
  id: "coffe",
  title: "Fresh Grinded Frappé coffee",
  price: 1.5,
  offerPrice: null,
  stock: 12,
  img: "coffe.jpg",
  category: "drink"
}, {
  id: "coffe2",
  title: "Caffee Nero Mocha Late",
  price: 1.8,
  offerPrice: null,
  stock: 12,
  img: "coffe2.jpg",
  category: "drink"
}, {
  id: "coffe3",
  title: "Nescafe Clasico Instant Coffee",
  price: 2.2,
  offerPrice: null,
  stock: 12,
  img: "coffe3.jpg",
  category: "drink"
}, {
  id: "coffe4",
  title: "Peet Coffee Decaf Major Dickason Blend",
  price: 2.4,
  offerPrice: 2.1,
  stock: 12,
  img: "coffe4.jpg",
  category: "drink"
}]);

/***/ }),

/***/ "./src/pages/api/index.js":
/*!********************************!*\
  !*** ./src/pages/api/index.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../data */ "./src/data.js");


const handleSort = (items, sortMode) => {
  switch (sortMode) {
    case "Ascending":
      return items.sort((a, b) => a.title - b.title);

    case "Descending":
      return items.sort((a, b) => b.title - a.title);

    case "Min Price":
      return items.sort((a, b) => a.price - b.price);

    case "Max Price":
      return items.sort((a, b) => b.price - a.price);

    default:
      return items;
  }
};

/* harmony default export */ __webpack_exports__["default"] = (async (req, res) => {
  const cat = req.query.category;
  const sort = req.query.sort;
  const search = req.query.search; //use settimeout for apreciate card loaders

  setTimeout(() => {
    if (!cat || !sort) return res.json(_data__WEBPACK_IMPORTED_MODULE_0__["default"]);
    let items;

    if (cat !== "all") {
      items = _data__WEBPACK_IMPORTED_MODULE_0__["default"].filter(i => i.category === cat);
    } else {
      items = _data__WEBPACK_IMPORTED_MODULE_0__["default"];
    }

    if (typeof search === "string") {
      const searchQuery = search.toLocaleLowerCase();
      items = items.filter(i => {
        const title = i.title.toLocaleLowerCase();
        return title.includes(searchQuery);
      });
    }

    const sortedtItems = handleSort(items, sort);
    return res.json(sortedtItems);
  }, 800);
});

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2RhdGEuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BhZ2VzL2FwaS9pbmRleC5qcyJdLCJuYW1lcyI6WyJpZCIsInRpdGxlIiwicHJpY2UiLCJvZmZlclByaWNlIiwic3RvY2siLCJpbWciLCJjYXRlZ29yeSIsImhhbmRsZVNvcnQiLCJpdGVtcyIsInNvcnRNb2RlIiwic29ydCIsImEiLCJiIiwicmVxIiwicmVzIiwiY2F0IiwicXVlcnkiLCJzZWFyY2giLCJzZXRUaW1lb3V0IiwianNvbiIsImRhdGEiLCJmaWx0ZXIiLCJpIiwic2VhcmNoUXVlcnkiLCJ0b0xvY2FsZUxvd2VyQ2FzZSIsImluY2x1ZGVzIiwic29ydGVkdEl0ZW1zIl0sIm1hcHBpbmdzIjoiOztRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSTtRQUNKO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7O0FDeEZBO0FBQWUsZ0VBQ2I7QUFDRUEsSUFBRSxFQUFFLEdBRE47QUFFRUMsT0FBSyxFQUFFLGFBRlQ7QUFHRUMsT0FBSyxFQUFFLEdBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLFlBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0FEYSxFQVViO0FBQ0VOLElBQUUsRUFBRSxHQUROO0FBRUVDLE9BQUssRUFBRSx5QkFGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsVUFOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQVZhLEVBbUJiO0FBQ0VOLElBQUUsRUFBRSxHQUROO0FBRUVDLE9BQUssRUFBRSx3QkFGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsV0FOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQW5CYSxFQTRCYjtBQUNFTixJQUFFLEVBQUUsR0FETjtBQUVFQyxPQUFLLEVBQUUsd0JBRlQ7QUFHRUMsT0FBSyxFQUFFLElBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLFlBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0E1QmEsRUFxQ2I7QUFDRU4sSUFBRSxFQUFFLEdBRE47QUFFRUMsT0FBSyxFQUFFLHlCQUZUO0FBR0VDLE9BQUssRUFBRSxHQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxXQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBckNhLEVBOENiO0FBQ0VOLElBQUUsRUFBRSxHQUROO0FBRUVDLE9BQUssRUFBRSw4QkFGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsWUFOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQTlDYSxFQXVEYjtBQUNFTixJQUFFLEVBQUUsR0FETjtBQUVFQyxPQUFLLEVBQUUsaUNBRlQ7QUFHRUMsT0FBSyxFQUFFLElBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLGNBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0F2RGEsRUFnRWI7QUFDRU4sSUFBRSxFQUFFLEdBRE47QUFFRUMsT0FBSyxFQUFFLCtCQUZUO0FBR0VDLE9BQUssRUFBRSxJQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxZQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBaEVhLEVBeUViO0FBQ0VOLElBQUUsRUFBRSxHQUROO0FBRUVDLE9BQUssRUFBRSwrQkFGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsWUFOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQXpFYSxFQWtGYjtBQUNFTixJQUFFLEVBQUUsSUFETjtBQUVFQyxPQUFLLEVBQUUsK0JBRlQ7QUFHRUMsT0FBSyxFQUFFLElBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLFlBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0FsRmEsRUEyRmI7QUFDRU4sSUFBRSxFQUFFLElBRE47QUFFRUMsT0FBSyxFQUFFLGdDQUZUO0FBR0VDLE9BQUssRUFBRSxJQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxhQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBM0ZhLEVBb0diO0FBQ0VOLElBQUUsRUFBRSxJQUROO0FBRUVDLE9BQUssRUFBRSw2QkFGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsY0FOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQXBHYSxFQTZHYjtBQUNFTixJQUFFLEVBQUUsSUFETjtBQUVFQyxPQUFLLEVBQUUsb0JBRlQ7QUFHRUMsT0FBSyxFQUFFLElBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLFlBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0E3R2EsRUFzSGI7QUFDRU4sSUFBRSxFQUFFLElBRE47QUFFRUMsT0FBSyxFQUFFLHFCQUZUO0FBR0VDLE9BQUssRUFBRSxJQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxTQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBdEhhLEVBK0hiO0FBQ0VOLElBQUUsRUFBRSxJQUROO0FBRUVDLE9BQUssRUFBRSx5QkFGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsVUFOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQS9IYSxFQXdJYjtBQUNFTixJQUFFLEVBQUUsSUFETjtBQUVFQyxPQUFLLEVBQUUsMEJBRlQ7QUFHRUMsT0FBSyxFQUFFLElBSFQ7QUFJRUMsWUFBVSxFQUFFLEdBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLGNBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0F4SWEsRUFpSmI7QUFDRU4sSUFBRSxFQUFFLElBRE47QUFFRUMsT0FBSyxFQUFFLDBCQUZUO0FBR0VDLE9BQUssRUFBRSxJQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxXQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBakphLEVBMEpiO0FBQ0VOLElBQUUsRUFBRSxJQUROO0FBRUVDLE9BQUssRUFBRSx3QkFGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsVUFOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQTFKYSxFQW1LYjtBQUNFTixJQUFFLEVBQUUsSUFETjtBQUVFQyxPQUFLLEVBQUUsa0JBRlQ7QUFHRUMsT0FBSyxFQUFFLElBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLFdBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0FuS2EsRUE0S2I7QUFDRU4sSUFBRSxFQUFFLEtBRE47QUFFRUMsT0FBSyxFQUFFLDZCQUZUO0FBR0VDLE9BQUssRUFBRSxJQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxXQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBNUthLEVBcUxiO0FBQ0VOLElBQUUsRUFBRSxLQUROO0FBRUVDLE9BQUssRUFBRSxrQkFGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsV0FOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQXJMYSxFQThMYjtBQUNFTixJQUFFLEVBQUUsS0FETjtBQUVFQyxPQUFLLEVBQUUsNkJBRlQ7QUFHRUMsT0FBSyxFQUFFLElBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLFVBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0E5TGEsRUF1TWI7QUFDRU4sSUFBRSxFQUFFLEtBRE47QUFFRUMsT0FBSyxFQUFFLHVCQUZUO0FBR0VDLE9BQUssRUFBRSxJQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxXQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBdk1hLEVBZ05iO0FBQ0VOLElBQUUsRUFBRSxLQUROO0FBRUVDLE9BQUssRUFBRSw2QkFGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsVUFOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQWhOYSxFQXlOYjtBQUNFTixJQUFFLEVBQUUsS0FETjtBQUVFQyxPQUFLLEVBQUUsNkJBRlQ7QUFHRUMsT0FBSyxFQUFFLElBSFQ7QUFJRUMsWUFBVSxFQUFFLEdBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLFdBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0F6TmEsRUFrT2I7QUFDRU4sSUFBRSxFQUFFLEtBRE47QUFFRUMsT0FBSyxFQUFFLDhCQUZUO0FBR0VDLE9BQUssRUFBRSxJQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxXQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBbE9hLEVBMk9iO0FBQ0VOLElBQUUsRUFBRSxLQUROO0FBRUVDLE9BQUssRUFBRSx1Q0FGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsU0FOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQTNPYSxFQW9QYjtBQUNFTixJQUFFLEVBQUUsS0FETjtBQUVFQyxPQUFLLEVBQUUsOEJBRlQ7QUFHRUMsT0FBSyxFQUFFLElBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLFdBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0FwUGEsRUE2UGI7QUFDRU4sSUFBRSxFQUFFLEtBRE47QUFFRUMsT0FBSyxFQUFFLCtCQUZUO0FBR0VDLE9BQUssRUFBRSxJQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxZQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBN1BhLEVBc1FiO0FBQ0VOLElBQUUsRUFBRSxNQUROO0FBRUVDLE9BQUssRUFBRSwrQkFGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsWUFOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQXRRYSxFQWdSYjtBQUNFTixJQUFFLEVBQUUsUUFETjtBQUVFQyxPQUFLLEVBQUUsMENBRlQ7QUFHRUMsT0FBSyxFQUFFLElBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLFdBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0FoUmEsRUF5UmI7QUFDRU4sSUFBRSxFQUFFLFFBRE47QUFFRUMsT0FBSyxFQUFFLGdDQUZUO0FBR0VDLE9BQUssRUFBRSxJQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxZQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBelJhLEVBa1NiO0FBQ0VOLElBQUUsRUFBRSxRQUROO0FBRUVDLE9BQUssRUFBRSxvQ0FGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsWUFOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQWxTYSxFQTJTYjtBQUNFTixJQUFFLEVBQUUsT0FETjtBQUVFQyxPQUFLLEVBQUUsa0NBRlQ7QUFHRUMsT0FBSyxFQUFFLEdBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLFdBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0EzU2EsRUFvVGI7QUFDRU4sSUFBRSxFQUFFLFFBRE47QUFFRUMsT0FBSyxFQUFFLDhDQUZUO0FBR0VDLE9BQUssRUFBRSxJQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxZQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBcFRhLEVBNlRiO0FBQ0VOLElBQUUsRUFBRSxTQUROO0FBRUVDLE9BQUssRUFBRSwyQkFGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsYUFOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQTdUYSxFQXNVYjtBQUNFTixJQUFFLEVBQUUsVUFETjtBQUVFQyxPQUFLLEVBQUUsd0JBRlQ7QUFHRUMsT0FBSyxFQUFFLEdBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLGNBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0F0VWEsRUErVWI7QUFDRU4sSUFBRSxFQUFFLFVBRE47QUFFRUMsT0FBSyxFQUFFLHFDQUZUO0FBR0VDLE9BQUssRUFBRSxHQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxjQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBL1VhLEVBd1ZiO0FBQ0VOLElBQUUsRUFBRSxRQUROO0FBRUVDLE9BQUssRUFBRSx3Q0FGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsWUFOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQXhWYSxFQWtXYjtBQUNFTixJQUFFLEVBQUUsU0FETjtBQUVFQyxPQUFLLEVBQUUsK0JBRlQ7QUFHRUMsT0FBSyxFQUFFLElBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLGFBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0FsV2EsRUE0V2I7QUFDRU4sSUFBRSxFQUFFLFNBRE47QUFFRUMsT0FBSyxFQUFFLDhCQUZUO0FBR0VDLE9BQUssRUFBRSxJQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxhQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBNVdhLEVBc1hiO0FBQ0VOLElBQUUsRUFBRSxLQUROO0FBRUVDLE9BQUssRUFBRSxrQ0FGVDtBQUdFQyxPQUFLLEVBQUUsSUFIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsU0FOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQXRYYSxFQWdZYjtBQUNFTixJQUFFLEVBQUUsT0FETjtBQUVFQyxPQUFLLEVBQUUsNkJBRlQ7QUFHRUMsT0FBSyxFQUFFLEdBSFQ7QUFJRUMsWUFBVSxFQUFFLElBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLFdBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0FoWWEsRUEwWWI7QUFDRU4sSUFBRSxFQUFFLFFBRE47QUFFRUMsT0FBSyxFQUFFLHdCQUZUO0FBR0VDLE9BQUssRUFBRSxHQUhUO0FBSUVDLFlBQVUsRUFBRSxJQUpkO0FBS0VDLE9BQUssRUFBRSxFQUxUO0FBTUVDLEtBQUcsRUFBRSxZQU5QO0FBT0VDLFVBQVEsRUFBRTtBQVBaLENBMVlhLEVBb1piO0FBQ0VOLElBQUUsRUFBRSxRQUROO0FBRUVDLE9BQUssRUFBRSxnQ0FGVDtBQUdFQyxPQUFLLEVBQUUsR0FIVDtBQUlFQyxZQUFVLEVBQUUsSUFKZDtBQUtFQyxPQUFLLEVBQUUsRUFMVDtBQU1FQyxLQUFHLEVBQUUsWUFOUDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQXBaYSxFQThaYjtBQUNFTixJQUFFLEVBQUUsUUFETjtBQUVFQyxPQUFLLEVBQUUsd0NBRlQ7QUFHRUMsT0FBSyxFQUFFLEdBSFQ7QUFJRUMsWUFBVSxFQUFFLEdBSmQ7QUFLRUMsT0FBSyxFQUFFLEVBTFQ7QUFNRUMsS0FBRyxFQUFFLFlBTlA7QUFPRUMsVUFBUSxFQUFFO0FBUFosQ0E5WmEsQ0FBZixFOzs7Ozs7Ozs7Ozs7QUNBQTtBQUFBO0FBQUE7O0FBRUEsTUFBTUMsVUFBVSxHQUFHLENBQUNDLEtBQUQsRUFBUUMsUUFBUixLQUFxQjtBQUN0QyxVQUFRQSxRQUFSO0FBQ0UsU0FBSyxXQUFMO0FBQ0UsYUFBT0QsS0FBSyxDQUFDRSxJQUFOLENBQVcsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLEtBQVVELENBQUMsQ0FBQ1YsS0FBRixHQUFVVyxDQUFDLENBQUNYLEtBQWpDLENBQVA7O0FBQ0YsU0FBSyxZQUFMO0FBQ0UsYUFBT08sS0FBSyxDQUFDRSxJQUFOLENBQVcsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLEtBQVVBLENBQUMsQ0FBQ1gsS0FBRixHQUFVVSxDQUFDLENBQUNWLEtBQWpDLENBQVA7O0FBQ0YsU0FBSyxXQUFMO0FBQ0UsYUFBT08sS0FBSyxDQUFDRSxJQUFOLENBQVcsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLEtBQVVELENBQUMsQ0FBQ1QsS0FBRixHQUFVVSxDQUFDLENBQUNWLEtBQWpDLENBQVA7O0FBQ0YsU0FBSyxXQUFMO0FBQ0UsYUFBT00sS0FBSyxDQUFDRSxJQUFOLENBQVcsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLEtBQVVBLENBQUMsQ0FBQ1YsS0FBRixHQUFVUyxDQUFDLENBQUNULEtBQWpDLENBQVA7O0FBQ0Y7QUFDRSxhQUFPTSxLQUFQO0FBVko7QUFZRCxDQWJEOztBQWVlLHNFQUFPSyxHQUFQLEVBQVlDLEdBQVosS0FBb0I7QUFDakMsUUFBTUMsR0FBRyxHQUFHRixHQUFHLENBQUNHLEtBQUosQ0FBVVYsUUFBdEI7QUFDQSxRQUFNSSxJQUFJLEdBQUdHLEdBQUcsQ0FBQ0csS0FBSixDQUFVTixJQUF2QjtBQUNBLFFBQU1PLE1BQU0sR0FBR0osR0FBRyxDQUFDRyxLQUFKLENBQVVDLE1BQXpCLENBSGlDLENBS2pDOztBQUNBQyxZQUFVLENBQUMsTUFBTTtBQUNmLFFBQUksQ0FBQ0gsR0FBRCxJQUFRLENBQUNMLElBQWIsRUFBbUIsT0FBT0ksR0FBRyxDQUFDSyxJQUFKLENBQVNDLDZDQUFULENBQVA7QUFFbkIsUUFBSVosS0FBSjs7QUFFQSxRQUFJTyxHQUFHLEtBQUssS0FBWixFQUFtQjtBQUNqQlAsV0FBSyxHQUFHWSw2Q0FBSSxDQUFDQyxNQUFMLENBQWFDLENBQUQsSUFBT0EsQ0FBQyxDQUFDaEIsUUFBRixLQUFlUyxHQUFsQyxDQUFSO0FBQ0QsS0FGRCxNQUVPO0FBQ0xQLFdBQUssR0FBR1ksNkNBQVI7QUFDRDs7QUFFRCxRQUFJLE9BQU9ILE1BQVAsS0FBa0IsUUFBdEIsRUFBZ0M7QUFDOUIsWUFBTU0sV0FBVyxHQUFHTixNQUFNLENBQUNPLGlCQUFQLEVBQXBCO0FBQ0FoQixXQUFLLEdBQUdBLEtBQUssQ0FBQ2EsTUFBTixDQUFjQyxDQUFELElBQU87QUFDMUIsY0FBTXJCLEtBQUssR0FBR3FCLENBQUMsQ0FBQ3JCLEtBQUYsQ0FBUXVCLGlCQUFSLEVBQWQ7QUFDQSxlQUFPdkIsS0FBSyxDQUFDd0IsUUFBTixDQUFlRixXQUFmLENBQVA7QUFDRCxPQUhPLENBQVI7QUFJRDs7QUFFRCxVQUFNRyxZQUFZLEdBQUduQixVQUFVLENBQUNDLEtBQUQsRUFBUUUsSUFBUixDQUEvQjtBQUVBLFdBQU9JLEdBQUcsQ0FBQ0ssSUFBSixDQUFTTyxZQUFULENBQVA7QUFDRCxHQXRCUyxFQXNCUCxHQXRCTyxDQUFWO0FBdUJELENBN0JELEUiLCJmaWxlIjoicGFnZXMvYXBpLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSByZXF1aXJlKCcuLi9zc3ItbW9kdWxlLWNhY2hlLmpzJyk7XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdHZhciB0aHJldyA9IHRydWU7XG4gXHRcdHRyeSB7XG4gXHRcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG4gXHRcdFx0dGhyZXcgPSBmYWxzZTtcbiBcdFx0fSBmaW5hbGx5IHtcbiBcdFx0XHRpZih0aHJldykgZGVsZXRlIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHR9XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi9zcmMvcGFnZXMvYXBpL2luZGV4LmpzXCIpO1xuIiwiZXhwb3J0IGRlZmF1bHQgW1xyXG4gIHtcclxuICAgIGlkOiBcIjFcIixcclxuICAgIHRpdGxlOiBcIkFwcGxlcyB4IGxiXCIsXHJcbiAgICBwcmljZTogMi4xLFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJhcHBsZXMuanBnXCIsXHJcbiAgICBjYXRlZ29yeTogXCJmcnVpdHNcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjJcIixcclxuICAgIHRpdGxlOiBcImJsaXF1YW0gZmV1Z2lhdCBkdWkgbm9uXCIsXHJcbiAgICBwcmljZTogNC44OCxcclxuICAgIG9mZmVyUHJpY2U6IDMuODgsXHJcbiAgICBzdG9jazogMTIsXHJcbiAgICBpbWc6IFwiYmFieS5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcInZlZ2V0YWJsZVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiM1wiLFxyXG4gICAgdGl0bGU6IFwiYWJjaXF1YW0gZmV1Z2lhdCBiZWFuc1wiLFxyXG4gICAgcHJpY2U6IDQuODgsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcImJlYW5zLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwidmVnZXRhYmxlXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCI0XCIsXHJcbiAgICB0aXRsZTogXCJMb3JlbSBhbSBiZWFucyBkdWkgbm9uXCIsXHJcbiAgICBwcmljZTogMS44OCxcclxuICAgIG9mZmVyUHJpY2U6IG51bGwsXHJcbiAgICBzdG9jazogMTIsXHJcbiAgICBpbWc6IFwiYmVhbnMyLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwidmVnZXRhYmxlXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCI1XCIsXHJcbiAgICB0aXRsZTogXCJCZXJyeSBlcyBmZXVnaWF0IG1vbGxpc1wiLFxyXG4gICAgcHJpY2U6IDIuMyxcclxuICAgIG9mZmVyUHJpY2U6IG51bGwsXHJcbiAgICBzdG9jazogMTIsXHJcbiAgICBpbWc6IFwiYmVycnkuanBnXCIsXHJcbiAgICBjYXRlZ29yeTogXCJmcnVpdHNcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjZcIixcclxuICAgIHRpdGxlOiBcImJlcnJ5IGZldWdpYXQgZHVpIG5vbiBtb2xsaXNcIixcclxuICAgIHByaWNlOiAyLjIyLFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJiZXJyeTIuanBnXCIsXHJcbiAgICBjYXRlZ29yeTogXCJmcnVpdHNcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjdcIixcclxuICAgIHRpdGxlOiBcImJydXNzZWxzIGZldWdpYXQgZHVpIG5vbiBtb2xsaXNcIixcclxuICAgIHByaWNlOiAyLjg4LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJicnVzc2Vscy5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcInZlZ2V0YWJsZVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiOFwiLFxyXG4gICAgdGl0bGU6IFwiY2Fycm90IGZldWdpYXQgZHVpIG5vbiBtb2xsaXNcIixcclxuICAgIHByaWNlOiAzLjg4LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJjYXJyb3QuanBnXCIsXHJcbiAgICBjYXRlZ29yeTogXCJ2ZWdldGFibGVcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjlcIixcclxuICAgIHRpdGxlOiBcImNlbGVyeSBmZXVnaWF0IGR1aSBub24gbW9sbGlzXCIsXHJcbiAgICBwcmljZTogNS44OCxcclxuICAgIG9mZmVyUHJpY2U6IG51bGwsXHJcbiAgICBzdG9jazogMTIsXHJcbiAgICBpbWc6IFwiY2VsZXJ5LmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwidmVnZXRhYmxlXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCIxMVwiLFxyXG4gICAgdGl0bGU6IFwiY2hlcnJ5IGZldWdpYXQgZHVpIG5vbiBtb2xsaXNcIixcclxuICAgIHByaWNlOiA3Ljg4LFxyXG4gICAgb2ZmZXJQcmljZTogNi44OCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJjaGVycnkuanBnXCIsXHJcbiAgICBjYXRlZ29yeTogXCJmcnVpdHNcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjIyXCIsXHJcbiAgICB0aXRsZTogXCJjaGlja2VuIGZldWdpYXQgZHVpIG5vbiBtb2xsaXNcIixcclxuICAgIHByaWNlOiA0Ljg4LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJjaGlja2VuLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwibWVhdFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMzNcIixcclxuICAgIHRpdGxlOiBcIkFsaXF1YW0gZmV1Z2lhdCBub24gY2hpY2tlblwiLFxyXG4gICAgcHJpY2U6IDguODgsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcImNoaWNrZW4yLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwibWVhdFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNDRcIixcclxuICAgIHRpdGxlOiBcImNsZW1lbiBmZXVnaWF0IGR1aVwiLFxyXG4gICAgcHJpY2U6IDQuOTksXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcImNsZW1lbi5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImZydWl0c1wiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNTVcIixcclxuICAgIHRpdGxlOiBcImNvZCBmZXVnaWF0IGR1aSBub25cIixcclxuICAgIHByaWNlOiA5Ljg4LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJjb2QuanBnXCIsXHJcbiAgICBjYXRlZ29yeTogXCJtZWF0XCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCI2NlwiLFxyXG4gICAgdGl0bGU6IFwiY29ybiBmZXVnaWF0IG5vbiBtb2xsaXNcIixcclxuICAgIHByaWNlOiA0Ljg4LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJjb3JuLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwidmVnZXRhYmxlXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCI3N1wiLFxyXG4gICAgdGl0bGU6IFwiY3VjdW1iZXIgZmV1Z2lhdCBkdWkgbm9uXCIsXHJcbiAgICBwcmljZTogNC44OCxcclxuICAgIG9mZmVyUHJpY2U6IDIuNSxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJjdWN1bWJlci5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcInZlZ2V0YWJsZVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiODhcIixcclxuICAgIHRpdGxlOiBcImRhdGVzIGZldWdpYXQgbm9uIGR1aWxpc1wiLFxyXG4gICAgcHJpY2U6IDQuODgsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcImRhdGVzLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwiZnJ1aXRzXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCI5OVwiLFxyXG4gICAgdGl0bGU6IFwiZnJlc2ggZmlzaCBmZXVnaWF0IGR1aVwiLFxyXG4gICAgcHJpY2U6IDQuODgsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcImZpc2guanBnXCIsXHJcbiAgICBjYXRlZ29yeTogXCJtZWF0XCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCIwMFwiLFxyXG4gICAgdGl0bGU6IFwiZmlzaCBsb3JlbSBpcHN1bVwiLFxyXG4gICAgcHJpY2U6IDQuODgsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcImZpc2gyLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwibWVhdFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMTExXCIsXHJcbiAgICB0aXRsZTogXCJmaXNoIG5vbiBtb2xsaXMgZmV1Z2lhdCBkdWlcIixcclxuICAgIHByaWNlOiA0Ljg4LFxyXG4gICAgb2ZmZXJQcmljZTogMy4yNSxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJmaXNoMy5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcIm1lYXRcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjIyMlwiLFxyXG4gICAgdGl0bGU6IFwibGVtb24gbm9uIG1vbGxpc1wiLFxyXG4gICAgcHJpY2U6IDQuODgsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcImxlbW9uLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwiZnVpdHNcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjMzM1wiLFxyXG4gICAgdGl0bGU6IFwiQWxpcXVhbSBsaW1lIGR1aSBub24gbW9sbGlzXCIsXHJcbiAgICBwcmljZTogNC44OCxcclxuICAgIG9mZmVyUHJpY2U6IG51bGwsXHJcbiAgICBzdG9jazogMTIsXHJcbiAgICBpbWc6IFwibGltZS5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImZydWl0c1wiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNDQ0XCIsXHJcbiAgICB0aXRsZTogXCJBbGlxdWFtIG1hbmdvIGR1aSBub25cIixcclxuICAgIHByaWNlOiA0Ljg4LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJtYW5nby5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImZydWl0c1wiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNTU1XCIsXHJcbiAgICB0aXRsZTogXCJBbGlxdWFtIG1lYXQgZHVpIG5vbiBtb2xsaXNcIixcclxuICAgIHByaWNlOiA0Ljg4LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJtZWF0LmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwibWVhdFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNjY2XCIsXHJcbiAgICB0aXRsZTogXCJtZWF0IGZldWdpYXQgZHVpIG5vbiBtb2xsaXNcIixcclxuICAgIHByaWNlOiA0Ljg4LFxyXG4gICAgb2ZmZXJQcmljZTogNC4wLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcIm1lYXQyLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwibWVhdFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNzc3XCIsXHJcbiAgICB0aXRsZTogXCJBbGlxdWFtIGZldWdpYXQgZHVpIG5vbiBtZWF0XCIsXHJcbiAgICBwcmljZTogNC44OCxcclxuICAgIG9mZmVyUHJpY2U6IG51bGwsXHJcbiAgICBzdG9jazogMTIsXHJcbiAgICBpbWc6IFwibWVhdDMuanBnXCIsXHJcbiAgICBjYXRlZ29yeTogXCJtZWF0XCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCI4ODhcIixcclxuICAgIHRpdGxlOiBcIm1peCB2ZWdldGFibGVzIGZldWdpYXQgZHVpIG5vbiBtb2xsaXNcIixcclxuICAgIHByaWNlOiA0Ljg4LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJtaXguanBnXCIsXHJcbiAgICBjYXRlZ29yeTogXCJ2ZWdldGFibGVcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjk5OVwiLFxyXG4gICAgdGl0bGU6IFwicGVhcnMgZmV1Z2lhdCBkdWkgbm9uIG1vbGxpc1wiLFxyXG4gICAgcHJpY2U6IDQuODgsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcInBlYXJzLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwiZnJ1aXRzXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCIwMDBcIixcclxuICAgIHRpdGxlOiBcIkFsaXF1YW0gcGVwcGVyIGR1aSBub24gbW9sbGlzXCIsXHJcbiAgICBwcmljZTogNC44OCxcclxuICAgIG9mZmVyUHJpY2U6IDMuOTksXHJcbiAgICBzdG9jazogMTIsXHJcbiAgICBpbWc6IFwicGVwcGVyLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwidmVnZXRhYmxlXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCIxMTExXCIsXHJcbiAgICB0aXRsZTogXCJBbGlxdWFtIHNhbG1vbiBkdWkgbm9uIG1vbGxpc1wiLFxyXG4gICAgcHJpY2U6IDQuODgsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcInNhbG1vbi5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcIm1lYXRcIixcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBpZDogXCJicmVhZDFcIixcclxuICAgIHRpdGxlOiBcIlNwcm91dHMgQ2xhc3NpYyBTZWVkc2F0aW9uYWwgQnJlYWQgMTQgb3pcIixcclxuICAgIHByaWNlOiAyLjI1LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJicmVhZC5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImJha2VyeVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiYnJlYWQyXCIsXHJcbiAgICB0aXRsZTogXCJUcmFkaXRpb25hbCBDb3JuIFNwZWNpYWwgQnJlYWRcIixcclxuICAgIHByaWNlOiAxLjc1LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJicmVhZDIuanBnXCIsXHJcbiAgICBjYXRlZ29yeTogXCJiYWtlcnlcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcImJyZWFkM1wiLFxyXG4gICAgdGl0bGU6IFwiU3Byb3V0cyBDbGFzc2ljIFNlZWRzYXRpb25hbCBCcmVhZFwiLFxyXG4gICAgcHJpY2U6IDIuMjUsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcImJyZWFkMy5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImJha2VyeVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwidG9hc3RcIixcclxuICAgIHRpdGxlOiBcIk92ZW4gQmFrZWQgR2FybGljICYgQ2hlZXNlIFRvYXN0XCIsXHJcbiAgICBwcmljZTogMS43LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJ0b2FzdC5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImJha2VyeVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwidG9hc3QyXCIsXHJcbiAgICB0aXRsZTogXCJPdmVuIEJha2VkIEl0YWxpYW4gSGVyYiB3aXRoIE9saXZlIE9pbCBUb2FzdFwiLFxyXG4gICAgcHJpY2U6IDIuMjUsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcInRvYXN0Mi5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImJha2VyeVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiY29va2llc1wiLFxyXG4gICAgdGl0bGU6IFwiUmFzcGJlcnJ5IENydW1ibGUgQ29va2llc1wiLFxyXG4gICAgcHJpY2U6IDIuMjUsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcImNvb2tpZXMuanBnXCIsXHJcbiAgICBjYXRlZ29yeTogXCJiYWtlcnlcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcImNvb2tpZXMyXCIsXHJcbiAgICB0aXRsZTogXCJDaG9jb2xhdGUgQ2hpcCBDb29raWVzXCIsXHJcbiAgICBwcmljZTogMy4wLFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJjb29raWVzMi5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImJha2VyeVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiY29va2llczNcIixcclxuICAgIHRpdGxlOiBcIkZyZXNobHkgQmFrZWQgQ2hvY29sYXRlIENoaXAgQ29va2llXCIsXHJcbiAgICBwcmljZTogMi41LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJjb29raWVzMy5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImJha2VyeVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwibXVmZmluXCIsXHJcbiAgICB0aXRsZTogXCJUaG9tYXMgQ2lubmFtb24gUmFpc2luIEVuZ2xpc2ggTXVmZmluc1wiLFxyXG4gICAgcHJpY2U6IDIuMjUsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcIm11ZmZpbi5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImJha2VyeVwiLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIGlkOiBcIm11ZmZpbjJcIixcclxuICAgIHRpdGxlOiBcIk1pbmkgWnVjY2hpbmkgJiBDYXJyb3QgTXVmZmluXCIsXHJcbiAgICBwcmljZTogMi4yNSxcclxuICAgIG9mZmVyUHJpY2U6IG51bGwsXHJcbiAgICBzdG9jazogMTIsXHJcbiAgICBpbWc6IFwibXVmZmluMi5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImJha2VyeVwiLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIGlkOiBcIm11ZmZpbjNcIixcclxuICAgIHRpdGxlOiBcIkRvdWJsZSBDaG9jb2xhdGUgT2F0IE11ZmZpbiBcIixcclxuICAgIHByaWNlOiAyLjI1LFxyXG4gICAgb2ZmZXJQcmljZTogbnVsbCxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJtdWZmaW4zLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwiYmFrZXJ5XCIsXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgaWQ6IFwidGVhXCIsXHJcbiAgICB0aXRsZTogXCJGcmVzaGx5IEJyZXdlZCBPcmdhbmljIEdyZWVuIFRlYVwiLFxyXG4gICAgcHJpY2U6IDAuNzUsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcInRlYS5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImRyaW5rXCIsXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgaWQ6IFwiY29mZmVcIixcclxuICAgIHRpdGxlOiBcIkZyZXNoIEdyaW5kZWQgRnJhcHDDqSBjb2ZmZWVcIixcclxuICAgIHByaWNlOiAxLjUsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcImNvZmZlLmpwZ1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwiZHJpbmtcIixcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBpZDogXCJjb2ZmZTJcIixcclxuICAgIHRpdGxlOiBcIkNhZmZlZSBOZXJvIE1vY2hhIExhdGVcIixcclxuICAgIHByaWNlOiAxLjgsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcImNvZmZlMi5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImRyaW5rXCIsXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgaWQ6IFwiY29mZmUzXCIsXHJcbiAgICB0aXRsZTogXCJOZXNjYWZlIENsYXNpY28gSW5zdGFudCBDb2ZmZWVcIixcclxuICAgIHByaWNlOiAyLjIsXHJcbiAgICBvZmZlclByaWNlOiBudWxsLFxyXG4gICAgc3RvY2s6IDEyLFxyXG4gICAgaW1nOiBcImNvZmZlMy5qcGdcIixcclxuICAgIGNhdGVnb3J5OiBcImRyaW5rXCIsXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgaWQ6IFwiY29mZmU0XCIsXHJcbiAgICB0aXRsZTogXCJQZWV0IENvZmZlZSBEZWNhZiBNYWpvciBEaWNrYXNvbiBCbGVuZFwiLFxyXG4gICAgcHJpY2U6IDIuNCxcclxuICAgIG9mZmVyUHJpY2U6IDIuMSxcclxuICAgIHN0b2NrOiAxMixcclxuICAgIGltZzogXCJjb2ZmZTQuanBnXCIsXHJcbiAgICBjYXRlZ29yeTogXCJkcmlua1wiLFxyXG4gIH0sXHJcbl07XHJcbiIsImltcG9ydCBkYXRhIGZyb20gXCIuLi8uLi9kYXRhXCI7XHJcblxyXG5jb25zdCBoYW5kbGVTb3J0ID0gKGl0ZW1zLCBzb3J0TW9kZSkgPT4ge1xyXG4gIHN3aXRjaCAoc29ydE1vZGUpIHtcclxuICAgIGNhc2UgXCJBc2NlbmRpbmdcIjpcclxuICAgICAgcmV0dXJuIGl0ZW1zLnNvcnQoKGEsIGIpID0+IGEudGl0bGUgLSBiLnRpdGxlKTtcclxuICAgIGNhc2UgXCJEZXNjZW5kaW5nXCI6XHJcbiAgICAgIHJldHVybiBpdGVtcy5zb3J0KChhLCBiKSA9PiBiLnRpdGxlIC0gYS50aXRsZSk7XHJcbiAgICBjYXNlIFwiTWluIFByaWNlXCI6XHJcbiAgICAgIHJldHVybiBpdGVtcy5zb3J0KChhLCBiKSA9PiBhLnByaWNlIC0gYi5wcmljZSk7XHJcbiAgICBjYXNlIFwiTWF4IFByaWNlXCI6XHJcbiAgICAgIHJldHVybiBpdGVtcy5zb3J0KChhLCBiKSA9PiBiLnByaWNlIC0gYS5wcmljZSk7XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICByZXR1cm4gaXRlbXM7XHJcbiAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgKHJlcSwgcmVzKSA9PiB7XHJcbiAgY29uc3QgY2F0ID0gcmVxLnF1ZXJ5LmNhdGVnb3J5O1xyXG4gIGNvbnN0IHNvcnQgPSByZXEucXVlcnkuc29ydDtcclxuICBjb25zdCBzZWFyY2ggPSByZXEucXVlcnkuc2VhcmNoO1xyXG5cclxuICAvL3VzZSBzZXR0aW1lb3V0IGZvciBhcHJlY2lhdGUgY2FyZCBsb2FkZXJzXHJcbiAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICBpZiAoIWNhdCB8fCAhc29ydCkgcmV0dXJuIHJlcy5qc29uKGRhdGEpO1xyXG5cclxuICAgIGxldCBpdGVtcztcclxuXHJcbiAgICBpZiAoY2F0ICE9PSBcImFsbFwiKSB7XHJcbiAgICAgIGl0ZW1zID0gZGF0YS5maWx0ZXIoKGkpID0+IGkuY2F0ZWdvcnkgPT09IGNhdCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpdGVtcyA9IGRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHR5cGVvZiBzZWFyY2ggPT09IFwic3RyaW5nXCIpIHtcclxuICAgICAgY29uc3Qgc2VhcmNoUXVlcnkgPSBzZWFyY2gudG9Mb2NhbGVMb3dlckNhc2UoKTtcclxuICAgICAgaXRlbXMgPSBpdGVtcy5maWx0ZXIoKGkpID0+IHtcclxuICAgICAgICBjb25zdCB0aXRsZSA9IGkudGl0bGUudG9Mb2NhbGVMb3dlckNhc2UoKTtcclxuICAgICAgICByZXR1cm4gdGl0bGUuaW5jbHVkZXMoc2VhcmNoUXVlcnkpO1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBzb3J0ZWR0SXRlbXMgPSBoYW5kbGVTb3J0KGl0ZW1zLCBzb3J0KTtcclxuXHJcbiAgICByZXR1cm4gcmVzLmpzb24oc29ydGVkdEl0ZW1zKTtcclxuICB9LCA4MDApO1xyXG59O1xyXG4iXSwic291cmNlUm9vdCI6IiJ9
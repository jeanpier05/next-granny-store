webpackHotUpdate_N_E("pages/checkout",{

/***/ "./src/components/checkout/CheckoutForm.jsx":
/*!**************************************************!*\
  !*** ./src/components/checkout/CheckoutForm.jsx ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @chakra-ui/core */ "./node_modules/@chakra-ui/core/dist/es/index.js");
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons/bi */ "./node_modules/react-icons/bi/index.esm.js");
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.js");
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/recoil.js");
/* harmony import */ var _recoil_state__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../recoil/state */ "./src/recoil/state.js");
/* harmony import */ var _others_ConfirmAlertModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../others/ConfirmAlertModal */ "./src/components/others/ConfirmAlertModal.jsx");
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../helpers */ "./src/helpers.js");


var _jsxFileName = "E:\\nodesjs\\next-grocery-store\\src\\components\\checkout\\CheckoutForm.jsx",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;









function CheckoutForm() {
  _s();

  var setForm = Object(recoil__WEBPACK_IMPORTED_MODULE_5__["useSetRecoilState"])(_recoil_state__WEBPACK_IMPORTED_MODULE_6__["formState"]);

  var _useRecoilState = Object(recoil__WEBPACK_IMPORTED_MODULE_5__["useRecoilState"])(_recoil_state__WEBPACK_IMPORTED_MODULE_6__["withDelivery"]),
      _useRecoilState2 = Object(_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useRecoilState, 2),
      delivery = _useRecoilState2[0],
      setDelivery = _useRecoilState2[1];

  var _useForm = Object(react_hook_form__WEBPACK_IMPORTED_MODULE_4__["useForm"])({
    mode: "onTouched"
  }),
      register = _useForm.register,
      errors = _useForm.errors,
      handleSubmit = _useForm.handleSubmit;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false),
      showModal = _useState[0],
      setModal = _useState[1];

  var validations = Object(_helpers__WEBPACK_IMPORTED_MODULE_8__["getFormValidations"])();

  var onSubmit = function onSubmit(formState) {
    setForm(formState);
    setModal(true);
  };

  return __jsx(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    w: ["100%", "80%", "46%", "40%"],
    height: "max-content",
    bg: "white",
    p: "4",
    mx: "2",
    order: ["1", "1", "0"],
    mt: ["6", "6", "0"],
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 7
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Heading"], {
    as: "h3",
    size: "md",
    textAlign: "center",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 9
    }
  }, "Sus opciones"), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Flex"], {
    as: "form",
    p: "2",
    direction: "column",
    onSubmit: handleSubmit(onSubmit),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 9
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Flex"], {
    justify: "center",
    align: "center",
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 11
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["FormLabel"], {
    htmlFor: "delivery",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 13
    }
  }, "Con delivery?"), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Switch"], {
    id: "delivery",
    color: "teal",
    onChange: function onChange() {
      return setDelivery(!delivery);
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 13
    }
  })), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputGroup"], {
    mt: "4",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48,
      columnNumber: 11
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputLeftElement"], {
    children: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["PseudoBox"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiUser"],
      size: "24px",
      color: "bluex.400",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 41
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 13
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Input"], {
    type: "text",
    name: "name",
    placeholder: "Tu nombre",
    variant: "filled",
    ref: register(validations.name),
    isInvalid: errors.name ? true : false,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 13
    }
  })), errors.name && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    as: "i",
    fontSize: "xs",
    color: "red.500",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 13
    }
  }, errors.name.message), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputGroup"], {
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 11
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputLeftElement"], {
    children: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["PseudoBox"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiPhone"],
      size: "24px",
      color: "bluex.400",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 41
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 13
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Input"], {
    type: "phone",
    name: "phone",
    placeholder: "N\xFAmero Celular",
    variant: "filled",
    ref: register(validations.phone),
    isInvalid: errors.phone ? true : false,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 67,
      columnNumber: 13
    }
  })), errors.phone && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    as: "i",
    fontSize: "xs",
    color: "red.500",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 77,
      columnNumber: 13
    }
  }, errors.phone.message), delivery && __jsx(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputGroup"], {
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 15
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputLeftElement"], {
    children: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["PseudoBox"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiMap"],
      size: "24px",
      color: "bluex.400",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 45
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 85,
      columnNumber: 17
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Input"], {
    type: "text",
    name: "address",
    placeholder: "Su direcci\xF3n",
    variant: "filled",
    ref: register(validations.address),
    isInvalid: errors.address ? true : false,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 86,
      columnNumber: 17
    }
  })), errors.address && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    as: "i",
    fontSize: "xs",
    color: "red.500",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 96,
      columnNumber: 17
    }
  }, errors.address.message), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputGroup"], {
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 101,
      columnNumber: 15
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputLeftElement"], {
    children: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["PseudoBox"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiMapAlt"],
      size: "24px",
      color: "bluex.400",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 102,
        columnNumber: 45
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 102,
      columnNumber: 17
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Select"], {
    variant: "filled",
    placeholder: "-- Elige un distrito --",
    pl: "40px",
    name: "city",
    ref: register(validations.city),
    isInvalid: errors.city ? true : false,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 103,
      columnNumber: 17
    }
  }, __jsx("option", {
    value: "option1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 111,
      columnNumber: 19
    }
  }, "Trujillo"), __jsx("option", {
    value: "option2",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 112,
      columnNumber: 19
    }
  }, "El Porvenir"), __jsx("option", {
    value: "option3",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 113,
      columnNumber: 19
    }
  }, "Florencia de Mora"), __jsx("option", {
    value: "option4",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 114,
      columnNumber: 19
    }
  }, "La Esperanza"))), errors.city && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    as: "i",
    fontSize: "xs",
    color: "red.500",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 118,
      columnNumber: 17
    }
  }, errors.city.message), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputGroup"], {
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 123,
      columnNumber: 15
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputLeftElement"], {
    children: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["PseudoBox"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiTime"],
      size: "24px",
      color: "bluex.400",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 124,
        columnNumber: 45
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 124,
      columnNumber: 17
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Select"], {
    variant: "filled",
    placeholder: "-- Elija un horario --",
    pl: "40px",
    name: "schedule",
    ref: register(validations.schedule),
    isInvalid: errors.schedule ? true : false,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 125,
      columnNumber: 17
    }
  }, __jsx("option", {
    value: "option1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 133,
      columnNumber: 19
    }
  }, "Lo mas pronto"), __jsx("option", {
    value: "option2",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 134,
      columnNumber: 19
    }
  }, "09:00 am - 10:00 am"), __jsx("option", {
    value: "option3",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 135,
      columnNumber: 19
    }
  }, "02:00 pm - 03:00 pm"), __jsx("option", {
    value: "option4",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 136,
      columnNumber: 19
    }
  }, "04:00 pm - 05:00 pm"))), errors.schedule && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    as: "i",
    fontSize: "xs",
    color: "red.500",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 140,
      columnNumber: 17
    }
  }, errors.schedule.message)), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputGroup"], {
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 147,
      columnNumber: 11
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputLeftElement"], {
    children: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["PseudoBox"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiComment"],
      size: "24px",
      color: "bluex.400",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 148,
        columnNumber: 41
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 148,
      columnNumber: 13
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Input"], {
    type: "text",
    name: "comment",
    placeholder: "Comentario adicional",
    variant: "filled",
    ref: register(validations.comment),
    isInvalid: errors.comment ? true : false,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 149,
      columnNumber: 13
    }
  })), errors.comment && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    as: "i",
    fontSize: "xs",
    color: "red.500",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 159,
      columnNumber: 13
    }
  }, errors.comment.message), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Button"], {
    type: "submit",
    w: "100%",
    variantColor: "green",
    size: "lg",
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 164,
      columnNumber: 11
    }
  }, "CONFIRMAR"))), showModal && __jsx(_others_ConfirmAlertModal__WEBPACK_IMPORTED_MODULE_7__["default"], {
    showModal: showModal,
    setModal: setModal,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 170,
      columnNumber: 21
    }
  }));
}

_s(CheckoutForm, "GqX6+QMD/L3OkBE3jXQ3BC9ei0Y=", false, function () {
  return [recoil__WEBPACK_IMPORTED_MODULE_5__["useSetRecoilState"], recoil__WEBPACK_IMPORTED_MODULE_5__["useRecoilState"], react_hook_form__WEBPACK_IMPORTED_MODULE_4__["useForm"]];
});

_c = CheckoutForm;
/* harmony default export */ __webpack_exports__["default"] = (CheckoutForm);

var _c;

$RefreshReg$(_c, "CheckoutForm");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvY2hlY2tvdXQvQ2hlY2tvdXRGb3JtLmpzeCJdLCJuYW1lcyI6WyJDaGVja291dEZvcm0iLCJzZXRGb3JtIiwidXNlU2V0UmVjb2lsU3RhdGUiLCJmb3JtU3RhdGUiLCJ1c2VSZWNvaWxTdGF0ZSIsIndpdGhEZWxpdmVyeSIsImRlbGl2ZXJ5Iiwic2V0RGVsaXZlcnkiLCJ1c2VGb3JtIiwibW9kZSIsInJlZ2lzdGVyIiwiZXJyb3JzIiwiaGFuZGxlU3VibWl0IiwidXNlU3RhdGUiLCJzaG93TW9kYWwiLCJzZXRNb2RhbCIsInZhbGlkYXRpb25zIiwiZ2V0Rm9ybVZhbGlkYXRpb25zIiwib25TdWJtaXQiLCJCaVVzZXIiLCJuYW1lIiwibWVzc2FnZSIsIkJpUGhvbmUiLCJwaG9uZSIsIkJpTWFwIiwiYWRkcmVzcyIsIkJpTWFwQWx0IiwiY2l0eSIsIkJpVGltZSIsInNjaGVkdWxlIiwiQmlDb21tZW50IiwiY29tbWVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBZUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsU0FBU0EsWUFBVCxHQUF3QjtBQUFBOztBQUN0QixNQUFNQyxPQUFPLEdBQUdDLGdFQUFpQixDQUFDQyx1REFBRCxDQUFqQzs7QUFEc0Isd0JBRVVDLDZEQUFjLENBQUNDLDBEQUFELENBRnhCO0FBQUE7QUFBQSxNQUVmQyxRQUZlO0FBQUEsTUFFTEMsV0FGSzs7QUFBQSxpQkFHcUJDLCtEQUFPLENBQUM7QUFBRUMsUUFBSSxFQUFFO0FBQVIsR0FBRCxDQUg1QjtBQUFBLE1BR2RDLFFBSGMsWUFHZEEsUUFIYztBQUFBLE1BR0pDLE1BSEksWUFHSkEsTUFISTtBQUFBLE1BR0lDLFlBSEosWUFHSUEsWUFISjs7QUFBQSxrQkFJUUMsc0RBQVEsQ0FBQyxLQUFELENBSmhCO0FBQUEsTUFJZkMsU0FKZTtBQUFBLE1BSUpDLFFBSkk7O0FBS3RCLE1BQU1DLFdBQVcsR0FBR0MsbUVBQWtCLEVBQXRDOztBQUVBLE1BQU1DLFFBQVEsR0FBRyxTQUFYQSxRQUFXLENBQUNmLFNBQUQsRUFBZTtBQUM5QkYsV0FBTyxDQUFDRSxTQUFELENBQVA7QUFDQVksWUFBUSxDQUFDLElBQUQsQ0FBUjtBQUNELEdBSEQ7O0FBS0EsU0FDRSxtRUFDRSxNQUFDLG1EQUFEO0FBQUssS0FBQyxFQUFFLENBQUMsTUFBRCxFQUFTLEtBQVQsRUFBZ0IsS0FBaEIsRUFBdUIsS0FBdkIsQ0FBUjtBQUF1QyxVQUFNLEVBQUMsYUFBOUM7QUFBNEQsTUFBRSxFQUFDLE9BQS9EO0FBQXVFLEtBQUMsRUFBQyxHQUF6RTtBQUE2RSxNQUFFLEVBQUMsR0FBaEY7QUFBb0YsU0FBSyxFQUFFLENBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxHQUFYLENBQTNGO0FBQTRHLE1BQUUsRUFBRSxDQUFDLEdBQUQsRUFBTSxHQUFOLEVBQVcsR0FBWCxDQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsTUFBQyx1REFBRDtBQUFTLE1BQUUsRUFBQyxJQUFaO0FBQWlCLFFBQUksRUFBQyxJQUF0QjtBQUEyQixhQUFTLEVBQUMsUUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixFQUlFLE1BQUMsb0RBQUQ7QUFBTSxNQUFFLEVBQUMsTUFBVDtBQUFnQixLQUFDLEVBQUMsR0FBbEI7QUFBc0IsYUFBUyxFQUFDLFFBQWhDO0FBQXlDLFlBQVEsRUFBRUgsWUFBWSxDQUFDTSxRQUFELENBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLG9EQUFEO0FBQU0sV0FBTyxFQUFDLFFBQWQ7QUFBdUIsU0FBSyxFQUFDLFFBQTdCO0FBQXNDLE1BQUUsRUFBQyxHQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsTUFBQyx5REFBRDtBQUFXLFdBQU8sRUFBQyxVQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLEVBRUUsTUFBQyxzREFBRDtBQUFRLE1BQUUsRUFBQyxVQUFYO0FBQXNCLFNBQUssRUFBQyxNQUE1QjtBQUFvQyxZQUFRLEVBQUU7QUFBQSxhQUFNWCxXQUFXLENBQUMsQ0FBQ0QsUUFBRixDQUFqQjtBQUFBLEtBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFGRixDQURGLEVBTUUsTUFBQywwREFBRDtBQUFZLE1BQUUsRUFBQyxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLGdFQUFEO0FBQWtCLFlBQVEsRUFBRSxNQUFDLHlEQUFEO0FBQVcsUUFBRSxFQUFFYSxxREFBZjtBQUF1QixVQUFJLEVBQUMsTUFBNUI7QUFBbUMsV0FBSyxFQUFDLFdBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQURGLEVBRUUsTUFBQyxxREFBRDtBQUNFLFFBQUksRUFBQyxNQURQO0FBRUUsUUFBSSxFQUFDLE1BRlA7QUFHRSxlQUFXLEVBQUMsV0FIZDtBQUlFLFdBQU8sRUFBQyxRQUpWO0FBS0UsT0FBRyxFQUFFVCxRQUFRLENBQUNNLFdBQVcsQ0FBQ0ksSUFBYixDQUxmO0FBTUUsYUFBUyxFQUFFVCxNQUFNLENBQUNTLElBQVAsR0FBYyxJQUFkLEdBQXFCLEtBTmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFGRixDQU5GLEVBaUJHVCxNQUFNLENBQUNTLElBQVAsSUFDQyxNQUFDLG9EQUFEO0FBQU0sTUFBRSxFQUFDLEdBQVQ7QUFBYSxZQUFRLEVBQUMsSUFBdEI7QUFBMkIsU0FBSyxFQUFDLFNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDR1QsTUFBTSxDQUFDUyxJQUFQLENBQVlDLE9BRGYsQ0FsQkosRUF1QkUsTUFBQywwREFBRDtBQUFZLE1BQUUsRUFBQyxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLGdFQUFEO0FBQWtCLFlBQVEsRUFBRSxNQUFDLHlEQUFEO0FBQVcsUUFBRSxFQUFFQyxzREFBZjtBQUF3QixVQUFJLEVBQUMsTUFBN0I7QUFBb0MsV0FBSyxFQUFDLFdBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQURGLEVBRUUsTUFBQyxxREFBRDtBQUNFLFFBQUksRUFBQyxPQURQO0FBRUUsUUFBSSxFQUFDLE9BRlA7QUFHRSxlQUFXLEVBQUMsbUJBSGQ7QUFJRSxXQUFPLEVBQUMsUUFKVjtBQUtFLE9BQUcsRUFBRVosUUFBUSxDQUFDTSxXQUFXLENBQUNPLEtBQWIsQ0FMZjtBQU1FLGFBQVMsRUFBRVosTUFBTSxDQUFDWSxLQUFQLEdBQWUsSUFBZixHQUFzQixLQU5uQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRkYsQ0F2QkYsRUFrQ0daLE1BQU0sQ0FBQ1ksS0FBUCxJQUNDLE1BQUMsb0RBQUQ7QUFBTSxNQUFFLEVBQUMsR0FBVDtBQUFhLFlBQVEsRUFBQyxJQUF0QjtBQUEyQixTQUFLLEVBQUMsU0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNHWixNQUFNLENBQUNZLEtBQVAsQ0FBYUYsT0FEaEIsQ0FuQ0osRUF3Q0dmLFFBQVEsSUFDUCxtRUFDRSxNQUFDLDBEQUFEO0FBQVksTUFBRSxFQUFDLEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFLE1BQUMsZ0VBQUQ7QUFBa0IsWUFBUSxFQUFFLE1BQUMseURBQUQ7QUFBVyxRQUFFLEVBQUVrQixvREFBZjtBQUFzQixVQUFJLEVBQUMsTUFBM0I7QUFBa0MsV0FBSyxFQUFDLFdBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQURGLEVBRUUsTUFBQyxxREFBRDtBQUNFLFFBQUksRUFBQyxNQURQO0FBRUUsUUFBSSxFQUFDLFNBRlA7QUFHRSxlQUFXLEVBQUMsaUJBSGQ7QUFJRSxXQUFPLEVBQUMsUUFKVjtBQUtFLE9BQUcsRUFBRWQsUUFBUSxDQUFDTSxXQUFXLENBQUNTLE9BQWIsQ0FMZjtBQU1FLGFBQVMsRUFBRWQsTUFBTSxDQUFDYyxPQUFQLEdBQWlCLElBQWpCLEdBQXdCLEtBTnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFGRixDQURGLEVBWUdkLE1BQU0sQ0FBQ2MsT0FBUCxJQUNDLE1BQUMsb0RBQUQ7QUFBTSxNQUFFLEVBQUMsR0FBVDtBQUFhLFlBQVEsRUFBQyxJQUF0QjtBQUEyQixTQUFLLEVBQUMsU0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNHZCxNQUFNLENBQUNjLE9BQVAsQ0FBZUosT0FEbEIsQ0FiSixFQWtCRSxNQUFDLDBEQUFEO0FBQVksTUFBRSxFQUFDLEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFLE1BQUMsZ0VBQUQ7QUFBa0IsWUFBUSxFQUFFLE1BQUMseURBQUQ7QUFBVyxRQUFFLEVBQUVLLHVEQUFmO0FBQXlCLFVBQUksRUFBQyxNQUE5QjtBQUFxQyxXQUFLLEVBQUMsV0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBREYsRUFFRSxNQUFDLHNEQUFEO0FBQ0UsV0FBTyxFQUFDLFFBRFY7QUFFRSxlQUFXLEVBQUMseUJBRmQ7QUFHRSxNQUFFLEVBQUMsTUFITDtBQUlFLFFBQUksRUFBQyxNQUpQO0FBS0UsT0FBRyxFQUFFaEIsUUFBUSxDQUFDTSxXQUFXLENBQUNXLElBQWIsQ0FMZjtBQU1FLGFBQVMsRUFBRWhCLE1BQU0sQ0FBQ2dCLElBQVAsR0FBYyxJQUFkLEdBQXFCLEtBTmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FRRTtBQUFRLFNBQUssRUFBQyxTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUkYsRUFTRTtBQUFRLFNBQUssRUFBQyxTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVEYsRUFVRTtBQUFRLFNBQUssRUFBQyxTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVkYsRUFXRTtBQUFRLFNBQUssRUFBQyxTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBWEYsQ0FGRixDQWxCRixFQWtDR2hCLE1BQU0sQ0FBQ2dCLElBQVAsSUFDQyxNQUFDLG9EQUFEO0FBQU0sTUFBRSxFQUFDLEdBQVQ7QUFBYSxZQUFRLEVBQUMsSUFBdEI7QUFBMkIsU0FBSyxFQUFDLFNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDR2hCLE1BQU0sQ0FBQ2dCLElBQVAsQ0FBWU4sT0FEZixDQW5DSixFQXdDRSxNQUFDLDBEQUFEO0FBQVksTUFBRSxFQUFDLEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFLE1BQUMsZ0VBQUQ7QUFBa0IsWUFBUSxFQUFFLE1BQUMseURBQUQ7QUFBVyxRQUFFLEVBQUVPLHFEQUFmO0FBQXVCLFVBQUksRUFBQyxNQUE1QjtBQUFtQyxXQUFLLEVBQUMsV0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBREYsRUFFRSxNQUFDLHNEQUFEO0FBQ0UsV0FBTyxFQUFDLFFBRFY7QUFFRSxlQUFXLEVBQUMsd0JBRmQ7QUFHRSxNQUFFLEVBQUMsTUFITDtBQUlFLFFBQUksRUFBQyxVQUpQO0FBS0UsT0FBRyxFQUFFbEIsUUFBUSxDQUFDTSxXQUFXLENBQUNhLFFBQWIsQ0FMZjtBQU1FLGFBQVMsRUFBRWxCLE1BQU0sQ0FBQ2tCLFFBQVAsR0FBa0IsSUFBbEIsR0FBeUIsS0FOdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQVFFO0FBQVEsU0FBSyxFQUFDLFNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFSRixFQVNFO0FBQVEsU0FBSyxFQUFDLFNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFURixFQVVFO0FBQVEsU0FBSyxFQUFDLFNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFWRixFQVdFO0FBQVEsU0FBSyxFQUFDLFNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFYRixDQUZGLENBeENGLEVBd0RHbEIsTUFBTSxDQUFDa0IsUUFBUCxJQUNDLE1BQUMsb0RBQUQ7QUFBTSxNQUFFLEVBQUMsR0FBVDtBQUFhLFlBQVEsRUFBQyxJQUF0QjtBQUEyQixTQUFLLEVBQUMsU0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNHbEIsTUFBTSxDQUFDa0IsUUFBUCxDQUFnQlIsT0FEbkIsQ0F6REosQ0F6Q0osRUF5R0UsTUFBQywwREFBRDtBQUFZLE1BQUUsRUFBQyxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLGdFQUFEO0FBQWtCLFlBQVEsRUFBRSxNQUFDLHlEQUFEO0FBQVcsUUFBRSxFQUFFUyx3REFBZjtBQUEwQixVQUFJLEVBQUMsTUFBL0I7QUFBc0MsV0FBSyxFQUFDLFdBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQURGLEVBRUUsTUFBQyxxREFBRDtBQUNFLFFBQUksRUFBQyxNQURQO0FBRUUsUUFBSSxFQUFDLFNBRlA7QUFHRSxlQUFXLEVBQUMsc0JBSGQ7QUFJRSxXQUFPLEVBQUMsUUFKVjtBQUtFLE9BQUcsRUFBRXBCLFFBQVEsQ0FBQ00sV0FBVyxDQUFDZSxPQUFiLENBTGY7QUFNRSxhQUFTLEVBQUVwQixNQUFNLENBQUNvQixPQUFQLEdBQWlCLElBQWpCLEdBQXdCLEtBTnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFGRixDQXpHRixFQW9IR3BCLE1BQU0sQ0FBQ29CLE9BQVAsSUFDQyxNQUFDLG9EQUFEO0FBQU0sTUFBRSxFQUFDLEdBQVQ7QUFBYSxZQUFRLEVBQUMsSUFBdEI7QUFBMkIsU0FBSyxFQUFDLFNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDR3BCLE1BQU0sQ0FBQ29CLE9BQVAsQ0FBZVYsT0FEbEIsQ0FySEosRUEwSEUsTUFBQyxzREFBRDtBQUFRLFFBQUksRUFBQyxRQUFiO0FBQXNCLEtBQUMsRUFBQyxNQUF4QjtBQUErQixnQkFBWSxFQUFDLE9BQTVDO0FBQW9ELFFBQUksRUFBQyxJQUF6RDtBQUE4RCxNQUFFLEVBQUMsR0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkExSEYsQ0FKRixDQURGLEVBcUlHUCxTQUFTLElBQUksTUFBQyxpRUFBRDtBQUFtQixhQUFTLEVBQUVBLFNBQTlCO0FBQXlDLFlBQVEsRUFBRUMsUUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXJJaEIsQ0FERjtBQXlJRDs7R0FySlFmLFk7VUFDU0Usd0QsRUFDZ0JFLHFELEVBQ1dJLHVEOzs7S0FIcENSLFk7QUF1Sk1BLDJFQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2NoZWNrb3V0LjU1YjBjMzlkZjE3Njk0YjliNjMzLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gIEJveCxcclxuICBCdXR0b24sXHJcbiAgRmxleCxcclxuICBGb3JtTGFiZWwsXHJcbiAgSGVhZGluZyxcclxuICBJbnB1dCxcclxuICBJbnB1dEdyb3VwLFxyXG4gIElucHV0TGVmdEVsZW1lbnQsXHJcbiAgUHNldWRvQm94LFxyXG4gIFNlbGVjdCxcclxuICBTd2l0Y2gsXHJcbiAgVGV4dCxcclxufSBmcm9tIFwiQGNoYWtyYS11aS9jb3JlXCI7XHJcblxyXG5pbXBvcnQgeyBCaUNvbW1lbnQsIEJpTWFwLCBCaU1hcEFsdCwgQmlQaG9uZSwgQmlUaW1lLCBCaVVzZXIgfSBmcm9tIFwicmVhY3QtaWNvbnMvYmlcIjtcclxuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcclxuaW1wb3J0IHsgdXNlUmVjb2lsU3RhdGUsIHVzZVNldFJlY29pbFN0YXRlIH0gZnJvbSBcInJlY29pbFwiO1xyXG5pbXBvcnQgeyBmb3JtU3RhdGUsIHdpdGhEZWxpdmVyeSB9IGZyb20gXCIuLi8uLi9yZWNvaWwvc3RhdGVcIjtcclxuaW1wb3J0IENvbmZpcm1BbGVydE1vZGFsIGZyb20gXCIuLi9vdGhlcnMvQ29uZmlybUFsZXJ0TW9kYWxcIjtcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgZ2V0Rm9ybVZhbGlkYXRpb25zIH0gZnJvbSBcIi4uLy4uL2hlbHBlcnNcIjtcclxuXHJcbmZ1bmN0aW9uIENoZWNrb3V0Rm9ybSgpIHtcclxuICBjb25zdCBzZXRGb3JtID0gdXNlU2V0UmVjb2lsU3RhdGUoZm9ybVN0YXRlKTtcclxuICBjb25zdCBbZGVsaXZlcnksIHNldERlbGl2ZXJ5XSA9IHVzZVJlY29pbFN0YXRlKHdpdGhEZWxpdmVyeSk7XHJcbiAgY29uc3QgeyByZWdpc3RlciwgZXJyb3JzLCBoYW5kbGVTdWJtaXQgfSA9IHVzZUZvcm0oeyBtb2RlOiBcIm9uVG91Y2hlZFwiIH0pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCB2YWxpZGF0aW9ucyA9IGdldEZvcm1WYWxpZGF0aW9ucygpO1xyXG5cclxuICBjb25zdCBvblN1Ym1pdCA9IChmb3JtU3RhdGUpID0+IHtcclxuICAgIHNldEZvcm0oZm9ybVN0YXRlKTtcclxuICAgIHNldE1vZGFsKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8Qm94IHc9e1tcIjEwMCVcIiwgXCI4MCVcIiwgXCI0NiVcIiwgXCI0MCVcIl19IGhlaWdodD1cIm1heC1jb250ZW50XCIgYmc9XCJ3aGl0ZVwiIHA9XCI0XCIgbXg9XCIyXCIgb3JkZXI9e1tcIjFcIiwgXCIxXCIsIFwiMFwiXX0gbXQ9e1tcIjZcIiwgXCI2XCIsIFwiMFwiXX0+XHJcbiAgICAgICAgPEhlYWRpbmcgYXM9XCJoM1wiIHNpemU9XCJtZFwiIHRleHRBbGlnbj1cImNlbnRlclwiPlxyXG4gICAgICAgICAgU3VzIG9wY2lvbmVzXHJcbiAgICAgICAgPC9IZWFkaW5nPlxyXG4gICAgICAgIDxGbGV4IGFzPVwiZm9ybVwiIHA9XCIyXCIgZGlyZWN0aW9uPVwiY29sdW1uXCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvblN1Ym1pdCl9PlxyXG4gICAgICAgICAgPEZsZXgganVzdGlmeT1cImNlbnRlclwiIGFsaWduPVwiY2VudGVyXCIgbXQ9XCI2XCI+XHJcbiAgICAgICAgICAgIDxGb3JtTGFiZWwgaHRtbEZvcj1cImRlbGl2ZXJ5XCI+Q29uIGRlbGl2ZXJ5PzwvRm9ybUxhYmVsPlxyXG4gICAgICAgICAgICA8U3dpdGNoIGlkPVwiZGVsaXZlcnlcIiBjb2xvcj1cInRlYWxcIiAgb25DaGFuZ2U9eygpID0+IHNldERlbGl2ZXJ5KCFkZWxpdmVyeSl9IC8+XHJcbiAgICAgICAgICA8L0ZsZXg+XHJcblxyXG4gICAgICAgICAgPElucHV0R3JvdXAgbXQ9XCI0XCI+XHJcbiAgICAgICAgICAgIDxJbnB1dExlZnRFbGVtZW50IGNoaWxkcmVuPXs8UHNldWRvQm94IGFzPXtCaVVzZXJ9IHNpemU9XCIyNHB4XCIgY29sb3I9XCJibHVleC40MDBcIiAvPn0gLz5cclxuICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIG5hbWU9XCJuYW1lXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlR1IG5vbWJyZVwiXHJcbiAgICAgICAgICAgICAgdmFyaWFudD1cImZpbGxlZFwiXHJcbiAgICAgICAgICAgICAgcmVmPXtyZWdpc3Rlcih2YWxpZGF0aW9ucy5uYW1lKX1cclxuICAgICAgICAgICAgICBpc0ludmFsaWQ9e2Vycm9ycy5uYW1lID8gdHJ1ZSA6IGZhbHNlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9JbnB1dEdyb3VwPlxyXG4gICAgICAgICAge2Vycm9ycy5uYW1lICYmIChcclxuICAgICAgICAgICAgPFRleHQgYXM9XCJpXCIgZm9udFNpemU9XCJ4c1wiIGNvbG9yPVwicmVkLjUwMFwiPlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMubmFtZS5tZXNzYWdlfVxyXG4gICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxJbnB1dEdyb3VwIG10PVwiNlwiPlxyXG4gICAgICAgICAgICA8SW5wdXRMZWZ0RWxlbWVudCBjaGlsZHJlbj17PFBzZXVkb0JveCBhcz17QmlQaG9uZX0gc2l6ZT1cIjI0cHhcIiBjb2xvcj1cImJsdWV4LjQwMFwiIC8+fSAvPlxyXG4gICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwicGhvbmVcIlxyXG4gICAgICAgICAgICAgIG5hbWU9XCJwaG9uZVwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOw7ptZXJvIENlbHVsYXJcIlxyXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJmaWxsZWRcIlxyXG4gICAgICAgICAgICAgIHJlZj17cmVnaXN0ZXIodmFsaWRhdGlvbnMucGhvbmUpfVxyXG4gICAgICAgICAgICAgIGlzSW52YWxpZD17ZXJyb3JzLnBob25lID8gdHJ1ZSA6IGZhbHNlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9JbnB1dEdyb3VwPlxyXG4gICAgICAgICAge2Vycm9ycy5waG9uZSAmJiAoXHJcbiAgICAgICAgICAgIDxUZXh0IGFzPVwiaVwiIGZvbnRTaXplPVwieHNcIiBjb2xvcj1cInJlZC41MDBcIj5cclxuICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAge2RlbGl2ZXJ5ICYmIChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8SW5wdXRHcm91cCBtdD1cIjZcIj5cclxuICAgICAgICAgICAgICAgIDxJbnB1dExlZnRFbGVtZW50IGNoaWxkcmVuPXs8UHNldWRvQm94IGFzPXtCaU1hcH0gc2l6ZT1cIjI0cHhcIiBjb2xvcj1cImJsdWV4LjQwMFwiIC8+fSAvPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlN1IGRpcmVjY2nDs25cIlxyXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZmlsbGVkXCJcclxuICAgICAgICAgICAgICAgICAgcmVmPXtyZWdpc3Rlcih2YWxpZGF0aW9ucy5hZGRyZXNzKX1cclxuICAgICAgICAgICAgICAgICAgaXNJbnZhbGlkPXtlcnJvcnMuYWRkcmVzcyA/IHRydWUgOiBmYWxzZX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9JbnB1dEdyb3VwPlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMuYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8VGV4dCBhcz1cImlcIiBmb250U2l6ZT1cInhzXCIgY29sb3I9XCJyZWQuNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRkcmVzcy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIDxJbnB1dEdyb3VwIG10PVwiNlwiPlxyXG4gICAgICAgICAgICAgICAgPElucHV0TGVmdEVsZW1lbnQgY2hpbGRyZW49ezxQc2V1ZG9Cb3ggYXM9e0JpTWFwQWx0fSBzaXplPVwiMjRweFwiIGNvbG9yPVwiYmx1ZXguNDAwXCIgLz59IC8+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJmaWxsZWRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi0tIEVsaWdlIHVuIGRpc3RyaXRvIC0tXCJcclxuICAgICAgICAgICAgICAgICAgcGw9XCI0MHB4XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImNpdHlcIlxyXG4gICAgICAgICAgICAgICAgICByZWY9e3JlZ2lzdGVyKHZhbGlkYXRpb25zLmNpdHkpfVxyXG4gICAgICAgICAgICAgICAgICBpc0ludmFsaWQ9e2Vycm9ycy5jaXR5ID8gdHJ1ZSA6IGZhbHNlfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib3B0aW9uMVwiPlRydWppbGxvPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvcHRpb24yXCI+RWwgUG9ydmVuaXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm9wdGlvbjNcIj5GbG9yZW5jaWEgZGUgTW9yYTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib3B0aW9uNFwiPkxhIEVzcGVyYW56YTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9JbnB1dEdyb3VwPlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMuY2l0eSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8VGV4dCBhcz1cImlcIiBmb250U2l6ZT1cInhzXCIgY29sb3I9XCJyZWQuNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY2l0eS5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIDxJbnB1dEdyb3VwIG10PVwiNlwiPlxyXG4gICAgICAgICAgICAgICAgPElucHV0TGVmdEVsZW1lbnQgY2hpbGRyZW49ezxQc2V1ZG9Cb3ggYXM9e0JpVGltZX0gc2l6ZT1cIjI0cHhcIiBjb2xvcj1cImJsdWV4LjQwMFwiIC8+fSAvPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZmlsbGVkXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItLSBFbGlqYSB1biBob3JhcmlvIC0tXCJcclxuICAgICAgICAgICAgICAgICAgcGw9XCI0MHB4XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInNjaGVkdWxlXCJcclxuICAgICAgICAgICAgICAgICAgcmVmPXtyZWdpc3Rlcih2YWxpZGF0aW9ucy5zY2hlZHVsZSl9XHJcbiAgICAgICAgICAgICAgICAgIGlzSW52YWxpZD17ZXJyb3JzLnNjaGVkdWxlID8gdHJ1ZSA6IGZhbHNlfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib3B0aW9uMVwiPkxvIG1hcyBwcm9udG88L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm9wdGlvbjJcIj4wOTowMCBhbSAtIDEwOjAwIGFtPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvcHRpb24zXCI+MDI6MDAgcG0gLSAwMzowMCBwbTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib3B0aW9uNFwiPjA0OjAwIHBtIC0gMDU6MDAgcG08L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvSW5wdXRHcm91cD5cclxuICAgICAgICAgICAgICB7ZXJyb3JzLnNjaGVkdWxlICYmIChcclxuICAgICAgICAgICAgICAgIDxUZXh0IGFzPVwiaVwiIGZvbnRTaXplPVwieHNcIiBjb2xvcj1cInJlZC41MDBcIj5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5zY2hlZHVsZS5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICA8SW5wdXRHcm91cCBtdD1cIjZcIj5cclxuICAgICAgICAgICAgPElucHV0TGVmdEVsZW1lbnQgY2hpbGRyZW49ezxQc2V1ZG9Cb3ggYXM9e0JpQ29tbWVudH0gc2l6ZT1cIjI0cHhcIiBjb2xvcj1cImJsdWV4LjQwMFwiIC8+fSAvPlxyXG4gICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgbmFtZT1cImNvbW1lbnRcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ29tZW50YXJpbyBhZGljaW9uYWxcIlxyXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJmaWxsZWRcIlxyXG4gICAgICAgICAgICAgIHJlZj17cmVnaXN0ZXIodmFsaWRhdGlvbnMuY29tbWVudCl9XHJcbiAgICAgICAgICAgICAgaXNJbnZhbGlkPXtlcnJvcnMuY29tbWVudCA/IHRydWUgOiBmYWxzZX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvSW5wdXRHcm91cD5cclxuICAgICAgICAgIHtlcnJvcnMuY29tbWVudCAmJiAoXHJcbiAgICAgICAgICAgIDxUZXh0IGFzPVwiaVwiIGZvbnRTaXplPVwieHNcIiBjb2xvcj1cInJlZC41MDBcIj5cclxuICAgICAgICAgICAgICB7ZXJyb3JzLmNvbW1lbnQubWVzc2FnZX1cclxuICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiB3PVwiMTAwJVwiIHZhcmlhbnRDb2xvcj1cImdyZWVuXCIgc2l6ZT1cImxnXCIgbXQ9XCI2XCI+XHJcbiAgICAgICAgICAgIENPTkZJUk1BUlxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9GbGV4PlxyXG4gICAgICA8L0JveD5cclxuXHJcbiAgICAgIHtzaG93TW9kYWwgJiYgPENvbmZpcm1BbGVydE1vZGFsIHNob3dNb2RhbD17c2hvd01vZGFsfSBzZXRNb2RhbD17c2V0TW9kYWx9IC8+fVxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2hlY2tvdXRGb3JtO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9
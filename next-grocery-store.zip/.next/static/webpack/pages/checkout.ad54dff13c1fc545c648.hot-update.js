webpackHotUpdate_N_E("pages/checkout",{

/***/ "./src/components/checkout/CheckoutForm.jsx":
/*!**************************************************!*\
  !*** ./src/components/checkout/CheckoutForm.jsx ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @chakra-ui/core */ "./node_modules/@chakra-ui/core/dist/es/index.js");
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons/bi */ "./node_modules/react-icons/bi/index.esm.js");
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.js");
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/recoil.js");
/* harmony import */ var _recoil_state__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../recoil/state */ "./src/recoil/state.js");
/* harmony import */ var _others_ConfirmAlertModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../others/ConfirmAlertModal */ "./src/components/others/ConfirmAlertModal.jsx");
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../helpers */ "./src/helpers.js");


var _jsxFileName = "E:\\nodesjs\\next-grocery-store\\src\\components\\checkout\\CheckoutForm.jsx",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;









function CheckoutForm() {
  _s();

  var setForm = Object(recoil__WEBPACK_IMPORTED_MODULE_5__["useSetRecoilState"])(_recoil_state__WEBPACK_IMPORTED_MODULE_6__["formState"]);

  var _useRecoilState = Object(recoil__WEBPACK_IMPORTED_MODULE_5__["useRecoilState"])(_recoil_state__WEBPACK_IMPORTED_MODULE_6__["withDelivery"]),
      _useRecoilState2 = Object(_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useRecoilState, 2),
      delivery = _useRecoilState2[0],
      setDelivery = _useRecoilState2[1];

  var _useForm = Object(react_hook_form__WEBPACK_IMPORTED_MODULE_4__["useForm"])({
    mode: "onTouched"
  }),
      register = _useForm.register,
      errors = _useForm.errors,
      handleSubmit = _useForm.handleSubmit;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false),
      showModal = _useState[0],
      setModal = _useState[1];

  var validations = Object(_helpers__WEBPACK_IMPORTED_MODULE_8__["getFormValidations"])();

  var onSubmit = function onSubmit(formState) {
    setForm(formState);
    setModal(true);
  };

  return __jsx(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    w: ["100%", "80%", "46%", "40%"],
    height: "max-content",
    bg: "white",
    p: "4",
    mx: "2",
    order: ["1", "1", "0"],
    mt: ["6", "6", "0"],
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 7
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Heading"], {
    as: "h3",
    size: "md",
    textAlign: "center",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 9
    }
  }, "Sus opciones"), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Flex"], {
    as: "form",
    p: "2",
    direction: "column",
    onSubmit: handleSubmit(onSubmit),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 9
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Flex"], {
    justify: "center",
    align: "center",
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 11
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["FormLabel"], {
    htmlFor: "delivery",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 13
    }
  }, "Con delivery?"), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Switch"], {
    id: "delivery",
    color: "teal",
    defaultIsChecked: true,
    onChange: function onChange() {
      return setDelivery(!delivery);
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 13
    }
  })), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputGroup"], {
    mt: "4",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48,
      columnNumber: 11
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputLeftElement"], {
    children: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["PseudoBox"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiUser"],
      size: "24px",
      color: "bluex.400",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 41
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 13
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Input"], {
    type: "text",
    name: "name",
    placeholder: "Tu nombre",
    variant: "filled",
    ref: register(validations.name),
    isInvalid: errors.name ? true : false,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 13
    }
  })), errors.name && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    as: "i",
    fontSize: "xs",
    color: "red.500",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 13
    }
  }, errors.name.message), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputGroup"], {
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 11
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputLeftElement"], {
    children: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["PseudoBox"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiPhone"],
      size: "24px",
      color: "bluex.400",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 41
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 13
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Input"], {
    type: "phone",
    name: "phone",
    placeholder: "N\xFAmero Celular",
    variant: "filled",
    ref: register(validations.phone),
    isInvalid: errors.phone ? true : false,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 67,
      columnNumber: 13
    }
  })), errors.phone && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    as: "i",
    fontSize: "xs",
    color: "red.500",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 77,
      columnNumber: 13
    }
  }, errors.phone.message), delivery && __jsx(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputGroup"], {
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 15
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputLeftElement"], {
    children: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["PseudoBox"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiMap"],
      size: "24px",
      color: "bluex.400",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 45
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 85,
      columnNumber: 17
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Input"], {
    type: "text",
    name: "address",
    placeholder: "Su direcci\xF3n",
    variant: "filled",
    ref: register(validations.address),
    isInvalid: errors.address ? true : false,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 86,
      columnNumber: 17
    }
  })), errors.address && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    as: "i",
    fontSize: "xs",
    color: "red.500",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 96,
      columnNumber: 17
    }
  }, errors.address.message), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputGroup"], {
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 101,
      columnNumber: 15
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputLeftElement"], {
    children: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["PseudoBox"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiMapAlt"],
      size: "24px",
      color: "bluex.400",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 102,
        columnNumber: 45
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 102,
      columnNumber: 17
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Select"], {
    variant: "filled",
    placeholder: "-- Elige un distrito --",
    pl: "40px",
    name: "city",
    ref: register(validations.city),
    isInvalid: errors.city ? true : false,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 103,
      columnNumber: 17
    }
  }, __jsx("option", {
    value: "option1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 111,
      columnNumber: 19
    }
  }, "Trujillo"), __jsx("option", {
    value: "option2",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 112,
      columnNumber: 19
    }
  }, "El Porvenir"), __jsx("option", {
    value: "option3",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 113,
      columnNumber: 19
    }
  }, "Florencia de Mora"), __jsx("option", {
    value: "option4",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 114,
      columnNumber: 19
    }
  }, "La Esperanza"))), errors.city && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    as: "i",
    fontSize: "xs",
    color: "red.500",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 118,
      columnNumber: 17
    }
  }, errors.city.message), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputGroup"], {
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 123,
      columnNumber: 15
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputLeftElement"], {
    children: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["PseudoBox"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiTime"],
      size: "24px",
      color: "bluex.400",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 124,
        columnNumber: 45
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 124,
      columnNumber: 17
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Select"], {
    variant: "filled",
    placeholder: "-- Elija un horario --",
    pl: "40px",
    name: "schedule",
    ref: register(validations.schedule),
    isInvalid: errors.schedule ? true : false,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 125,
      columnNumber: 17
    }
  }, __jsx("option", {
    value: "option1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 133,
      columnNumber: 19
    }
  }, "Lo mas pronto"), __jsx("option", {
    value: "option2",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 134,
      columnNumber: 19
    }
  }, "09:00 am - 10:00 am"), __jsx("option", {
    value: "option3",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 135,
      columnNumber: 19
    }
  }, "02:00 pm - 03:00 pm"), __jsx("option", {
    value: "option4",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 136,
      columnNumber: 19
    }
  }, "04:00 pm - 05:00 pm"))), errors.schedule && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    as: "i",
    fontSize: "xs",
    color: "red.500",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 140,
      columnNumber: 17
    }
  }, errors.schedule.message)), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputGroup"], {
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 147,
      columnNumber: 11
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["InputLeftElement"], {
    children: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["PseudoBox"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiComment"],
      size: "24px",
      color: "bluex.400",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 148,
        columnNumber: 41
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 148,
      columnNumber: 13
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Input"], {
    type: "text",
    name: "comment",
    placeholder: "Comentario adicional",
    variant: "filled",
    ref: register(validations.comment),
    isInvalid: errors.comment ? true : false,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 149,
      columnNumber: 13
    }
  })), errors.comment && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    as: "i",
    fontSize: "xs",
    color: "red.500",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 159,
      columnNumber: 13
    }
  }, errors.comment.message), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Button"], {
    type: "submit",
    w: "100%",
    variantColor: "green",
    size: "lg",
    mt: "6",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 164,
      columnNumber: 11
    }
  }, "CONFIRMAR"))), showModal && __jsx(_others_ConfirmAlertModal__WEBPACK_IMPORTED_MODULE_7__["default"], {
    showModal: showModal,
    setModal: setModal,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 170,
      columnNumber: 21
    }
  }));
}

_s(CheckoutForm, "GqX6+QMD/L3OkBE3jXQ3BC9ei0Y=", false, function () {
  return [recoil__WEBPACK_IMPORTED_MODULE_5__["useSetRecoilState"], recoil__WEBPACK_IMPORTED_MODULE_5__["useRecoilState"], react_hook_form__WEBPACK_IMPORTED_MODULE_4__["useForm"]];
});

_c = CheckoutForm;
/* harmony default export */ __webpack_exports__["default"] = (CheckoutForm);

var _c;

$RefreshReg$(_c, "CheckoutForm");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvY2hlY2tvdXQvQ2hlY2tvdXRGb3JtLmpzeCJdLCJuYW1lcyI6WyJDaGVja291dEZvcm0iLCJzZXRGb3JtIiwidXNlU2V0UmVjb2lsU3RhdGUiLCJmb3JtU3RhdGUiLCJ1c2VSZWNvaWxTdGF0ZSIsIndpdGhEZWxpdmVyeSIsImRlbGl2ZXJ5Iiwic2V0RGVsaXZlcnkiLCJ1c2VGb3JtIiwibW9kZSIsInJlZ2lzdGVyIiwiZXJyb3JzIiwiaGFuZGxlU3VibWl0IiwidXNlU3RhdGUiLCJzaG93TW9kYWwiLCJzZXRNb2RhbCIsInZhbGlkYXRpb25zIiwiZ2V0Rm9ybVZhbGlkYXRpb25zIiwib25TdWJtaXQiLCJCaVVzZXIiLCJuYW1lIiwibWVzc2FnZSIsIkJpUGhvbmUiLCJwaG9uZSIsIkJpTWFwIiwiYWRkcmVzcyIsIkJpTWFwQWx0IiwiY2l0eSIsIkJpVGltZSIsInNjaGVkdWxlIiwiQmlDb21tZW50IiwiY29tbWVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBZUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsU0FBU0EsWUFBVCxHQUF3QjtBQUFBOztBQUN0QixNQUFNQyxPQUFPLEdBQUdDLGdFQUFpQixDQUFDQyx1REFBRCxDQUFqQzs7QUFEc0Isd0JBRVVDLDZEQUFjLENBQUNDLDBEQUFELENBRnhCO0FBQUE7QUFBQSxNQUVmQyxRQUZlO0FBQUEsTUFFTEMsV0FGSzs7QUFBQSxpQkFHcUJDLCtEQUFPLENBQUM7QUFBRUMsUUFBSSxFQUFFO0FBQVIsR0FBRCxDQUg1QjtBQUFBLE1BR2RDLFFBSGMsWUFHZEEsUUFIYztBQUFBLE1BR0pDLE1BSEksWUFHSkEsTUFISTtBQUFBLE1BR0lDLFlBSEosWUFHSUEsWUFISjs7QUFBQSxrQkFJUUMsc0RBQVEsQ0FBQyxLQUFELENBSmhCO0FBQUEsTUFJZkMsU0FKZTtBQUFBLE1BSUpDLFFBSkk7O0FBS3RCLE1BQU1DLFdBQVcsR0FBR0MsbUVBQWtCLEVBQXRDOztBQUVBLE1BQU1DLFFBQVEsR0FBRyxTQUFYQSxRQUFXLENBQUNmLFNBQUQsRUFBZTtBQUM5QkYsV0FBTyxDQUFDRSxTQUFELENBQVA7QUFDQVksWUFBUSxDQUFDLElBQUQsQ0FBUjtBQUNELEdBSEQ7O0FBS0EsU0FDRSxtRUFDRSxNQUFDLG1EQUFEO0FBQUssS0FBQyxFQUFFLENBQUMsTUFBRCxFQUFTLEtBQVQsRUFBZ0IsS0FBaEIsRUFBdUIsS0FBdkIsQ0FBUjtBQUF1QyxVQUFNLEVBQUMsYUFBOUM7QUFBNEQsTUFBRSxFQUFDLE9BQS9EO0FBQXVFLEtBQUMsRUFBQyxHQUF6RTtBQUE2RSxNQUFFLEVBQUMsR0FBaEY7QUFBb0YsU0FBSyxFQUFFLENBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxHQUFYLENBQTNGO0FBQTRHLE1BQUUsRUFBRSxDQUFDLEdBQUQsRUFBTSxHQUFOLEVBQVcsR0FBWCxDQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsTUFBQyx1REFBRDtBQUFTLE1BQUUsRUFBQyxJQUFaO0FBQWlCLFFBQUksRUFBQyxJQUF0QjtBQUEyQixhQUFTLEVBQUMsUUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixFQUlFLE1BQUMsb0RBQUQ7QUFBTSxNQUFFLEVBQUMsTUFBVDtBQUFnQixLQUFDLEVBQUMsR0FBbEI7QUFBc0IsYUFBUyxFQUFDLFFBQWhDO0FBQXlDLFlBQVEsRUFBRUgsWUFBWSxDQUFDTSxRQUFELENBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLG9EQUFEO0FBQU0sV0FBTyxFQUFDLFFBQWQ7QUFBdUIsU0FBSyxFQUFDLFFBQTdCO0FBQXNDLE1BQUUsRUFBQyxHQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsTUFBQyx5REFBRDtBQUFXLFdBQU8sRUFBQyxVQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLEVBRUUsTUFBQyxzREFBRDtBQUFRLE1BQUUsRUFBQyxVQUFYO0FBQXNCLFNBQUssRUFBQyxNQUE1QjtBQUFtQyxvQkFBZ0IsTUFBbkQ7QUFBb0QsWUFBUSxFQUFFO0FBQUEsYUFBTVgsV0FBVyxDQUFDLENBQUNELFFBQUYsQ0FBakI7QUFBQSxLQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRkYsQ0FERixFQU1FLE1BQUMsMERBQUQ7QUFBWSxNQUFFLEVBQUMsR0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsTUFBQyxnRUFBRDtBQUFrQixZQUFRLEVBQUUsTUFBQyx5REFBRDtBQUFXLFFBQUUsRUFBRWEscURBQWY7QUFBdUIsVUFBSSxFQUFDLE1BQTVCO0FBQW1DLFdBQUssRUFBQyxXQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFERixFQUVFLE1BQUMscURBQUQ7QUFDRSxRQUFJLEVBQUMsTUFEUDtBQUVFLFFBQUksRUFBQyxNQUZQO0FBR0UsZUFBVyxFQUFDLFdBSGQ7QUFJRSxXQUFPLEVBQUMsUUFKVjtBQUtFLE9BQUcsRUFBRVQsUUFBUSxDQUFDTSxXQUFXLENBQUNJLElBQWIsQ0FMZjtBQU1FLGFBQVMsRUFBRVQsTUFBTSxDQUFDUyxJQUFQLEdBQWMsSUFBZCxHQUFxQixLQU5sQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRkYsQ0FORixFQWlCR1QsTUFBTSxDQUFDUyxJQUFQLElBQ0MsTUFBQyxvREFBRDtBQUFNLE1BQUUsRUFBQyxHQUFUO0FBQWEsWUFBUSxFQUFDLElBQXRCO0FBQTJCLFNBQUssRUFBQyxTQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0dULE1BQU0sQ0FBQ1MsSUFBUCxDQUFZQyxPQURmLENBbEJKLEVBdUJFLE1BQUMsMERBQUQ7QUFBWSxNQUFFLEVBQUMsR0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsTUFBQyxnRUFBRDtBQUFrQixZQUFRLEVBQUUsTUFBQyx5REFBRDtBQUFXLFFBQUUsRUFBRUMsc0RBQWY7QUFBd0IsVUFBSSxFQUFDLE1BQTdCO0FBQW9DLFdBQUssRUFBQyxXQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFERixFQUVFLE1BQUMscURBQUQ7QUFDRSxRQUFJLEVBQUMsT0FEUDtBQUVFLFFBQUksRUFBQyxPQUZQO0FBR0UsZUFBVyxFQUFDLG1CQUhkO0FBSUUsV0FBTyxFQUFDLFFBSlY7QUFLRSxPQUFHLEVBQUVaLFFBQVEsQ0FBQ00sV0FBVyxDQUFDTyxLQUFiLENBTGY7QUFNRSxhQUFTLEVBQUVaLE1BQU0sQ0FBQ1ksS0FBUCxHQUFlLElBQWYsR0FBc0IsS0FObkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUZGLENBdkJGLEVBa0NHWixNQUFNLENBQUNZLEtBQVAsSUFDQyxNQUFDLG9EQUFEO0FBQU0sTUFBRSxFQUFDLEdBQVQ7QUFBYSxZQUFRLEVBQUMsSUFBdEI7QUFBMkIsU0FBSyxFQUFDLFNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDR1osTUFBTSxDQUFDWSxLQUFQLENBQWFGLE9BRGhCLENBbkNKLEVBd0NHZixRQUFRLElBQ1AsbUVBQ0UsTUFBQywwREFBRDtBQUFZLE1BQUUsRUFBQyxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLGdFQUFEO0FBQWtCLFlBQVEsRUFBRSxNQUFDLHlEQUFEO0FBQVcsUUFBRSxFQUFFa0Isb0RBQWY7QUFBc0IsVUFBSSxFQUFDLE1BQTNCO0FBQWtDLFdBQUssRUFBQyxXQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFERixFQUVFLE1BQUMscURBQUQ7QUFDRSxRQUFJLEVBQUMsTUFEUDtBQUVFLFFBQUksRUFBQyxTQUZQO0FBR0UsZUFBVyxFQUFDLGlCQUhkO0FBSUUsV0FBTyxFQUFDLFFBSlY7QUFLRSxPQUFHLEVBQUVkLFFBQVEsQ0FBQ00sV0FBVyxDQUFDUyxPQUFiLENBTGY7QUFNRSxhQUFTLEVBQUVkLE1BQU0sQ0FBQ2MsT0FBUCxHQUFpQixJQUFqQixHQUF3QixLQU5yQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRkYsQ0FERixFQVlHZCxNQUFNLENBQUNjLE9BQVAsSUFDQyxNQUFDLG9EQUFEO0FBQU0sTUFBRSxFQUFDLEdBQVQ7QUFBYSxZQUFRLEVBQUMsSUFBdEI7QUFBMkIsU0FBSyxFQUFDLFNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDR2QsTUFBTSxDQUFDYyxPQUFQLENBQWVKLE9BRGxCLENBYkosRUFrQkUsTUFBQywwREFBRDtBQUFZLE1BQUUsRUFBQyxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLGdFQUFEO0FBQWtCLFlBQVEsRUFBRSxNQUFDLHlEQUFEO0FBQVcsUUFBRSxFQUFFSyx1REFBZjtBQUF5QixVQUFJLEVBQUMsTUFBOUI7QUFBcUMsV0FBSyxFQUFDLFdBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQURGLEVBRUUsTUFBQyxzREFBRDtBQUNFLFdBQU8sRUFBQyxRQURWO0FBRUUsZUFBVyxFQUFDLHlCQUZkO0FBR0UsTUFBRSxFQUFDLE1BSEw7QUFJRSxRQUFJLEVBQUMsTUFKUDtBQUtFLE9BQUcsRUFBRWhCLFFBQVEsQ0FBQ00sV0FBVyxDQUFDVyxJQUFiLENBTGY7QUFNRSxhQUFTLEVBQUVoQixNQUFNLENBQUNnQixJQUFQLEdBQWMsSUFBZCxHQUFxQixLQU5sQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBUUU7QUFBUSxTQUFLLEVBQUMsU0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVJGLEVBU0U7QUFBUSxTQUFLLEVBQUMsU0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVRGLEVBVUU7QUFBUSxTQUFLLEVBQUMsU0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVZGLEVBV0U7QUFBUSxTQUFLLEVBQUMsU0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVhGLENBRkYsQ0FsQkYsRUFrQ0doQixNQUFNLENBQUNnQixJQUFQLElBQ0MsTUFBQyxvREFBRDtBQUFNLE1BQUUsRUFBQyxHQUFUO0FBQWEsWUFBUSxFQUFDLElBQXRCO0FBQTJCLFNBQUssRUFBQyxTQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0doQixNQUFNLENBQUNnQixJQUFQLENBQVlOLE9BRGYsQ0FuQ0osRUF3Q0UsTUFBQywwREFBRDtBQUFZLE1BQUUsRUFBQyxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLGdFQUFEO0FBQWtCLFlBQVEsRUFBRSxNQUFDLHlEQUFEO0FBQVcsUUFBRSxFQUFFTyxxREFBZjtBQUF1QixVQUFJLEVBQUMsTUFBNUI7QUFBbUMsV0FBSyxFQUFDLFdBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQURGLEVBRUUsTUFBQyxzREFBRDtBQUNFLFdBQU8sRUFBQyxRQURWO0FBRUUsZUFBVyxFQUFDLHdCQUZkO0FBR0UsTUFBRSxFQUFDLE1BSEw7QUFJRSxRQUFJLEVBQUMsVUFKUDtBQUtFLE9BQUcsRUFBRWxCLFFBQVEsQ0FBQ00sV0FBVyxDQUFDYSxRQUFiLENBTGY7QUFNRSxhQUFTLEVBQUVsQixNQUFNLENBQUNrQixRQUFQLEdBQWtCLElBQWxCLEdBQXlCLEtBTnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FRRTtBQUFRLFNBQUssRUFBQyxTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUkYsRUFTRTtBQUFRLFNBQUssRUFBQyxTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBVEYsRUFVRTtBQUFRLFNBQUssRUFBQyxTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBVkYsRUFXRTtBQUFRLFNBQUssRUFBQyxTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBWEYsQ0FGRixDQXhDRixFQXdER2xCLE1BQU0sQ0FBQ2tCLFFBQVAsSUFDQyxNQUFDLG9EQUFEO0FBQU0sTUFBRSxFQUFDLEdBQVQ7QUFBYSxZQUFRLEVBQUMsSUFBdEI7QUFBMkIsU0FBSyxFQUFDLFNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDR2xCLE1BQU0sQ0FBQ2tCLFFBQVAsQ0FBZ0JSLE9BRG5CLENBekRKLENBekNKLEVBeUdFLE1BQUMsMERBQUQ7QUFBWSxNQUFFLEVBQUMsR0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsTUFBQyxnRUFBRDtBQUFrQixZQUFRLEVBQUUsTUFBQyx5REFBRDtBQUFXLFFBQUUsRUFBRVMsd0RBQWY7QUFBMEIsVUFBSSxFQUFDLE1BQS9CO0FBQXNDLFdBQUssRUFBQyxXQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFERixFQUVFLE1BQUMscURBQUQ7QUFDRSxRQUFJLEVBQUMsTUFEUDtBQUVFLFFBQUksRUFBQyxTQUZQO0FBR0UsZUFBVyxFQUFDLHNCQUhkO0FBSUUsV0FBTyxFQUFDLFFBSlY7QUFLRSxPQUFHLEVBQUVwQixRQUFRLENBQUNNLFdBQVcsQ0FBQ2UsT0FBYixDQUxmO0FBTUUsYUFBUyxFQUFFcEIsTUFBTSxDQUFDb0IsT0FBUCxHQUFpQixJQUFqQixHQUF3QixLQU5yQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRkYsQ0F6R0YsRUFvSEdwQixNQUFNLENBQUNvQixPQUFQLElBQ0MsTUFBQyxvREFBRDtBQUFNLE1BQUUsRUFBQyxHQUFUO0FBQWEsWUFBUSxFQUFDLElBQXRCO0FBQTJCLFNBQUssRUFBQyxTQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0dwQixNQUFNLENBQUNvQixPQUFQLENBQWVWLE9BRGxCLENBckhKLEVBMEhFLE1BQUMsc0RBQUQ7QUFBUSxRQUFJLEVBQUMsUUFBYjtBQUFzQixLQUFDLEVBQUMsTUFBeEI7QUFBK0IsZ0JBQVksRUFBQyxPQUE1QztBQUFvRCxRQUFJLEVBQUMsSUFBekQ7QUFBOEQsTUFBRSxFQUFDLEdBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMUhGLENBSkYsQ0FERixFQXFJR1AsU0FBUyxJQUFJLE1BQUMsaUVBQUQ7QUFBbUIsYUFBUyxFQUFFQSxTQUE5QjtBQUF5QyxZQUFRLEVBQUVDLFFBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFySWhCLENBREY7QUF5SUQ7O0dBckpRZixZO1VBQ1NFLHdELEVBQ2dCRSxxRCxFQUNXSSx1RDs7O0tBSHBDUixZO0FBdUpNQSwyRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9jaGVja291dC5hZDU0ZGZmMTNjMWZjNTQ1YzY0OC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICBCb3gsXHJcbiAgQnV0dG9uLFxyXG4gIEZsZXgsXHJcbiAgRm9ybUxhYmVsLFxyXG4gIEhlYWRpbmcsXHJcbiAgSW5wdXQsXHJcbiAgSW5wdXRHcm91cCxcclxuICBJbnB1dExlZnRFbGVtZW50LFxyXG4gIFBzZXVkb0JveCxcclxuICBTZWxlY3QsXHJcbiAgU3dpdGNoLFxyXG4gIFRleHQsXHJcbn0gZnJvbSBcIkBjaGFrcmEtdWkvY29yZVwiO1xyXG5cclxuaW1wb3J0IHsgQmlDb21tZW50LCBCaU1hcCwgQmlNYXBBbHQsIEJpUGhvbmUsIEJpVGltZSwgQmlVc2VyIH0gZnJvbSBcInJlYWN0LWljb25zL2JpXCI7XHJcbmltcG9ydCB7IHVzZUZvcm0gfSBmcm9tIFwicmVhY3QtaG9vay1mb3JtXCI7XHJcbmltcG9ydCB7IHVzZVJlY29pbFN0YXRlLCB1c2VTZXRSZWNvaWxTdGF0ZSB9IGZyb20gXCJyZWNvaWxcIjtcclxuaW1wb3J0IHsgZm9ybVN0YXRlLCB3aXRoRGVsaXZlcnkgfSBmcm9tIFwiLi4vLi4vcmVjb2lsL3N0YXRlXCI7XHJcbmltcG9ydCBDb25maXJtQWxlcnRNb2RhbCBmcm9tIFwiLi4vb3RoZXJzL0NvbmZpcm1BbGVydE1vZGFsXCI7XHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IGdldEZvcm1WYWxpZGF0aW9ucyB9IGZyb20gXCIuLi8uLi9oZWxwZXJzXCI7XHJcblxyXG5mdW5jdGlvbiBDaGVja291dEZvcm0oKSB7XHJcbiAgY29uc3Qgc2V0Rm9ybSA9IHVzZVNldFJlY29pbFN0YXRlKGZvcm1TdGF0ZSk7XHJcbiAgY29uc3QgW2RlbGl2ZXJ5LCBzZXREZWxpdmVyeV0gPSB1c2VSZWNvaWxTdGF0ZSh3aXRoRGVsaXZlcnkpO1xyXG4gIGNvbnN0IHsgcmVnaXN0ZXIsIGVycm9ycywgaGFuZGxlU3VibWl0IH0gPSB1c2VGb3JtKHsgbW9kZTogXCJvblRvdWNoZWRcIiB9KTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgdmFsaWRhdGlvbnMgPSBnZXRGb3JtVmFsaWRhdGlvbnMoKTtcclxuXHJcbiAgY29uc3Qgb25TdWJtaXQgPSAoZm9ybVN0YXRlKSA9PiB7XHJcbiAgICBzZXRGb3JtKGZvcm1TdGF0ZSk7XHJcbiAgICBzZXRNb2RhbCh0cnVlKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPEJveCB3PXtbXCIxMDAlXCIsIFwiODAlXCIsIFwiNDYlXCIsIFwiNDAlXCJdfSBoZWlnaHQ9XCJtYXgtY29udGVudFwiIGJnPVwid2hpdGVcIiBwPVwiNFwiIG14PVwiMlwiIG9yZGVyPXtbXCIxXCIsIFwiMVwiLCBcIjBcIl19IG10PXtbXCI2XCIsIFwiNlwiLCBcIjBcIl19PlxyXG4gICAgICAgIDxIZWFkaW5nIGFzPVwiaDNcIiBzaXplPVwibWRcIiB0ZXh0QWxpZ249XCJjZW50ZXJcIj5cclxuICAgICAgICAgIFN1cyBvcGNpb25lc1xyXG4gICAgICAgIDwvSGVhZGluZz5cclxuICAgICAgICA8RmxleCBhcz1cImZvcm1cIiBwPVwiMlwiIGRpcmVjdGlvbj1cImNvbHVtblwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQob25TdWJtaXQpfT5cclxuICAgICAgICAgIDxGbGV4IGp1c3RpZnk9XCJjZW50ZXJcIiBhbGlnbj1cImNlbnRlclwiIG10PVwiNlwiPlxyXG4gICAgICAgICAgICA8Rm9ybUxhYmVsIGh0bWxGb3I9XCJkZWxpdmVyeVwiPkNvbiBkZWxpdmVyeT88L0Zvcm1MYWJlbD5cclxuICAgICAgICAgICAgPFN3aXRjaCBpZD1cImRlbGl2ZXJ5XCIgY29sb3I9XCJ0ZWFsXCIgZGVmYXVsdElzQ2hlY2tlZCBvbkNoYW5nZT17KCkgPT4gc2V0RGVsaXZlcnkoIWRlbGl2ZXJ5KX0gLz5cclxuICAgICAgICAgIDwvRmxleD5cclxuXHJcbiAgICAgICAgICA8SW5wdXRHcm91cCBtdD1cIjRcIj5cclxuICAgICAgICAgICAgPElucHV0TGVmdEVsZW1lbnQgY2hpbGRyZW49ezxQc2V1ZG9Cb3ggYXM9e0JpVXNlcn0gc2l6ZT1cIjI0cHhcIiBjb2xvcj1cImJsdWV4LjQwMFwiIC8+fSAvPlxyXG4gICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgbmFtZT1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVHUgbm9tYnJlXCJcclxuICAgICAgICAgICAgICB2YXJpYW50PVwiZmlsbGVkXCJcclxuICAgICAgICAgICAgICByZWY9e3JlZ2lzdGVyKHZhbGlkYXRpb25zLm5hbWUpfVxyXG4gICAgICAgICAgICAgIGlzSW52YWxpZD17ZXJyb3JzLm5hbWUgPyB0cnVlIDogZmFsc2V9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0lucHV0R3JvdXA+XHJcbiAgICAgICAgICB7ZXJyb3JzLm5hbWUgJiYgKFxyXG4gICAgICAgICAgICA8VGV4dCBhcz1cImlcIiBmb250U2l6ZT1cInhzXCIgY29sb3I9XCJyZWQuNTAwXCI+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5uYW1lLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPElucHV0R3JvdXAgbXQ9XCI2XCI+XHJcbiAgICAgICAgICAgIDxJbnB1dExlZnRFbGVtZW50IGNoaWxkcmVuPXs8UHNldWRvQm94IGFzPXtCaVBob25lfSBzaXplPVwiMjRweFwiIGNvbG9yPVwiYmx1ZXguNDAwXCIgLz59IC8+XHJcbiAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJwaG9uZVwiXHJcbiAgICAgICAgICAgICAgbmFtZT1cInBob25lXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk7Dum1lcm8gQ2VsdWxhclwiXHJcbiAgICAgICAgICAgICAgdmFyaWFudD1cImZpbGxlZFwiXHJcbiAgICAgICAgICAgICAgcmVmPXtyZWdpc3Rlcih2YWxpZGF0aW9ucy5waG9uZSl9XHJcbiAgICAgICAgICAgICAgaXNJbnZhbGlkPXtlcnJvcnMucGhvbmUgPyB0cnVlIDogZmFsc2V9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0lucHV0R3JvdXA+XHJcbiAgICAgICAgICB7ZXJyb3JzLnBob25lICYmIChcclxuICAgICAgICAgICAgPFRleHQgYXM9XCJpXCIgZm9udFNpemU9XCJ4c1wiIGNvbG9yPVwicmVkLjUwMFwiPlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMucGhvbmUubWVzc2FnZX1cclxuICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7ZGVsaXZlcnkgJiYgKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIDxJbnB1dEdyb3VwIG10PVwiNlwiPlxyXG4gICAgICAgICAgICAgICAgPElucHV0TGVmdEVsZW1lbnQgY2hpbGRyZW49ezxQc2V1ZG9Cb3ggYXM9e0JpTWFwfSBzaXplPVwiMjRweFwiIGNvbG9yPVwiYmx1ZXguNDAwXCIgLz59IC8+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU3UgZGlyZWNjacOzblwiXHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJmaWxsZWRcIlxyXG4gICAgICAgICAgICAgICAgICByZWY9e3JlZ2lzdGVyKHZhbGlkYXRpb25zLmFkZHJlc3MpfVxyXG4gICAgICAgICAgICAgICAgICBpc0ludmFsaWQ9e2Vycm9ycy5hZGRyZXNzID8gdHJ1ZSA6IGZhbHNlfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L0lucHV0R3JvdXA+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5hZGRyZXNzICYmIChcclxuICAgICAgICAgICAgICAgIDxUZXh0IGFzPVwiaVwiIGZvbnRTaXplPVwieHNcIiBjb2xvcj1cInJlZC41MDBcIj5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZGRyZXNzLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgPElucHV0R3JvdXAgbXQ9XCI2XCI+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRMZWZ0RWxlbWVudCBjaGlsZHJlbj17PFBzZXVkb0JveCBhcz17QmlNYXBBbHR9IHNpemU9XCIyNHB4XCIgY29sb3I9XCJibHVleC40MDBcIiAvPn0gLz5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImZpbGxlZFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiLS0gRWxpZ2UgdW4gZGlzdHJpdG8gLS1cIlxyXG4gICAgICAgICAgICAgICAgICBwbD1cIjQwcHhcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiY2l0eVwiXHJcbiAgICAgICAgICAgICAgICAgIHJlZj17cmVnaXN0ZXIodmFsaWRhdGlvbnMuY2l0eSl9XHJcbiAgICAgICAgICAgICAgICAgIGlzSW52YWxpZD17ZXJyb3JzLmNpdHkgPyB0cnVlIDogZmFsc2V9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvcHRpb24xXCI+VHJ1amlsbG88L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm9wdGlvbjJcIj5FbCBQb3J2ZW5pcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib3B0aW9uM1wiPkZsb3JlbmNpYSBkZSBNb3JhPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvcHRpb240XCI+TGEgRXNwZXJhbnphPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L0lucHV0R3JvdXA+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5jaXR5ICYmIChcclxuICAgICAgICAgICAgICAgIDxUZXh0IGFzPVwiaVwiIGZvbnRTaXplPVwieHNcIiBjb2xvcj1cInJlZC41MDBcIj5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5jaXR5Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgPElucHV0R3JvdXAgbXQ9XCI2XCI+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRMZWZ0RWxlbWVudCBjaGlsZHJlbj17PFBzZXVkb0JveCBhcz17QmlUaW1lfSBzaXplPVwiMjRweFwiIGNvbG9yPVwiYmx1ZXguNDAwXCIgLz59IC8+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJmaWxsZWRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi0tIEVsaWphIHVuIGhvcmFyaW8gLS1cIlxyXG4gICAgICAgICAgICAgICAgICBwbD1cIjQwcHhcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwic2NoZWR1bGVcIlxyXG4gICAgICAgICAgICAgICAgICByZWY9e3JlZ2lzdGVyKHZhbGlkYXRpb25zLnNjaGVkdWxlKX1cclxuICAgICAgICAgICAgICAgICAgaXNJbnZhbGlkPXtlcnJvcnMuc2NoZWR1bGUgPyB0cnVlIDogZmFsc2V9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvcHRpb24xXCI+TG8gbWFzIHByb250bzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib3B0aW9uMlwiPjA5OjAwIGFtIC0gMTA6MDAgYW08L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm9wdGlvbjNcIj4wMjowMCBwbSAtIDAzOjAwIHBtPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvcHRpb240XCI+MDQ6MDAgcG0gLSAwNTowMCBwbTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9JbnB1dEdyb3VwPlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMuc2NoZWR1bGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgPFRleHQgYXM9XCJpXCIgZm9udFNpemU9XCJ4c1wiIGNvbG9yPVwicmVkLjUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnNjaGVkdWxlLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxJbnB1dEdyb3VwIG10PVwiNlwiPlxyXG4gICAgICAgICAgICA8SW5wdXRMZWZ0RWxlbWVudCBjaGlsZHJlbj17PFBzZXVkb0JveCBhcz17QmlDb21tZW50fSBzaXplPVwiMjRweFwiIGNvbG9yPVwiYmx1ZXguNDAwXCIgLz59IC8+XHJcbiAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICBuYW1lPVwiY29tbWVudFwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDb21lbnRhcmlvIGFkaWNpb25hbFwiXHJcbiAgICAgICAgICAgICAgdmFyaWFudD1cImZpbGxlZFwiXHJcbiAgICAgICAgICAgICAgcmVmPXtyZWdpc3Rlcih2YWxpZGF0aW9ucy5jb21tZW50KX1cclxuICAgICAgICAgICAgICBpc0ludmFsaWQ9e2Vycm9ycy5jb21tZW50ID8gdHJ1ZSA6IGZhbHNlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9JbnB1dEdyb3VwPlxyXG4gICAgICAgICAge2Vycm9ycy5jb21tZW50ICYmIChcclxuICAgICAgICAgICAgPFRleHQgYXM9XCJpXCIgZm9udFNpemU9XCJ4c1wiIGNvbG9yPVwicmVkLjUwMFwiPlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMuY29tbWVudC5tZXNzYWdlfVxyXG4gICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIHc9XCIxMDAlXCIgdmFyaWFudENvbG9yPVwiZ3JlZW5cIiBzaXplPVwibGdcIiBtdD1cIjZcIj5cclxuICAgICAgICAgICAgQ09ORklSTUFSXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L0ZsZXg+XHJcbiAgICAgIDwvQm94PlxyXG5cclxuICAgICAge3Nob3dNb2RhbCAmJiA8Q29uZmlybUFsZXJ0TW9kYWwgc2hvd01vZGFsPXtzaG93TW9kYWx9IHNldE1vZGFsPXtzZXRNb2RhbH0gLz59XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDaGVja291dEZvcm07XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=
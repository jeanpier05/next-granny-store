webpackHotUpdate_N_E("pages/checkout",{

/***/ "./src/components/checkout/OrderItem.jsx":
/*!***********************************************!*\
  !*** ./src/components/checkout/OrderItem.jsx ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return OrderItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @chakra-ui/core */ "./node_modules/@chakra-ui/core/dist/es/index.js");
var _jsxFileName = "E:\\nodesjs\\next-grocery-store\\src\\components\\checkout\\OrderItem.jsx";

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;

function OrderItem(_ref) {
  var item = _ref.item;
  var qty = item.qty,
      title = item.title,
      price = item.price,
      offerPrice = item.offerPrice;
  var itemTotal = (offerPrice ? offerPrice * qty : price * qty).toFixed(2);
  return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Flex"], {
    w: "100%",
    justify: "space-between",
    mt: "4",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 5
    }
  }, __jsx("span", {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 7
    }
  }, __jsx("b", {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 9
    }
  }, qty)), __jsx("span", {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }
  }, "x"), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Text"], {
    w: "70%",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }
  }, title), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Text"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 7
    }
  }, "S/ ", itemTotal));
}
_c = OrderItem;

var _c;

$RefreshReg$(_c, "OrderItem");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvY2hlY2tvdXQvT3JkZXJJdGVtLmpzeCJdLCJuYW1lcyI6WyJPcmRlckl0ZW0iLCJpdGVtIiwicXR5IiwidGl0bGUiLCJwcmljZSIsIm9mZmVyUHJpY2UiLCJpdGVtVG90YWwiLCJ0b0ZpeGVkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUVlLFNBQVNBLFNBQVQsT0FBNkI7QUFBQSxNQUFSQyxJQUFRLFFBQVJBLElBQVE7QUFBQSxNQUNsQ0MsR0FEa0MsR0FDQUQsSUFEQSxDQUNsQ0MsR0FEa0M7QUFBQSxNQUM3QkMsS0FENkIsR0FDQUYsSUFEQSxDQUM3QkUsS0FENkI7QUFBQSxNQUN0QkMsS0FEc0IsR0FDQUgsSUFEQSxDQUN0QkcsS0FEc0I7QUFBQSxNQUNmQyxVQURlLEdBQ0FKLElBREEsQ0FDZkksVUFEZTtBQUcxQyxNQUFNQyxTQUFTLEdBQUcsQ0FBQ0QsVUFBVSxHQUFHQSxVQUFVLEdBQUdILEdBQWhCLEdBQXNCRSxLQUFLLEdBQUdGLEdBQXpDLEVBQThDSyxPQUE5QyxDQUFzRCxDQUF0RCxDQUFsQjtBQUVBLFNBQ0UsTUFBQyxvREFBRDtBQUFNLEtBQUMsRUFBQyxNQUFSO0FBQWUsV0FBTyxFQUFDLGVBQXZCO0FBQXVDLE1BQUUsRUFBQyxHQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBSUwsR0FBSixDQURGLENBREYsRUFJRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSkYsRUFLRSxNQUFDLG9EQUFEO0FBQU0sS0FBQyxFQUFDLEtBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFlQyxLQUFmLENBTEYsRUFPRSxNQUFDLG9EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFBVUcsU0FBVixDQVBGLENBREY7QUFXRDtLQWhCdUJOLFMiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvY2hlY2tvdXQuZWVhZWQwNzM0MWI0MGY1ZTI1MGQuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZsZXgsIFRleHQgfSBmcm9tIFwiQGNoYWtyYS11aS9jb3JlXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBPcmRlckl0ZW0oeyBpdGVtIH0pIHtcclxuICBjb25zdCB7IHF0eSwgdGl0bGUsIHByaWNlLCBvZmZlclByaWNlIH0gPSBpdGVtO1xyXG5cclxuICBjb25zdCBpdGVtVG90YWwgPSAob2ZmZXJQcmljZSA/IG9mZmVyUHJpY2UgKiBxdHkgOiBwcmljZSAqIHF0eSkudG9GaXhlZCgyKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxGbGV4IHc9XCIxMDAlXCIganVzdGlmeT1cInNwYWNlLWJldHdlZW5cIiBtdD1cIjRcIj5cclxuICAgICAgPHNwYW4+XHJcbiAgICAgICAgPGI+e3F0eX08L2I+XHJcbiAgICAgIDwvc3Bhbj5cclxuICAgICAgPHNwYW4+eDwvc3Bhbj5cclxuICAgICAgPFRleHQgdz1cIjcwJVwiPnt0aXRsZX08L1RleHQ+XHJcblxyXG4gICAgICA8VGV4dD5TLyB7aXRlbVRvdGFsfTwvVGV4dD5cclxuICAgIDwvRmxleD5cclxuICApO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=
webpackHotUpdate_N_E("pages/checkout",{

/***/ "./src/pages/checkout.jsx":
/*!********************************!*\
  !*** ./src/pages/checkout.jsx ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @chakra-ui/core */ "./node_modules/@chakra-ui/core/dist/es/index.js");
/* harmony import */ var _components_checkout_CheckoutForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/checkout/CheckoutForm */ "./src/components/checkout/CheckoutForm.jsx");
/* harmony import */ var _components_commons_Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/commons/Footer */ "./src/components/commons/Footer.jsx");
/* harmony import */ var _components_commons_Header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/commons/Header */ "./src/components/commons/Header.jsx");
/* harmony import */ var _components_checkout_OrderDetails__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/checkout/OrderDetails */ "./src/components/checkout/OrderDetails.jsx");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ "./node_modules/next/dist/client/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/recoil.js");
/* harmony import */ var _recoil_state__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../recoil/state */ "./src/recoil/state.js");
var _this = undefined,
    _jsxFileName = "E:\\nodesjs\\next-grocery-store\\src\\pages\\checkout.jsx",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;









var Checkout = function Checkout() {
  _s();

  var total = Object(recoil__WEBPACK_IMPORTED_MODULE_7__["useRecoilValue"])(_recoil_state__WEBPACK_IMPORTED_MODULE_8__["cartTotal"]); //only work in client side

  if ( true && !total) {
    next_router__WEBPACK_IMPORTED_MODULE_6___default.a.replace("/");
    return __jsx(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, __jsx("p", {
      __self: _this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }
    }, "Loading..."));
  }

  return __jsx(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    bg: "gray.100",
    minHeight: "calc(100vh - 50px)",
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 7
    }
  }, __jsx(_components_commons_Header__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 9
    }
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    as: "main",
    py: "8",
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 9
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Heading"], {
    as: "h2",
    size: "xl",
    textAlign: "center",
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 11
    }
  }, "PROCESAR PEDIDO"), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Flex"], {
    w: ["100%", "80%", "90%", "80%"],
    mx: "auto",
    justify: "center",
    mt: "8",
    wrap: "wrap",
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 11
    }
  }, __jsx(_components_checkout_CheckoutForm__WEBPACK_IMPORTED_MODULE_2__["default"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 13
    }
  }), __jsx(_components_checkout_OrderDetails__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 13
    }
  })))), __jsx(_components_commons_Footer__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 7
    }
  }));
};

_s(Checkout, "G3P2YDGPjfTXEo/UBBgzh/or3uQ=", false, function () {
  return [recoil__WEBPACK_IMPORTED_MODULE_7__["useRecoilValue"]];
});

_c = Checkout;
/* harmony default export */ __webpack_exports__["default"] = (Checkout);

var _c;

$RefreshReg$(_c, "Checkout");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3BhZ2VzL2NoZWNrb3V0LmpzeCJdLCJuYW1lcyI6WyJDaGVja291dCIsInRvdGFsIiwidXNlUmVjb2lsVmFsdWUiLCJjYXJ0VG90YWwiLCJSb3V0ZXIiLCJyZXBsYWNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxJQUFNQSxRQUFRLEdBQUcsU0FBWEEsUUFBVyxHQUFNO0FBQUE7O0FBQ3JCLE1BQU1DLEtBQUssR0FBR0MsNkRBQWMsQ0FBQ0MsdURBQUQsQ0FBNUIsQ0FEcUIsQ0FHckI7O0FBQ0EsTUFBSSxTQUFpQyxDQUFDRixLQUF0QyxFQUE2QztBQUMzQ0csc0RBQU0sQ0FBQ0MsT0FBUCxDQUFlLEdBQWY7QUFDQSxXQUNFLG1FQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsQ0FERjtBQUtEOztBQUVELFNBQ0UsbUVBQ0UsTUFBQyxtREFBRDtBQUFLLE1BQUUsRUFBQyxVQUFSO0FBQW1CLGFBQVMsRUFBQyxvQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFLE1BQUMsa0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQURGLEVBR0UsTUFBQyxtREFBRDtBQUFLLE1BQUUsRUFBQyxNQUFSO0FBQWUsTUFBRSxFQUFDLEdBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLHVEQUFEO0FBQVMsTUFBRSxFQUFDLElBQVo7QUFBaUIsUUFBSSxFQUFDLElBQXRCO0FBQTJCLGFBQVMsRUFBQyxRQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLEVBS0UsTUFBQyxvREFBRDtBQUFNLEtBQUMsRUFBRSxDQUFDLE1BQUQsRUFBUyxLQUFULEVBQWdCLEtBQWhCLEVBQXVCLEtBQXZCLENBQVQ7QUFBd0MsTUFBRSxFQUFDLE1BQTNDO0FBQWtELFdBQU8sRUFBQyxRQUExRDtBQUFtRSxNQUFFLEVBQUMsR0FBdEU7QUFBMEUsUUFBSSxFQUFDLE1BQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLHlFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFERixFQUVFLE1BQUMseUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUZGLENBTEYsQ0FIRixDQURGLEVBZUUsTUFBQyxrRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZkYsQ0FERjtBQW1CRCxDQWhDRDs7R0FBTUwsUTtVQUNVRSxxRDs7O0tBRFZGLFE7QUFrQ1NBLHVFQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2NoZWNrb3V0LmY0MmIwMjY3MTZhYmIxYzY5ZWM3LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3gsIEZsZXgsIEhlYWRpbmcgfSBmcm9tIFwiQGNoYWtyYS11aS9jb3JlXCI7XHJcbmltcG9ydCBDaGVja291dEZvcm0gZnJvbSBcIi4uL2NvbXBvbmVudHMvY2hlY2tvdXQvQ2hlY2tvdXRGb3JtXCI7XHJcbmltcG9ydCBGb290ZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvY29tbW9ucy9Gb290ZXJcIjtcclxuaW1wb3J0IEhlYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9jb21tb25zL0hlYWRlclwiO1xyXG5pbXBvcnQgT3JkZXJEZXRhaWxzIGZyb20gXCIuLi9jb21wb25lbnRzL2NoZWNrb3V0L09yZGVyRGV0YWlsc1wiO1xyXG5pbXBvcnQgUm91dGVyIGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5pbXBvcnQgeyB1c2VSZWNvaWxWYWx1ZSB9IGZyb20gXCJyZWNvaWxcIjtcclxuaW1wb3J0IHsgY2FydFRvdGFsIH0gZnJvbSBcIi4uL3JlY29pbC9zdGF0ZVwiO1xyXG5cclxuY29uc3QgQ2hlY2tvdXQgPSAoKSA9PiB7XHJcbiAgY29uc3QgdG90YWwgPSB1c2VSZWNvaWxWYWx1ZShjYXJ0VG90YWwpO1xyXG5cclxuICAvL29ubHkgd29yayBpbiBjbGllbnQgc2lkZVxyXG4gIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmICF0b3RhbCkge1xyXG4gICAgUm91dGVyLnJlcGxhY2UoXCIvXCIpO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPD5cclxuICAgICAgICA8cD5Mb2FkaW5nLi4uPC9wPlxyXG4gICAgICA8Lz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPEJveCBiZz1cImdyYXkuMTAwXCIgbWluSGVpZ2h0PVwiY2FsYygxMDB2aCAtIDUwcHgpXCI+XHJcbiAgICAgICAgPEhlYWRlciAvPlxyXG5cclxuICAgICAgICA8Qm94IGFzPVwibWFpblwiIHB5PVwiOFwiPlxyXG4gICAgICAgICAgPEhlYWRpbmcgYXM9XCJoMlwiIHNpemU9XCJ4bFwiIHRleHRBbGlnbj1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICBQUk9DRVNBUiBQRURJRE9cclxuICAgICAgICAgIDwvSGVhZGluZz5cclxuXHJcbiAgICAgICAgICA8RmxleCB3PXtbXCIxMDAlXCIsIFwiODAlXCIsIFwiOTAlXCIsIFwiODAlXCJdfSBteD1cImF1dG9cIiBqdXN0aWZ5PVwiY2VudGVyXCIgbXQ9XCI4XCIgd3JhcD1cIndyYXBcIj5cclxuICAgICAgICAgICAgPENoZWNrb3V0Rm9ybSAvPlxyXG4gICAgICAgICAgICA8T3JkZXJEZXRhaWxzIC8+XHJcbiAgICAgICAgICA8L0ZsZXg+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICAgIDwvQm94PlxyXG4gICAgICA8Rm9vdGVyIC8+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2hlY2tvdXQ7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=
webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/cart/CartList.jsx":
/*!******************************************!*\
  !*** ./src/components/cart/CartList.jsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @chakra-ui/core */ "./node_modules/@chakra-ui/core/dist/es/index.js");
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/recoil.js");
/* harmony import */ var _recoil_state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../recoil/state */ "./src/recoil/state.js");
/* harmony import */ var _CartItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./CartItem */ "./src/components/cart/CartItem.jsx");
var _jsxFileName = "E:\\nodesjs\\next-grocery-store\\src\\components\\cart\\CartList.jsx",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;





function CartList() {
  _s();

  var _this = this;

  var cartItems = Object(recoil__WEBPACK_IMPORTED_MODULE_2__["useRecoilValue"])(_recoil_state__WEBPACK_IMPORTED_MODULE_3__["cart"]);

  if (!Object.keys(cartItems).length) {
    return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Alert"], {
      status: "info",
      variant: "solid",
      flexDirection: "column",
      justifyContent: "center",
      textAlign: "center",
      height: "200px",
      mt: "8",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 11,
        columnNumber: 7
      }
    }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["AlertIcon"], {
      size: "40px",
      mr: 0,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }
    }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["AlertTitle"], {
      mt: 4,
      mb: 1,
      fontSize: "lg",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }
    }, "\xA1A\xFAn no se han a\xF1adido art\xEDculos!"), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["AlertDescription"], {
      maxWidth: "sm",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 9
      }
    }, "Lorem ipsum dolor sit amet consectetur adipisicing elit"));
  }

  return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Flex"], {
    direction: "column",
    align: "center",
    w: "100%",
    mt: "4",
    overflowY: "auto",
    h: "calc(100% - 190px)",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 5
    }
  }, Object.values(cartItems).map(function (item) {
    return __jsx(_CartItem__WEBPACK_IMPORTED_MODULE_4__["default"], {
      item: item,
      key: item.id,
      __self: _this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 9
      }
    });
  }));
}

_s(CartList, "br7xyg/fa2R/VuKqESx4qphElHQ=", false, function () {
  return [recoil__WEBPACK_IMPORTED_MODULE_2__["useRecoilValue"]];
});

_c = CartList;
/* harmony default export */ __webpack_exports__["default"] = (CartList);

var _c;

$RefreshReg$(_c, "CartList");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvY2FydC9DYXJ0TGlzdC5qc3giXSwibmFtZXMiOlsiQ2FydExpc3QiLCJjYXJ0SXRlbXMiLCJ1c2VSZWNvaWxWYWx1ZSIsImNhcnQiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwidmFsdWVzIiwibWFwIiwiaXRlbSIsImlkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsU0FBU0EsUUFBVCxHQUFvQjtBQUFBOztBQUFBOztBQUNsQixNQUFNQyxTQUFTLEdBQUdDLDZEQUFjLENBQUNDLGtEQUFELENBQWhDOztBQUVBLE1BQUksQ0FBQ0MsTUFBTSxDQUFDQyxJQUFQLENBQVlKLFNBQVosRUFBdUJLLE1BQTVCLEVBQW9DO0FBQ2xDLFdBQ0UsTUFBQyxxREFBRDtBQUFPLFlBQU0sRUFBQyxNQUFkO0FBQXFCLGFBQU8sRUFBQyxPQUE3QjtBQUFxQyxtQkFBYSxFQUFDLFFBQW5EO0FBQTRELG9CQUFjLEVBQUMsUUFBM0U7QUFBb0YsZUFBUyxFQUFDLFFBQTlGO0FBQXVHLFlBQU0sRUFBQyxPQUE5RztBQUFzSCxRQUFFLEVBQUMsR0FBekg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUNFLE1BQUMseURBQUQ7QUFBVyxVQUFJLEVBQUMsTUFBaEI7QUFBdUIsUUFBRSxFQUFFLENBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFERixFQUVFLE1BQUMsMERBQUQ7QUFBWSxRQUFFLEVBQUUsQ0FBaEI7QUFBbUIsUUFBRSxFQUFFLENBQXZCO0FBQTBCLGNBQVEsRUFBQyxJQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVEQUZGLEVBS0UsTUFBQyxnRUFBRDtBQUFrQixjQUFRLEVBQUMsSUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpRUFMRixDQURGO0FBU0Q7O0FBRUQsU0FDRSxNQUFDLG9EQUFEO0FBQU0sYUFBUyxFQUFDLFFBQWhCO0FBQXlCLFNBQUssRUFBQyxRQUEvQjtBQUF3QyxLQUFDLEVBQUMsTUFBMUM7QUFBaUQsTUFBRSxFQUFDLEdBQXBEO0FBQXdELGFBQVMsRUFBQyxNQUFsRTtBQUF5RSxLQUFDLEVBQUMsb0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDR0YsTUFBTSxDQUFDRyxNQUFQLENBQWNOLFNBQWQsRUFBeUJPLEdBQXpCLENBQTZCLFVBQUNDLElBQUQ7QUFBQSxXQUM1QixNQUFDLGlEQUFEO0FBQVUsVUFBSSxFQUFFQSxJQUFoQjtBQUFzQixTQUFHLEVBQUVBLElBQUksQ0FBQ0MsRUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUQ0QjtBQUFBLEdBQTdCLENBREgsQ0FERjtBQU9EOztHQXRCUVYsUTtVQUNXRSxxRDs7O0tBRFhGLFE7QUF3Qk1BLHVFQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LjEwZDRkMmIyNWFiZDMxMThhNjIxLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBbGVydCwgQWxlcnREZXNjcmlwdGlvbiwgQWxlcnRJY29uLCBBbGVydFRpdGxlLCBGbGV4IH0gZnJvbSBcIkBjaGFrcmEtdWkvY29yZVwiO1xyXG5pbXBvcnQgeyB1c2VSZWNvaWxWYWx1ZSB9IGZyb20gXCJyZWNvaWxcIjtcclxuaW1wb3J0IHsgY2FydCB9IGZyb20gXCIuLi8uLi9yZWNvaWwvc3RhdGVcIjtcclxuaW1wb3J0IENhcnRJdGVtIGZyb20gXCIuL0NhcnRJdGVtXCI7XHJcblxyXG5mdW5jdGlvbiBDYXJ0TGlzdCgpIHtcclxuICBjb25zdCBjYXJ0SXRlbXMgPSB1c2VSZWNvaWxWYWx1ZShjYXJ0KTtcclxuXHJcbiAgaWYgKCFPYmplY3Qua2V5cyhjYXJ0SXRlbXMpLmxlbmd0aCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPEFsZXJ0IHN0YXR1cz1cImluZm9cIiB2YXJpYW50PVwic29saWRcIiBmbGV4RGlyZWN0aW9uPVwiY29sdW1uXCIganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIiB0ZXh0QWxpZ249XCJjZW50ZXJcIiBoZWlnaHQ9XCIyMDBweFwiIG10PVwiOFwiPlxyXG4gICAgICAgIDxBbGVydEljb24gc2l6ZT1cIjQwcHhcIiBtcj17MH0gLz5cclxuICAgICAgICA8QWxlcnRUaXRsZSBtdD17NH0gbWI9ezF9IGZvbnRTaXplPVwibGdcIj5cclxuICAgICAgICDCoUHDum4gbm8gc2UgaGFuIGHDsWFkaWRvIGFydMOtY3Vsb3MhXHJcbiAgICAgICAgPC9BbGVydFRpdGxlPlxyXG4gICAgICAgIDxBbGVydERlc2NyaXB0aW9uIG1heFdpZHRoPVwic21cIj5Mb3JlbSBpcHN1bSBkb2xvciBzaXQgYW1ldCBjb25zZWN0ZXR1ciBhZGlwaXNpY2luZyBlbGl0PC9BbGVydERlc2NyaXB0aW9uPlxyXG4gICAgICA8L0FsZXJ0PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8RmxleCBkaXJlY3Rpb249XCJjb2x1bW5cIiBhbGlnbj1cImNlbnRlclwiIHc9XCIxMDAlXCIgbXQ9XCI0XCIgb3ZlcmZsb3dZPVwiYXV0b1wiIGg9XCJjYWxjKDEwMCUgLSAxOTBweClcIj5cclxuICAgICAge09iamVjdC52YWx1ZXMoY2FydEl0ZW1zKS5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICA8Q2FydEl0ZW0gaXRlbT17aXRlbX0ga2V5PXtpdGVtLmlkfSAvPlxyXG4gICAgICApKX1cclxuICAgIDwvRmxleD5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDYXJ0TGlzdDtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==
webpackHotUpdate_N_E("pages/index",{

/***/ "./src/helpers.js":
/*!************************!*\
  !*** ./src/helpers.js ***!
  \************************/
/*! exports provided: fetcher, getFormValidations, getWspUrl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetcher", function() { return fetcher; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFormValidations", function() { return getFormValidations; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWspUrl", function() { return getWspUrl; });
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! isomorphic-unfetch */ "./node_modules/next/dist/build/polyfills/fetch/index.js");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var nanoid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! nanoid */ "./node_modules/nanoid/index.browser.js");

 //fetcher

var fetcher = function fetcher(url) {
  return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default()(url).then(function (r) {
    return r.json();
  });
};
var getFormValidations = function getFormValidations() {
  return {
    //name
    name: {
      required: {
        value: true,
        message: "Nombre es Requerido"
      },
      maxLength: {
        value: 40,
        message: "Maximo tamaño 40 caracteres"
      },
      minLength: {
        value: 5,
        message: "Minimo tamaño 5 caracteres"
      },
      pattern: {
        value: /^[A-Za-zñÑ ]{5,20}$/,
        message: "Nombre Incorrecto"
      }
    },
    //phone
    phone: {
      required: {
        value: true,
        message: "Celular es Requerido"
      },
      maxLength: {
        value: 20,
        message: "Maximo tamaño 20 caracteres"
      },
      minLength: {
        value: 5,
        message: "Minimo tamaño 5 caracteres"
      },
      pattern: {
        value: /^[0-9]{5,20}$/,
        message: "Icorrect Phone"
      }
    },
    //address
    address: {
      required: {
        value: true,
        message: "Address is required"
      },
      maxLength: {
        value: 20,
        message: "Max Length 20 chars"
      },
      minLength: {
        value: 5,
        message: "Min Length 5 chars"
      },
      pattern: {
        value: /^[0-9a-zA-Z ]{5,20}$/,
        message: "Icorrect Address"
      }
    },
    //city
    city: {
      required: {
        value: true,
        message: "City is required"
      }
    },
    //schedule
    schedule: {
      required: {
        value: true,
        message: "Schedule is required"
      }
    },
    //extra comment
    comment: {
      maxLength: {
        value: 25,
        message: "Max Length 25 chars"
      }
    }
  };
}; //wsp url creator

function getWspUrl(orderData) {
  var N = "000000000";
  var ID = Object(nanoid__WEBPACK_IMPORTED_MODULE_1__["nanoid"])(8);
  var cartItems = orderData.cartItems,
      subTotal = orderData.subTotal,
      withDelivery = orderData.withDelivery,
      shippingCost = orderData.shippingCost,
      total = orderData.total,
      formData = orderData.formData;
  var name = formData.name,
      phone = formData.phone,
      address = formData.address,
      city = formData.city,
      schedule = formData.schedule,
      comment = formData.comment;
  var cartListforUrl = "";
  {
    Object.values(cartItems).forEach(function (item) {
      var itemTotal = (item.offerPrice ? item.offerPrice * item.qty : item.price * item.qty).toFixed(2);
      cartListforUrl += "%0A%0A - *(".concat(item.qty, ")* ").concat(item.title, " --> _*$").concat(itemTotal, "*_");
    });
  }
  var WSP_URL = "https://api.whatsapp.com/send/?phone=".concat(N, "&text=%2A", "Order", "%3A%2A%20").concat(ID, "%0A%0A%2A", "Client", "%3A%2A%20").concat(name, "%0A%0A%2A", "Phone", "%3A%2A%20").concat(phone, "%0A%0A%2A").concat(withDelivery ? "Address" + "%3A%2A%20" + address + " %0A%0A%2A" : "").concat(withDelivery ? "City" + "%3A%2A%20" + city + "%0A%0A%2A" : "").concat(withDelivery ? "Schedule" + "%3A%2A%20" + schedule + "%0A%0A%2A" : "").concat(comment ? "Comment" + "%3A%2A%20" + comment + "%0A%0A%2A" : "", "Items List", "%3A%2A").concat(cartListforUrl, "%0A%0A%2A").concat(withDelivery ? "Sub Total" + "%3A%2A%20$" + subTotal + " %0A%0A%2A" : "").concat(withDelivery ? "Delivery Fee" + "%3A%2A%20$" + shippingCost + " %0A%0A%2A" : "", "Total", "%3A%2A%20").concat(total, "%0A%0A");
  return WSP_URL;
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2hlbHBlcnMuanMiXSwibmFtZXMiOlsiZmV0Y2hlciIsInVybCIsImZldGNoIiwidGhlbiIsInIiLCJqc29uIiwiZ2V0Rm9ybVZhbGlkYXRpb25zIiwibmFtZSIsInJlcXVpcmVkIiwidmFsdWUiLCJtZXNzYWdlIiwibWF4TGVuZ3RoIiwibWluTGVuZ3RoIiwicGF0dGVybiIsInBob25lIiwiYWRkcmVzcyIsImNpdHkiLCJzY2hlZHVsZSIsImNvbW1lbnQiLCJnZXRXc3BVcmwiLCJvcmRlckRhdGEiLCJOIiwicHJvY2VzcyIsIklEIiwibmFub2lkIiwiY2FydEl0ZW1zIiwic3ViVG90YWwiLCJ3aXRoRGVsaXZlcnkiLCJzaGlwcGluZ0Nvc3QiLCJ0b3RhbCIsImZvcm1EYXRhIiwiY2FydExpc3Rmb3JVcmwiLCJPYmplY3QiLCJ2YWx1ZXMiLCJmb3JFYWNoIiwiaXRlbSIsIml0ZW1Ub3RhbCIsIm9mZmVyUHJpY2UiLCJxdHkiLCJwcmljZSIsInRvRml4ZWQiLCJ0aXRsZSIsIldTUF9VUkwiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0NBR0E7O0FBQ08sSUFBTUEsT0FBTyxHQUFHLFNBQVZBLE9BQVUsQ0FBQ0MsR0FBRDtBQUFBLFNBQVNDLHlEQUFLLENBQUNELEdBQUQsQ0FBTCxDQUFXRSxJQUFYLENBQWdCLFVBQUNDLENBQUQ7QUFBQSxXQUFPQSxDQUFDLENBQUNDLElBQUYsRUFBUDtBQUFBLEdBQWhCLENBQVQ7QUFBQSxDQUFoQjtBQUVBLElBQU1DLGtCQUFrQixHQUFHLFNBQXJCQSxrQkFBcUIsR0FBTTtBQUN0QyxTQUFPO0FBQ0w7QUFDQUMsUUFBSSxFQUFFO0FBQ0pDLGNBQVEsRUFBRTtBQUNSQyxhQUFLLEVBQUUsSUFEQztBQUVSQyxlQUFPLEVBQUU7QUFGRCxPQUROO0FBS0pDLGVBQVMsRUFBRTtBQUNURixhQUFLLEVBQUUsRUFERTtBQUVUQyxlQUFPLEVBQUU7QUFGQSxPQUxQO0FBU0pFLGVBQVMsRUFBRTtBQUNUSCxhQUFLLEVBQUUsQ0FERTtBQUVUQyxlQUFPLEVBQUU7QUFGQSxPQVRQO0FBYUpHLGFBQU8sRUFBRTtBQUNQSixhQUFLLEVBQUUscUJBREE7QUFFUEMsZUFBTyxFQUFFO0FBRkY7QUFiTCxLQUZEO0FBcUJMO0FBQ0FJLFNBQUssRUFBRTtBQUNMTixjQUFRLEVBQUU7QUFDUkMsYUFBSyxFQUFFLElBREM7QUFFUkMsZUFBTyxFQUFFO0FBRkQsT0FETDtBQUtMQyxlQUFTLEVBQUU7QUFDVEYsYUFBSyxFQUFFLEVBREU7QUFFVEMsZUFBTyxFQUFFO0FBRkEsT0FMTjtBQVNMRSxlQUFTLEVBQUU7QUFDVEgsYUFBSyxFQUFFLENBREU7QUFFVEMsZUFBTyxFQUFFO0FBRkEsT0FUTjtBQWFMRyxhQUFPLEVBQUU7QUFDUEosYUFBSyxFQUFFLGVBREE7QUFFUEMsZUFBTyxFQUFFO0FBRkY7QUFiSixLQXRCRjtBQXdDTDtBQUNBSyxXQUFPLEVBQUU7QUFDUFAsY0FBUSxFQUFFO0FBQ1JDLGFBQUssRUFBRSxJQURDO0FBRVJDLGVBQU8sRUFBRTtBQUZELE9BREg7QUFLUEMsZUFBUyxFQUFFO0FBQ1RGLGFBQUssRUFBRSxFQURFO0FBRVRDLGVBQU8sRUFBRTtBQUZBLE9BTEo7QUFTUEUsZUFBUyxFQUFFO0FBQ1RILGFBQUssRUFBRSxDQURFO0FBRVRDLGVBQU8sRUFBRTtBQUZBLE9BVEo7QUFhUEcsYUFBTyxFQUFFO0FBQ1BKLGFBQUssRUFBRSxzQkFEQTtBQUVQQyxlQUFPLEVBQUU7QUFGRjtBQWJGLEtBekNKO0FBMkRMO0FBQ0FNLFFBQUksRUFBRTtBQUNKUixjQUFRLEVBQUU7QUFDUkMsYUFBSyxFQUFFLElBREM7QUFFUkMsZUFBTyxFQUFFO0FBRkQ7QUFETixLQTVERDtBQWtFTDtBQUNBTyxZQUFRLEVBQUU7QUFDUlQsY0FBUSxFQUFFO0FBQ1JDLGFBQUssRUFBRSxJQURDO0FBRVJDLGVBQU8sRUFBRTtBQUZEO0FBREYsS0FuRUw7QUF5RUw7QUFDQVEsV0FBTyxFQUFFO0FBQ1BQLGVBQVMsRUFBRTtBQUNURixhQUFLLEVBQUUsRUFERTtBQUVUQyxlQUFPLEVBQUU7QUFGQTtBQURKO0FBMUVKLEdBQVA7QUFpRkQsQ0FsRk0sQyxDQW9GUDs7QUFDTyxTQUFTUyxTQUFULENBQW1CQyxTQUFuQixFQUE4QjtBQUNuQyxNQUFNQyxDQUFDLEdBQUdDLFdBQVY7QUFDQSxNQUFNQyxFQUFFLEdBQUdDLHFEQUFNLENBQUMsQ0FBRCxDQUFqQjtBQUZtQyxNQUczQkMsU0FIMkIsR0FHMENMLFNBSDFDLENBRzNCSyxTQUgyQjtBQUFBLE1BR2hCQyxRQUhnQixHQUcwQ04sU0FIMUMsQ0FHaEJNLFFBSGdCO0FBQUEsTUFHTkMsWUFITSxHQUcwQ1AsU0FIMUMsQ0FHTk8sWUFITTtBQUFBLE1BR1FDLFlBSFIsR0FHMENSLFNBSDFDLENBR1FRLFlBSFI7QUFBQSxNQUdzQkMsS0FIdEIsR0FHMENULFNBSDFDLENBR3NCUyxLQUh0QjtBQUFBLE1BRzZCQyxRQUg3QixHQUcwQ1YsU0FIMUMsQ0FHNkJVLFFBSDdCO0FBQUEsTUFJM0J2QixJQUoyQixHQUl1QnVCLFFBSnZCLENBSTNCdkIsSUFKMkI7QUFBQSxNQUlyQk8sS0FKcUIsR0FJdUJnQixRQUp2QixDQUlyQmhCLEtBSnFCO0FBQUEsTUFJZEMsT0FKYyxHQUl1QmUsUUFKdkIsQ0FJZGYsT0FKYztBQUFBLE1BSUxDLElBSkssR0FJdUJjLFFBSnZCLENBSUxkLElBSks7QUFBQSxNQUlDQyxRQUpELEdBSXVCYSxRQUp2QixDQUlDYixRQUpEO0FBQUEsTUFJV0MsT0FKWCxHQUl1QlksUUFKdkIsQ0FJV1osT0FKWDtBQU1uQyxNQUFJYSxjQUFjLEdBQUcsRUFBckI7QUFFQTtBQUNFQyxVQUFNLENBQUNDLE1BQVAsQ0FBY1IsU0FBZCxFQUF5QlMsT0FBekIsQ0FBaUMsVUFBQ0MsSUFBRCxFQUFVO0FBQ3pDLFVBQU1DLFNBQVMsR0FBRyxDQUFDRCxJQUFJLENBQUNFLFVBQUwsR0FBa0JGLElBQUksQ0FBQ0UsVUFBTCxHQUFrQkYsSUFBSSxDQUFDRyxHQUF6QyxHQUErQ0gsSUFBSSxDQUFDSSxLQUFMLEdBQWFKLElBQUksQ0FBQ0csR0FBbEUsRUFBdUVFLE9BQXZFLENBQStFLENBQS9FLENBQWxCO0FBQ0FULG9CQUFjLHlCQUFrQkksSUFBSSxDQUFDRyxHQUF2QixnQkFBZ0NILElBQUksQ0FBQ00sS0FBckMscUJBQXFETCxTQUFyRCxPQUFkO0FBQ0QsS0FIRDtBQUlEO0FBRUQsTUFBTU0sT0FBTyxrREFBMkNyQixDQUEzQyxlQUF3RCxPQUF4RCxzQkFBMkVFLEVBQTNFLGVBQXlGLFFBQXpGLHNCQUE2R2hCLElBQTdHLGVBQTZILE9BQTdILHNCQUFnSk8sS0FBaEosc0JBQ1hhLFlBQVksR0FBRyxZQUFZLFdBQVosR0FBMEJaLE9BQTFCLEdBQW9DLFlBQXZDLEdBQXNELEVBRHZELFNBRVZZLFlBQVksR0FBRyxTQUFTLFdBQVQsR0FBdUJYLElBQXZCLEdBQThCLFdBQWpDLEdBQStDLEVBRmpELFNBR1hXLFlBQVksR0FBRyxhQUFhLFdBQWIsR0FBMkJWLFFBQTNCLEdBQXNDLFdBQXpDLEdBQXVELEVBSHhELFNBSVZDLE9BQU8sR0FBRyxZQUFZLFdBQVosR0FBMEJBLE9BQTFCLEdBQW9DLFdBQXZDLEdBQXFELEVBSmxELEVBSXVELFlBSnZELG1CQUk0RWEsY0FKNUUsc0JBS1hKLFlBQVksR0FBRyxjQUFjLFlBQWQsR0FBNkJELFFBQTdCLEdBQXdDLFlBQTNDLEdBQTBELEVBTDNELFNBTVZDLFlBQVksR0FBRyxpQkFBaUIsWUFBakIsR0FBZ0NDLFlBQWhDLEdBQStDLFlBQWxELEdBQWlFLEVBTm5FLEVBTXdFLE9BTnhFLHNCQU0yRkMsS0FOM0YsV0FBYjtBQVFBLFNBQU9hLE9BQVA7QUFDRCIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC41NDM0ZWY4YWRlY2E5YzNlZjczNS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGZldGNoIGZyb20gXCJpc29tb3JwaGljLXVuZmV0Y2hcIjtcclxuaW1wb3J0IHsgbmFub2lkIH0gZnJvbSBcIm5hbm9pZFwiO1xyXG5cclxuLy9mZXRjaGVyXHJcbmV4cG9ydCBjb25zdCBmZXRjaGVyID0gKHVybCkgPT4gZmV0Y2godXJsKS50aGVuKChyKSA9PiByLmpzb24oKSk7XHJcblxyXG5leHBvcnQgY29uc3QgZ2V0Rm9ybVZhbGlkYXRpb25zID0gKCkgPT4ge1xyXG4gIHJldHVybiB7XHJcbiAgICAvL25hbWVcclxuICAgIG5hbWU6IHtcclxuICAgICAgcmVxdWlyZWQ6IHtcclxuICAgICAgICB2YWx1ZTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIk5vbWJyZSBlcyBSZXF1ZXJpZG9cIixcclxuICAgICAgfSxcclxuICAgICAgbWF4TGVuZ3RoOiB7XHJcbiAgICAgICAgdmFsdWU6IDQwLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiTWF4aW1vIHRhbWHDsW8gNDAgY2FyYWN0ZXJlc1wiLFxyXG4gICAgICB9LFxyXG4gICAgICBtaW5MZW5ndGg6IHtcclxuICAgICAgICB2YWx1ZTogNSxcclxuICAgICAgICBtZXNzYWdlOiBcIk1pbmltbyB0YW1hw7FvIDUgY2FyYWN0ZXJlc1wiLFxyXG4gICAgICB9LFxyXG4gICAgICBwYXR0ZXJuOiB7XHJcbiAgICAgICAgdmFsdWU6IC9eW0EtWmEtesOxw5EgXXs1LDIwfSQvLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiTm9tYnJlIEluY29ycmVjdG9cIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcblxyXG4gICAgLy9waG9uZVxyXG4gICAgcGhvbmU6IHtcclxuICAgICAgcmVxdWlyZWQ6IHtcclxuICAgICAgICB2YWx1ZTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkNlbHVsYXIgZXMgUmVxdWVyaWRvXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIG1heExlbmd0aDoge1xyXG4gICAgICAgIHZhbHVlOiAyMCxcclxuICAgICAgICBtZXNzYWdlOiBcIk1heGltbyB0YW1hw7FvIDIwIGNhcmFjdGVyZXNcIixcclxuICAgICAgfSxcclxuICAgICAgbWluTGVuZ3RoOiB7XHJcbiAgICAgICAgdmFsdWU6IDUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJNaW5pbW8gdGFtYcOxbyA1IGNhcmFjdGVyZXNcIixcclxuICAgICAgfSxcclxuICAgICAgcGF0dGVybjoge1xyXG4gICAgICAgIHZhbHVlOiAvXlswLTldezUsMjB9JC8sXHJcbiAgICAgICAgbWVzc2FnZTogXCJJY29ycmVjdCBQaG9uZVwiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIC8vYWRkcmVzc1xyXG4gICAgYWRkcmVzczoge1xyXG4gICAgICByZXF1aXJlZDoge1xyXG4gICAgICAgIHZhbHVlOiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiQWRkcmVzcyBpcyByZXF1aXJlZFwiLFxyXG4gICAgICB9LFxyXG4gICAgICBtYXhMZW5ndGg6IHtcclxuICAgICAgICB2YWx1ZTogMjAsXHJcbiAgICAgICAgbWVzc2FnZTogXCJNYXggTGVuZ3RoIDIwIGNoYXJzXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIG1pbkxlbmd0aDoge1xyXG4gICAgICAgIHZhbHVlOiA1LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiTWluIExlbmd0aCA1IGNoYXJzXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHBhdHRlcm46IHtcclxuICAgICAgICB2YWx1ZTogL15bMC05YS16QS1aIF17NSwyMH0kLyxcclxuICAgICAgICBtZXNzYWdlOiBcIkljb3JyZWN0IEFkZHJlc3NcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICAvL2NpdHlcclxuICAgIGNpdHk6IHtcclxuICAgICAgcmVxdWlyZWQ6IHtcclxuICAgICAgICB2YWx1ZTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkNpdHkgaXMgcmVxdWlyZWRcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICAvL3NjaGVkdWxlXHJcbiAgICBzY2hlZHVsZToge1xyXG4gICAgICByZXF1aXJlZDoge1xyXG4gICAgICAgIHZhbHVlOiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiU2NoZWR1bGUgaXMgcmVxdWlyZWRcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICAvL2V4dHJhIGNvbW1lbnRcclxuICAgIGNvbW1lbnQ6IHtcclxuICAgICAgbWF4TGVuZ3RoOiB7XHJcbiAgICAgICAgdmFsdWU6IDI1LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiTWF4IExlbmd0aCAyNSBjaGFyc1wiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9O1xyXG59O1xyXG5cclxuLy93c3AgdXJsIGNyZWF0b3JcclxuZXhwb3J0IGZ1bmN0aW9uIGdldFdzcFVybChvcmRlckRhdGEpIHtcclxuICBjb25zdCBOID0gcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfTVlfUEhPTkVfTlVNQkVSO1xyXG4gIGNvbnN0IElEID0gbmFub2lkKDgpO1xyXG4gIGNvbnN0IHsgY2FydEl0ZW1zLCBzdWJUb3RhbCwgd2l0aERlbGl2ZXJ5LCBzaGlwcGluZ0Nvc3QsIHRvdGFsLCBmb3JtRGF0YSB9ID0gb3JkZXJEYXRhO1xyXG4gIGNvbnN0IHsgbmFtZSwgcGhvbmUsIGFkZHJlc3MsIGNpdHksIHNjaGVkdWxlLCBjb21tZW50IH0gPSBmb3JtRGF0YTtcclxuXHJcbiAgbGV0IGNhcnRMaXN0Zm9yVXJsID0gXCJcIjtcclxuXHJcbiAge1xyXG4gICAgT2JqZWN0LnZhbHVlcyhjYXJ0SXRlbXMpLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgY29uc3QgaXRlbVRvdGFsID0gKGl0ZW0ub2ZmZXJQcmljZSA/IGl0ZW0ub2ZmZXJQcmljZSAqIGl0ZW0ucXR5IDogaXRlbS5wcmljZSAqIGl0ZW0ucXR5KS50b0ZpeGVkKDIpO1xyXG4gICAgICBjYXJ0TGlzdGZvclVybCArPSBgJTBBJTBBIC0gKigke2l0ZW0ucXR5fSkqICR7aXRlbS50aXRsZX0gLS0+IF8qJCR7aXRlbVRvdGFsfSpfYDtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgV1NQX1VSTCA9IGBodHRwczovL2FwaS53aGF0c2FwcC5jb20vc2VuZC8/cGhvbmU9JHtOfSZ0ZXh0PSUyQSR7XCJPcmRlclwifSUzQSUyQSUyMCR7SUR9JTBBJTBBJTJBJHtcIkNsaWVudFwifSUzQSUyQSUyMCR7bmFtZX0lMEElMEElMkEke1wiUGhvbmVcIn0lM0ElMkElMjAke3Bob25lfSUwQSUwQSUyQSR7XHJcbiAgICB3aXRoRGVsaXZlcnkgPyBcIkFkZHJlc3NcIiArIFwiJTNBJTJBJTIwXCIgKyBhZGRyZXNzICsgXCIgJTBBJTBBJTJBXCIgOiBcIlwiXHJcbiAgfSR7d2l0aERlbGl2ZXJ5ID8gXCJDaXR5XCIgKyBcIiUzQSUyQSUyMFwiICsgY2l0eSArIFwiJTBBJTBBJTJBXCIgOiBcIlwifSR7XHJcbiAgICB3aXRoRGVsaXZlcnkgPyBcIlNjaGVkdWxlXCIgKyBcIiUzQSUyQSUyMFwiICsgc2NoZWR1bGUgKyBcIiUwQSUwQSUyQVwiIDogXCJcIlxyXG4gIH0ke2NvbW1lbnQgPyBcIkNvbW1lbnRcIiArIFwiJTNBJTJBJTIwXCIgKyBjb21tZW50ICsgXCIlMEElMEElMkFcIiA6IFwiXCJ9JHtcIkl0ZW1zIExpc3RcIn0lM0ElMkEke2NhcnRMaXN0Zm9yVXJsfSUwQSUwQSUyQSR7XHJcbiAgICB3aXRoRGVsaXZlcnkgPyBcIlN1YiBUb3RhbFwiICsgXCIlM0ElMkElMjAkXCIgKyBzdWJUb3RhbCArIFwiICUwQSUwQSUyQVwiIDogXCJcIlxyXG4gIH0ke3dpdGhEZWxpdmVyeSA/IFwiRGVsaXZlcnkgRmVlXCIgKyBcIiUzQSUyQSUyMCRcIiArIHNoaXBwaW5nQ29zdCArIFwiICUwQSUwQSUyQVwiIDogXCJcIn0ke1wiVG90YWxcIn0lM0ElMkElMjAke3RvdGFsfSUwQSUwQWA7XHJcblxyXG4gIHJldHVybiBXU1BfVVJMO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=
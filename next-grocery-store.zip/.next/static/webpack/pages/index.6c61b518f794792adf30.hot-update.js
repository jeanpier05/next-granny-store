webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/cart/CartFooter.jsx":
/*!********************************************!*\
  !*** ./src/components/cart/CartFooter.jsx ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @chakra-ui/core */ "./node_modules/@chakra-ui/core/dist/es/index.js");
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/recoil.js");
/* harmony import */ var _recoil_state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../recoil/state */ "./src/recoil/state.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ "./node_modules/next/dist/client/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "E:\\nodesjs\\next-grocery-store\\src\\components\\cart\\CartFooter.jsx",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;





function CartFooter() {
  _s();

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_4__["useRouter"])();
  var subTotal = Object(recoil__WEBPACK_IMPORTED_MODULE_2__["useRecoilValue"])(_recoil_state__WEBPACK_IMPORTED_MODULE_3__["cartTotal"]);
  return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    w: "100%",
    bg: "white",
    py: "6",
    position: "absolute",
    bottom: "0",
    right: "0",
    px: "4",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 5
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Text"], {
    fontSize: "2xl",
    textAlign: "right",
    mb: "2",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }
  }, "Sub Total: S/ ", subTotal.toFixed(2)), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
    onClick: function onClick() {
      return router.push("/checkout");
    },
    w: "100%",
    variantColor: "bluex",
    size: "lg",
    disabled: !subTotal,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 7
    }
  }, "PROCESAR"));
}

_s(CartFooter, "GnLcuvUQBqFTYTv7FwVWvBFgoKs=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_4__["useRouter"], recoil__WEBPACK_IMPORTED_MODULE_2__["useRecoilValue"]];
});

_c = CartFooter;
/* harmony default export */ __webpack_exports__["default"] = (CartFooter);

var _c;

$RefreshReg$(_c, "CartFooter");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvY2FydC9DYXJ0Rm9vdGVyLmpzeCJdLCJuYW1lcyI6WyJDYXJ0Rm9vdGVyIiwicm91dGVyIiwidXNlUm91dGVyIiwic3ViVG90YWwiLCJ1c2VSZWNvaWxWYWx1ZSIsImNhcnRUb3RhbCIsInRvRml4ZWQiLCJwdXNoIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFNBQVNBLFVBQVQsR0FBc0I7QUFBQTs7QUFDcEIsTUFBTUMsTUFBTSxHQUFHQyw2REFBUyxFQUF4QjtBQUNBLE1BQU1DLFFBQVEsR0FBR0MsNkRBQWMsQ0FBQ0MsdURBQUQsQ0FBL0I7QUFFQSxTQUNFLE1BQUMsbURBQUQ7QUFBSyxLQUFDLEVBQUMsTUFBUDtBQUFjLE1BQUUsRUFBQyxPQUFqQjtBQUF5QixNQUFFLEVBQUMsR0FBNUI7QUFBZ0MsWUFBUSxFQUFDLFVBQXpDO0FBQW9ELFVBQU0sRUFBQyxHQUEzRDtBQUErRCxTQUFLLEVBQUMsR0FBckU7QUFBeUUsTUFBRSxFQUFDLEdBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLG9EQUFEO0FBQU0sWUFBUSxFQUFDLEtBQWY7QUFBcUIsYUFBUyxFQUFDLE9BQS9CO0FBQXVDLE1BQUUsRUFBQyxHQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUNpQkYsUUFBUSxDQUFDRyxPQUFULENBQWlCLENBQWpCLENBRGpCLENBREYsRUFJRSxNQUFDLHNEQUFEO0FBQVEsV0FBTyxFQUFFO0FBQUEsYUFBTUwsTUFBTSxDQUFDTSxJQUFQLENBQVksV0FBWixDQUFOO0FBQUEsS0FBakI7QUFBaUQsS0FBQyxFQUFDLE1BQW5EO0FBQTBELGdCQUFZLEVBQUMsT0FBdkU7QUFBK0UsUUFBSSxFQUFDLElBQXBGO0FBQXlGLFlBQVEsRUFBRSxDQUFDSixRQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpGLENBREY7QUFVRDs7R0FkUUgsVTtVQUNRRSxxRCxFQUNFRSxxRDs7O0tBRlZKLFU7QUFnQk1BLHlFQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LjZjNjFiNTE4Zjc5NDc5MmFkZjMwLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3gsIEJ1dHRvbiwgVGV4dCB9IGZyb20gXCJAY2hha3JhLXVpL2NvcmVcIjtcclxuaW1wb3J0IHsgdXNlUmVjb2lsVmFsdWUgfSBmcm9tIFwicmVjb2lsXCI7XHJcbmltcG9ydCB7IGNhcnRUb3RhbCB9IGZyb20gXCIuLi8uLi9yZWNvaWwvc3RhdGVcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcblxyXG5mdW5jdGlvbiBDYXJ0Rm9vdGVyKCkge1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IHN1YlRvdGFsID0gdXNlUmVjb2lsVmFsdWUoY2FydFRvdGFsKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxCb3ggdz1cIjEwMCVcIiBiZz1cIndoaXRlXCIgcHk9XCI2XCIgcG9zaXRpb249XCJhYnNvbHV0ZVwiIGJvdHRvbT1cIjBcIiByaWdodD1cIjBcIiBweD1cIjRcIj5cclxuICAgICAgPFRleHQgZm9udFNpemU9XCIyeGxcIiB0ZXh0QWxpZ249XCJyaWdodFwiIG1iPVwiMlwiPlxyXG4gICAgICAgIFN1YiBUb3RhbDogUy8ge3N1YlRvdGFsLnRvRml4ZWQoMil9XHJcbiAgICAgIDwvVGV4dD5cclxuICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiByb3V0ZXIucHVzaChcIi9jaGVja291dFwiKX0gdz1cIjEwMCVcIiB2YXJpYW50Q29sb3I9XCJibHVleFwiIHNpemU9XCJsZ1wiIGRpc2FibGVkPXshc3ViVG90YWx9PlxyXG4gICAgICAgIFBST0NFU0FSXHJcbiAgICAgIDwvQnV0dG9uPlxyXG4gICAgPC9Cb3g+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2FydEZvb3RlcjtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==
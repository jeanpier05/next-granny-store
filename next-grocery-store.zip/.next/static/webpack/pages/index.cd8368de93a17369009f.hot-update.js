webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/home/ItemCard.jsx":
/*!******************************************!*\
  !*** ./src/components/home/ItemCard.jsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ItemCard; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @chakra-ui/core */ "./node_modules/@chakra-ui/core/dist/es/index.js");
/* harmony import */ var _hooks_useIsInCart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../hooks/useIsInCart */ "./src/hooks/useIsInCart.js");
/* harmony import */ var _others_CounterBtn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../others/CounterBtn */ "./src/components/others/CounterBtn.jsx");
/* harmony import */ var _others_ItemModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../others/ItemModal */ "./src/components/others/ItemModal.jsx");
var _jsxFileName = "E:\\nodesjs\\next-grocery-store\\src\\components\\home\\ItemCard.jsx",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;





function ItemCard(_ref) {
  _s();

  var item = _ref.item;
  var title = item.title,
      price = item.price,
      img = item.img,
      offerPrice = item.offerPrice; //HOOKS

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false),
      showModal = _useState[0],
      setModal = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])("initial"),
      isAdded = _useState2[0],
      setAdded = _useState2[1];

  var counter = Object(_hooks_useIsInCart__WEBPACK_IMPORTED_MODULE_2__["default"])(item);
  var toast = Object(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["useToast"])(); //effect for handle toast

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(function () {
    if (counter === 1 && isAdded === "noAdded") {
      toast({
        position: "bottom-left",
        title: "Artículo agregado al carrito.",
        status: "success",
        duration: 1500
      });
      setAdded("added");
    } else if (counter === 0 && isAdded === "added") {
      toast({
        position: "bottom-left",
        title: "Item Removed to Cart.",
        status: "error",
        duration: 1500
      });
      setAdded("noAdded");
    } else if (isAdded === "initial" && counter === 0) {
      setAdded("noAdded");
    } else if (isAdded === "initial" && counter > 0) {
      setAdded("added");
    }
  }, [counter]);
  return __jsx(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Flex"], {
    w: "100%",
    h: "300px",
    bg: "white",
    direction: "column",
    justify: "center",
    align: "center",
    position: "relative",
    pb: "2",
    shadow: "lg",
    rounded: "md",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 7
    }
  }, offerPrice && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Badge"], {
    size: "",
    variant: "solid",
    variantColor: "red",
    position: "absolute",
    px: "2",
    top: "10px",
    right: "10px",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56,
      columnNumber: 11
    }
  }, "SALE"), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    w: "100%",
    h: "50%",
    onClick: function onClick() {
      return setModal(true);
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61,
      columnNumber: 9
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Image"], {
    size: "100%",
    objectFit: "cover",
    src: "/images/".concat(img),
    fallbackSrc: "/images/fallbackImg.png",
    alt: "",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62,
      columnNumber: 11
    }
  })), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    w: "85%",
    my: "3",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 9
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Flex"], {
    align: "flex-end",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 11
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Text"], {
    fontSize: "md",
    fontWeight: "medium",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 67,
      columnNumber: 13
    }
  }, "$", offerPrice || price), offerPrice && __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Text"], {
    ml: "1",
    fontSize: "sm",
    fontWeight: "medium",
    as: "del",
    color: "gray.400",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 15
    }
  }, "$", price)), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Text"], {
    fontSize: "sm",
    textTransform: "capitalize",
    minHeight: "42px",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 77,
      columnNumber: 11
    }
  }, title)), __jsx(_others_CounterBtn__WEBPACK_IMPORTED_MODULE_3__["default"], {
    item: item,
    counter: counter,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 82,
      columnNumber: 9
    }
  })), __jsx(_others_ItemModal__WEBPACK_IMPORTED_MODULE_4__["default"], {
    showModal: showModal,
    setModal: setModal,
    img: img,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 85,
      columnNumber: 7
    }
  }));
}

_s(ItemCard, "E9hnGYHY+mVdzMOtFUWCqwwcCiA=", false, function () {
  return [_hooks_useIsInCart__WEBPACK_IMPORTED_MODULE_2__["default"], _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["useToast"]];
});

_c = ItemCard;

var _c;

$RefreshReg$(_c, "ItemCard");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvaG9tZS9JdGVtQ2FyZC5qc3giXSwibmFtZXMiOlsiSXRlbUNhcmQiLCJpdGVtIiwidGl0bGUiLCJwcmljZSIsImltZyIsIm9mZmVyUHJpY2UiLCJ1c2VTdGF0ZSIsInNob3dNb2RhbCIsInNldE1vZGFsIiwiaXNBZGRlZCIsInNldEFkZGVkIiwiY291bnRlciIsInVzZUlzSW5DYXJ0IiwidG9hc3QiLCJ1c2VUb2FzdCIsInVzZUVmZmVjdCIsInBvc2l0aW9uIiwic3RhdHVzIiwiZHVyYXRpb24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVlLFNBQVNBLFFBQVQsT0FBNEI7QUFBQTs7QUFBQSxNQUFSQyxJQUFRLFFBQVJBLElBQVE7QUFBQSxNQUNqQ0MsS0FEaUMsR0FDQ0QsSUFERCxDQUNqQ0MsS0FEaUM7QUFBQSxNQUMxQkMsS0FEMEIsR0FDQ0YsSUFERCxDQUMxQkUsS0FEMEI7QUFBQSxNQUNuQkMsR0FEbUIsR0FDQ0gsSUFERCxDQUNuQkcsR0FEbUI7QUFBQSxNQUNkQyxVQURjLEdBQ0NKLElBREQsQ0FDZEksVUFEYyxFQUd6Qzs7QUFIeUMsa0JBSVhDLHNEQUFRLENBQUMsS0FBRCxDQUpHO0FBQUEsTUFJbENDLFNBSmtDO0FBQUEsTUFJdkJDLFFBSnVCOztBQUFBLG1CQUtiRixzREFBUSxDQUFDLFNBQUQsQ0FMSztBQUFBLE1BS2xDRyxPQUxrQztBQUFBLE1BS3pCQyxRQUx5Qjs7QUFNekMsTUFBTUMsT0FBTyxHQUFHQyxrRUFBVyxDQUFDWCxJQUFELENBQTNCO0FBQ0EsTUFBTVksS0FBSyxHQUFHQyxnRUFBUSxFQUF0QixDQVB5QyxDQVN6Qzs7QUFDQUMseURBQVMsQ0FBQyxZQUFNO0FBQ2QsUUFBSUosT0FBTyxLQUFLLENBQVosSUFBaUJGLE9BQU8sS0FBSyxTQUFqQyxFQUE0QztBQUMxQ0ksV0FBSyxDQUFDO0FBQ0pHLGdCQUFRLEVBQUUsYUFETjtBQUVKZCxhQUFLLEVBQUUsK0JBRkg7QUFHSmUsY0FBTSxFQUFFLFNBSEo7QUFJSkMsZ0JBQVEsRUFBRTtBQUpOLE9BQUQsQ0FBTDtBQU1BUixjQUFRLENBQUMsT0FBRCxDQUFSO0FBQ0QsS0FSRCxNQVFPLElBQUlDLE9BQU8sS0FBSyxDQUFaLElBQWlCRixPQUFPLEtBQUssT0FBakMsRUFBMEM7QUFDL0NJLFdBQUssQ0FBQztBQUNKRyxnQkFBUSxFQUFFLGFBRE47QUFFSmQsYUFBSyxFQUFFLHVCQUZIO0FBR0plLGNBQU0sRUFBRSxPQUhKO0FBSUpDLGdCQUFRLEVBQUU7QUFKTixPQUFELENBQUw7QUFNQVIsY0FBUSxDQUFDLFNBQUQsQ0FBUjtBQUNELEtBUk0sTUFRQSxJQUFJRCxPQUFPLEtBQUssU0FBWixJQUF5QkUsT0FBTyxLQUFLLENBQXpDLEVBQTRDO0FBQ2pERCxjQUFRLENBQUMsU0FBRCxDQUFSO0FBQ0QsS0FGTSxNQUVBLElBQUlELE9BQU8sS0FBSyxTQUFaLElBQXlCRSxPQUFPLEdBQUcsQ0FBdkMsRUFBMEM7QUFDL0NELGNBQVEsQ0FBQyxPQUFELENBQVI7QUFDRDtBQUNGLEdBdEJRLEVBc0JOLENBQUNDLE9BQUQsQ0F0Qk0sQ0FBVDtBQXdCQSxTQUNFLG1FQUNFLE1BQUMsb0RBQUQ7QUFDRSxLQUFDLEVBQUMsTUFESjtBQUVFLEtBQUMsRUFBQyxPQUZKO0FBR0UsTUFBRSxFQUFDLE9BSEw7QUFJRSxhQUFTLEVBQUMsUUFKWjtBQUtFLFdBQU8sRUFBQyxRQUxWO0FBTUUsU0FBSyxFQUFDLFFBTlI7QUFPRSxZQUFRLEVBQUMsVUFQWDtBQVFFLE1BQUUsRUFBQyxHQVJMO0FBU0UsVUFBTSxFQUFDLElBVFQ7QUFVRSxXQUFPLEVBQUMsSUFWVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBWUdOLFVBQVUsSUFDVCxNQUFDLHFEQUFEO0FBQU8sUUFBSSxFQUFDLEVBQVo7QUFBZSxXQUFPLEVBQUMsT0FBdkI7QUFBK0IsZ0JBQVksRUFBQyxLQUE1QztBQUFrRCxZQUFRLEVBQUMsVUFBM0Q7QUFBc0UsTUFBRSxFQUFDLEdBQXpFO0FBQTZFLE9BQUcsRUFBQyxNQUFqRjtBQUF3RixTQUFLLEVBQUMsTUFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWJKLEVBa0JFLE1BQUMsbURBQUQ7QUFBSyxLQUFDLEVBQUMsTUFBUDtBQUFjLEtBQUMsRUFBQyxLQUFoQjtBQUFzQixXQUFPLEVBQUU7QUFBQSxhQUFNRyxRQUFRLENBQUMsSUFBRCxDQUFkO0FBQUEsS0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFLE1BQUMscURBQUQ7QUFBTyxRQUFJLEVBQUMsTUFBWjtBQUFtQixhQUFTLEVBQUMsT0FBN0I7QUFBcUMsT0FBRyxvQkFBYUosR0FBYixDQUF4QztBQUE0RCxlQUFXLEVBQUMseUJBQXhFO0FBQWtHLE9BQUcsRUFBQyxFQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBREYsQ0FsQkYsRUFzQkUsTUFBQyxtREFBRDtBQUFLLEtBQUMsRUFBQyxLQUFQO0FBQWEsTUFBRSxFQUFDLEdBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLG9EQUFEO0FBQU0sU0FBSyxFQUFDLFVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFLE1BQUMsb0RBQUQ7QUFBTSxZQUFRLEVBQUMsSUFBZjtBQUFvQixjQUFVLEVBQUMsUUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNJQyxVQUFVLElBQUlGLEtBRGxCLENBREYsRUFJR0UsVUFBVSxJQUNULE1BQUMsb0RBQUQ7QUFBTSxNQUFFLEVBQUMsR0FBVDtBQUFhLFlBQVEsRUFBQyxJQUF0QjtBQUEyQixjQUFVLEVBQUMsUUFBdEM7QUFBK0MsTUFBRSxFQUFDLEtBQWxEO0FBQXdELFNBQUssRUFBQyxVQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ0lGLEtBREosQ0FMSixDQURGLEVBWUUsTUFBQyxvREFBRDtBQUFNLFlBQVEsRUFBQyxJQUFmO0FBQW9CLGlCQUFhLEVBQUMsWUFBbEM7QUFBK0MsYUFBUyxFQUFDLE1BQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDR0QsS0FESCxDQVpGLENBdEJGLEVBdUNFLE1BQUMsMERBQUQ7QUFBWSxRQUFJLEVBQUVELElBQWxCO0FBQXdCLFdBQU8sRUFBRVUsT0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXZDRixDQURGLEVBMkNFLE1BQUMseURBQUQ7QUFBVyxhQUFTLEVBQUVKLFNBQXRCO0FBQWlDLFlBQVEsRUFBRUMsUUFBM0M7QUFBcUQsT0FBRyxFQUFFSixHQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBM0NGLENBREY7QUErQ0Q7O0dBakZ1QkosUTtVQU1OWSwwRCxFQUNGRSx3RDs7O0tBUFFkLFEiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguY2Q4MzY4ZGU5M2ExNzM2OTAwOWYuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJhZGdlLCBCb3gsIEZsZXgsIEltYWdlLCBUZXh0LCB1c2VUb2FzdCB9IGZyb20gXCJAY2hha3JhLXVpL2NvcmVcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgdXNlSXNJbkNhcnQgZnJvbSBcIi4uLy4uL2hvb2tzL3VzZUlzSW5DYXJ0XCI7XHJcbmltcG9ydCBDb3VudGVyQnRuIGZyb20gXCIuLi9vdGhlcnMvQ291bnRlckJ0blwiO1xyXG5pbXBvcnQgSXRlbU1vZGFsIGZyb20gXCIuLi9vdGhlcnMvSXRlbU1vZGFsXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBJdGVtQ2FyZCh7IGl0ZW0gfSkge1xyXG4gIGNvbnN0IHsgdGl0bGUsIHByaWNlLCBpbWcsIG9mZmVyUHJpY2UgfSA9IGl0ZW07XHJcblxyXG4gIC8vSE9PS1NcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzQWRkZWQsIHNldEFkZGVkXSA9IHVzZVN0YXRlKFwiaW5pdGlhbFwiKTtcclxuICBjb25zdCBjb3VudGVyID0gdXNlSXNJbkNhcnQoaXRlbSk7XHJcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xyXG5cclxuICAvL2VmZmVjdCBmb3IgaGFuZGxlIHRvYXN0XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChjb3VudGVyID09PSAxICYmIGlzQWRkZWQgPT09IFwibm9BZGRlZFwiKSB7XHJcbiAgICAgIHRvYXN0KHtcclxuICAgICAgICBwb3NpdGlvbjogXCJib3R0b20tbGVmdFwiLFxyXG4gICAgICAgIHRpdGxlOiBcIkFydMOtY3VsbyBhZ3JlZ2FkbyBhbCBjYXJyaXRvLlwiLFxyXG4gICAgICAgIHN0YXR1czogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDE1MDAsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRBZGRlZChcImFkZGVkXCIpO1xyXG4gICAgfSBlbHNlIGlmIChjb3VudGVyID09PSAwICYmIGlzQWRkZWQgPT09IFwiYWRkZWRcIikge1xyXG4gICAgICB0b2FzdCh7XHJcbiAgICAgICAgcG9zaXRpb246IFwiYm90dG9tLWxlZnRcIixcclxuICAgICAgICB0aXRsZTogXCJJdGVtIFJlbW92ZWQgdG8gQ2FydC5cIixcclxuICAgICAgICBzdGF0dXM6IFwiZXJyb3JcIixcclxuICAgICAgICBkdXJhdGlvbjogMTUwMCxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldEFkZGVkKFwibm9BZGRlZFwiKTtcclxuICAgIH0gZWxzZSBpZiAoaXNBZGRlZCA9PT0gXCJpbml0aWFsXCIgJiYgY291bnRlciA9PT0gMCkge1xyXG4gICAgICBzZXRBZGRlZChcIm5vQWRkZWRcIik7XHJcbiAgICB9IGVsc2UgaWYgKGlzQWRkZWQgPT09IFwiaW5pdGlhbFwiICYmIGNvdW50ZXIgPiAwKSB7XHJcbiAgICAgIHNldEFkZGVkKFwiYWRkZWRcIik7XHJcbiAgICB9XHJcbiAgfSwgW2NvdW50ZXJdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxGbGV4XHJcbiAgICAgICAgdz1cIjEwMCVcIlxyXG4gICAgICAgIGg9XCIzMDBweFwiXHJcbiAgICAgICAgYmc9XCJ3aGl0ZVwiXHJcbiAgICAgICAgZGlyZWN0aW9uPVwiY29sdW1uXCJcclxuICAgICAgICBqdXN0aWZ5PVwiY2VudGVyXCJcclxuICAgICAgICBhbGlnbj1cImNlbnRlclwiXHJcbiAgICAgICAgcG9zaXRpb249XCJyZWxhdGl2ZVwiXHJcbiAgICAgICAgcGI9XCIyXCJcclxuICAgICAgICBzaGFkb3c9XCJsZ1wiXHJcbiAgICAgICAgcm91bmRlZD1cIm1kXCJcclxuICAgICAgPlxyXG4gICAgICAgIHtvZmZlclByaWNlICYmIChcclxuICAgICAgICAgIDxCYWRnZSBzaXplPVwiXCIgdmFyaWFudD1cInNvbGlkXCIgdmFyaWFudENvbG9yPVwicmVkXCIgcG9zaXRpb249XCJhYnNvbHV0ZVwiIHB4PVwiMlwiIHRvcD1cIjEwcHhcIiByaWdodD1cIjEwcHhcIj5cclxuICAgICAgICAgICAgU0FMRVxyXG4gICAgICAgICAgPC9CYWRnZT5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICA8Qm94IHc9XCIxMDAlXCIgaD1cIjUwJVwiIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsKHRydWUpfT5cclxuICAgICAgICAgIDxJbWFnZSBzaXplPVwiMTAwJVwiIG9iamVjdEZpdD1cImNvdmVyXCIgc3JjPXtgL2ltYWdlcy8ke2ltZ31gfSBmYWxsYmFja1NyYz1cIi9pbWFnZXMvZmFsbGJhY2tJbWcucG5nXCIgYWx0PVwiXCIgLz5cclxuICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgPEJveCB3PVwiODUlXCIgbXk9XCIzXCI+XHJcbiAgICAgICAgICA8RmxleCBhbGlnbj1cImZsZXgtZW5kXCI+XHJcbiAgICAgICAgICAgIDxUZXh0IGZvbnRTaXplPVwibWRcIiBmb250V2VpZ2h0PVwibWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgJHtvZmZlclByaWNlIHx8IHByaWNlfVxyXG4gICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgIHtvZmZlclByaWNlICYmIChcclxuICAgICAgICAgICAgICA8VGV4dCBtbD1cIjFcIiBmb250U2l6ZT1cInNtXCIgZm9udFdlaWdodD1cIm1lZGl1bVwiIGFzPVwiZGVsXCIgY29sb3I9XCJncmF5LjQwMFwiPlxyXG4gICAgICAgICAgICAgICAgJHtwcmljZX1cclxuICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L0ZsZXg+XHJcblxyXG4gICAgICAgICAgPFRleHQgZm9udFNpemU9XCJzbVwiIHRleHRUcmFuc2Zvcm09XCJjYXBpdGFsaXplXCIgbWluSGVpZ2h0PVwiNDJweFwiPlxyXG4gICAgICAgICAgICB7dGl0bGV9XHJcbiAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgIDxDb3VudGVyQnRuIGl0ZW09e2l0ZW19IGNvdW50ZXI9e2NvdW50ZXJ9IC8+XHJcbiAgICAgIDwvRmxleD5cclxuXHJcbiAgICAgIDxJdGVtTW9kYWwgc2hvd01vZGFsPXtzaG93TW9kYWx9IHNldE1vZGFsPXtzZXRNb2RhbH0gaW1nPXtpbWd9IC8+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=
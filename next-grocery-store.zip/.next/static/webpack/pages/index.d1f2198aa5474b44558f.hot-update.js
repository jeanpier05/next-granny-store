webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/home/ItemsGrid.jsx":
/*!*******************************************!*\
  !*** ./src/components/home/ItemsGrid.jsx ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ItemsGrid; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @chakra-ui/core */ "./node_modules/@chakra-ui/core/dist/es/index.js");
/* harmony import */ var _ItemCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ItemCard */ "./src/components/home/ItemCard.jsx");
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/recoil.js");
/* harmony import */ var _recoil_state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../recoil/state */ "./src/recoil/state.js");
/* harmony import */ var _SkeletonGrid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./SkeletonGrid */ "./src/components/home/SkeletonGrid.jsx");
var _jsxFileName = "E:\\nodesjs\\next-grocery-store\\src\\components\\home\\ItemsGrid.jsx",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;





console.log(_recoil_state__WEBPACK_IMPORTED_MODULE_4__["itemsList"]);
function ItemsGrid() {
  _s();

  var _this = this;

  var data = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["useRecoilValueLoadable"])(_recoil_state__WEBPACK_IMPORTED_MODULE_4__["itemsList"]);
  if (data.state === "loading") return __jsx(_SkeletonGrid__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 40
    }
  });

  if (data.state === "hasError") {
    return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Alert"], {
      status: "error",
      variant: "solid",
      flexDirection: "column",
      justifyContent: "center",
      textAlign: "center",
      height: "200px",
      mt: "80px",
      mx: "auto",
      w: ["100%", "80%"],
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 7
      }
    }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["AlertIcon"], {
      size: "40px",
      mr: 0,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }
    }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["AlertTitle"], {
      mt: 4,
      mb: 1,
      fontSize: "lg",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 9
      }
    }, "Ocurri\xF3 un error!"), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["AlertDescription"], {
      maxWidth: "sm",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 9
      }
    }, "Lorem ipsum dolor sit amet consectetur adipisicing elit"));
  }

  if (!data.contents.length) {
    return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Alert"], {
      status: "info",
      variant: "solid",
      flexDirection: "column",
      justifyContent: "center",
      textAlign: "center",
      height: "200px",
      mt: "80px",
      mx: "auto",
      w: ["100%", "80%"],
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 7
      }
    }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["AlertIcon"], {
      size: "40px",
      mr: 0,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 9
      }
    }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["AlertTitle"], {
      mt: 4,
      mb: 1,
      fontSize: "lg",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }
    }, "No Items Found!"), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["AlertDescription"], {
      maxWidth: "sm",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 9
      }
    }, "Lorem ipsum dolor sit amet consectetur adipisicing elit"));
  }

  return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    templateColumns: "repeat(auto-fill,minmax(220px,1fr))",
    gap: 6,
    mt: "8",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 5
    }
  }, data.contents.map(function (item) {
    return __jsx(_ItemCard__WEBPACK_IMPORTED_MODULE_2__["default"], {
      item: item,
      key: item.img,
      __self: _this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 9
      }
    });
  }));
}

_s(ItemsGrid, "OOET3Jm5sBOBEos8MvS/QRINE30=", false, function () {
  return [recoil__WEBPACK_IMPORTED_MODULE_3__["useRecoilValueLoadable"]];
});

_c = ItemsGrid;

var _c;

$RefreshReg$(_c, "ItemsGrid");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvaG9tZS9JdGVtc0dyaWQuanN4Il0sIm5hbWVzIjpbImNvbnNvbGUiLCJsb2ciLCJpdGVtc0xpc3QiLCJJdGVtc0dyaWQiLCJkYXRhIiwidXNlUmVjb2lsVmFsdWVMb2FkYWJsZSIsInN0YXRlIiwiY29udGVudHMiLCJsZW5ndGgiLCJtYXAiLCJpdGVtIiwiaW1nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyx1REFBWjtBQUVlLFNBQVNDLFNBQVQsR0FBcUI7QUFBQTs7QUFBQTs7QUFDbEMsTUFBTUMsSUFBSSxHQUFHQyxxRUFBc0IsQ0FBQ0gsdURBQUQsQ0FBbkM7QUFFQSxNQUFJRSxJQUFJLENBQUNFLEtBQUwsS0FBZSxTQUFuQixFQUE4QixPQUFPLE1BQUMscURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUFQOztBQUU5QixNQUFJRixJQUFJLENBQUNFLEtBQUwsS0FBZSxVQUFuQixFQUErQjtBQUM3QixXQUNFLE1BQUMscURBQUQ7QUFDRSxZQUFNLEVBQUMsT0FEVDtBQUVFLGFBQU8sRUFBQyxPQUZWO0FBR0UsbUJBQWEsRUFBQyxRQUhoQjtBQUlFLG9CQUFjLEVBQUMsUUFKakI7QUFLRSxlQUFTLEVBQUMsUUFMWjtBQU1FLFlBQU0sRUFBQyxPQU5UO0FBT0UsUUFBRSxFQUFDLE1BUEw7QUFRRSxRQUFFLEVBQUMsTUFSTDtBQVNFLE9BQUMsRUFBRSxDQUFDLE1BQUQsRUFBUyxLQUFULENBVEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQVdFLE1BQUMseURBQUQ7QUFBVyxVQUFJLEVBQUMsTUFBaEI7QUFBdUIsUUFBRSxFQUFFLENBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFYRixFQVlFLE1BQUMsMERBQUQ7QUFBWSxRQUFFLEVBQUUsQ0FBaEI7QUFBbUIsUUFBRSxFQUFFLENBQXZCO0FBQTBCLGNBQVEsRUFBQyxJQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQVpGLEVBZUUsTUFBQyxnRUFBRDtBQUFrQixjQUFRLEVBQUMsSUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpRUFmRixDQURGO0FBbUJEOztBQUVELE1BQUksQ0FBQ0YsSUFBSSxDQUFDRyxRQUFMLENBQWNDLE1BQW5CLEVBQTJCO0FBQ3pCLFdBQ0UsTUFBQyxxREFBRDtBQUNFLFlBQU0sRUFBQyxNQURUO0FBRUUsYUFBTyxFQUFDLE9BRlY7QUFHRSxtQkFBYSxFQUFDLFFBSGhCO0FBSUUsb0JBQWMsRUFBQyxRQUpqQjtBQUtFLGVBQVMsRUFBQyxRQUxaO0FBTUUsWUFBTSxFQUFDLE9BTlQ7QUFPRSxRQUFFLEVBQUMsTUFQTDtBQVFFLFFBQUUsRUFBQyxNQVJMO0FBU0UsT0FBQyxFQUFFLENBQUMsTUFBRCxFQUFTLEtBQVQsQ0FUTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BV0UsTUFBQyx5REFBRDtBQUFXLFVBQUksRUFBQyxNQUFoQjtBQUF1QixRQUFFLEVBQUUsQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVhGLEVBWUUsTUFBQywwREFBRDtBQUFZLFFBQUUsRUFBRSxDQUFoQjtBQUFtQixRQUFFLEVBQUUsQ0FBdkI7QUFBMEIsY0FBUSxFQUFDLElBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWkYsRUFlRSxNQUFDLGdFQUFEO0FBQWtCLGNBQVEsRUFBQyxJQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlFQWZGLENBREY7QUFtQkQ7O0FBRUQsU0FDRSxNQUFDLG9EQUFEO0FBQU0sbUJBQWUsRUFBQyxxQ0FBdEI7QUFBNEQsT0FBRyxFQUFFLENBQWpFO0FBQW9FLE1BQUUsRUFBQyxHQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0dKLElBQUksQ0FBQ0csUUFBTCxDQUFjRSxHQUFkLENBQWtCLFVBQUNDLElBQUQ7QUFBQSxXQUNqQixNQUFDLGlEQUFEO0FBQVUsVUFBSSxFQUFFQSxJQUFoQjtBQUFzQixTQUFHLEVBQUVBLElBQUksQ0FBQ0MsR0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQURpQjtBQUFBLEdBQWxCLENBREgsQ0FERjtBQU9EOztHQXhEdUJSLFM7VUFDVEUsNkQ7OztLQURTRixTIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LmQxZjIxOThhYTU0NzRiNDQ1NThmLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBbGVydCwgQWxlcnREZXNjcmlwdGlvbiwgQWxlcnRJY29uLCBBbGVydFRpdGxlLCBHcmlkIH0gZnJvbSBcIkBjaGFrcmEtdWkvY29yZVwiO1xyXG5pbXBvcnQgSXRlbUNhcmQgZnJvbSBcIi4vSXRlbUNhcmRcIjtcclxuXHJcbmltcG9ydCB7IHVzZVJlY29pbFZhbHVlTG9hZGFibGUgfSBmcm9tIFwicmVjb2lsXCI7XHJcbmltcG9ydCB7IGl0ZW1zTGlzdCB9IGZyb20gXCIuLi8uLi9yZWNvaWwvc3RhdGVcIjtcclxuaW1wb3J0IFNrZWxldG9uR3JpZCBmcm9tIFwiLi9Ta2VsZXRvbkdyaWRcIjtcclxuXHJcbmNvbnNvbGUubG9nKGl0ZW1zTGlzdCk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBJdGVtc0dyaWQoKSB7XHJcbiAgY29uc3QgZGF0YSA9IHVzZVJlY29pbFZhbHVlTG9hZGFibGUoaXRlbXNMaXN0KTtcclxuXHJcbiAgaWYgKGRhdGEuc3RhdGUgPT09IFwibG9hZGluZ1wiKSByZXR1cm4gPFNrZWxldG9uR3JpZCAvPjtcclxuXHJcbiAgaWYgKGRhdGEuc3RhdGUgPT09IFwiaGFzRXJyb3JcIikge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPEFsZXJ0XHJcbiAgICAgICAgc3RhdHVzPVwiZXJyb3JcIlxyXG4gICAgICAgIHZhcmlhbnQ9XCJzb2xpZFwiXHJcbiAgICAgICAgZmxleERpcmVjdGlvbj1cImNvbHVtblwiXHJcbiAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgIHRleHRBbGlnbj1cImNlbnRlclwiXHJcbiAgICAgICAgaGVpZ2h0PVwiMjAwcHhcIlxyXG4gICAgICAgIG10PVwiODBweFwiXHJcbiAgICAgICAgbXg9XCJhdXRvXCJcclxuICAgICAgICB3PXtbXCIxMDAlXCIsIFwiODAlXCJdfVxyXG4gICAgICA+XHJcbiAgICAgICAgPEFsZXJ0SWNvbiBzaXplPVwiNDBweFwiIG1yPXswfSAvPlxyXG4gICAgICAgIDxBbGVydFRpdGxlIG10PXs0fSBtYj17MX0gZm9udFNpemU9XCJsZ1wiPlxyXG4gICAgICAgICAgT2N1cnJpw7MgdW4gZXJyb3IhXHJcbiAgICAgICAgPC9BbGVydFRpdGxlPlxyXG4gICAgICAgIDxBbGVydERlc2NyaXB0aW9uIG1heFdpZHRoPVwic21cIj5Mb3JlbSBpcHN1bSBkb2xvciBzaXQgYW1ldCBjb25zZWN0ZXR1ciBhZGlwaXNpY2luZyBlbGl0PC9BbGVydERlc2NyaXB0aW9uPlxyXG4gICAgICA8L0FsZXJ0PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmICghZGF0YS5jb250ZW50cy5sZW5ndGgpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxBbGVydFxyXG4gICAgICAgIHN0YXR1cz1cImluZm9cIlxyXG4gICAgICAgIHZhcmlhbnQ9XCJzb2xpZFwiXHJcbiAgICAgICAgZmxleERpcmVjdGlvbj1cImNvbHVtblwiXHJcbiAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgIHRleHRBbGlnbj1cImNlbnRlclwiXHJcbiAgICAgICAgaGVpZ2h0PVwiMjAwcHhcIlxyXG4gICAgICAgIG10PVwiODBweFwiXHJcbiAgICAgICAgbXg9XCJhdXRvXCJcclxuICAgICAgICB3PXtbXCIxMDAlXCIsIFwiODAlXCJdfVxyXG4gICAgICA+XHJcbiAgICAgICAgPEFsZXJ0SWNvbiBzaXplPVwiNDBweFwiIG1yPXswfSAvPlxyXG4gICAgICAgIDxBbGVydFRpdGxlIG10PXs0fSBtYj17MX0gZm9udFNpemU9XCJsZ1wiPlxyXG4gICAgICAgICAgTm8gSXRlbXMgRm91bmQhXHJcbiAgICAgICAgPC9BbGVydFRpdGxlPlxyXG4gICAgICAgIDxBbGVydERlc2NyaXB0aW9uIG1heFdpZHRoPVwic21cIj5Mb3JlbSBpcHN1bSBkb2xvciBzaXQgYW1ldCBjb25zZWN0ZXR1ciBhZGlwaXNpY2luZyBlbGl0PC9BbGVydERlc2NyaXB0aW9uPlxyXG4gICAgICA8L0FsZXJ0PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8R3JpZCB0ZW1wbGF0ZUNvbHVtbnM9XCJyZXBlYXQoYXV0by1maWxsLG1pbm1heCgyMjBweCwxZnIpKVwiIGdhcD17Nn0gbXQ9XCI4XCI+XHJcbiAgICAgIHtkYXRhLmNvbnRlbnRzLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgIDxJdGVtQ2FyZCBpdGVtPXtpdGVtfSBrZXk9e2l0ZW0uaW1nfSAvPlxyXG4gICAgICApKX1cclxuICAgIDwvR3JpZD5cclxuICApO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=
webpackHotUpdate_N_E("pages/index",{

/***/ "./src/recoil/state.js":
/*!*****************************!*\
  !*** ./src/recoil/state.js ***!
  \*****************************/
/*! exports provided: selectedCategory, orderOptions, sortMode, searchValue, cart, cartLength, cartTotal, withDelivery, deliveryFee, formState, itemsList, refreshCart, orderDetails, resetState */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectedCategory", function() { return selectedCategory; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orderOptions", function() { return orderOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sortMode", function() { return sortMode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchValue", function() { return searchValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cart", function() { return cart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cartLength", function() { return cartLength; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cartTotal", function() { return cartTotal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "withDelivery", function() { return withDelivery; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deliveryFee", function() { return deliveryFee; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formState", function() { return formState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "itemsList", function() { return itemsList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "refreshCart", function() { return refreshCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orderDetails", function() { return orderDetails; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetState", function() { return resetState; });
/* harmony import */ var _babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/recoil.js");
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../helpers */ "./src/helpers.js");




function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }


 //ATOMS

var selectedCategory = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["atom"])({
  key: "selectedCategory",
  "default": "all"
});
var orderOptions = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["atom"])({
  key: "orderOptions",
  "default": ["Ascending", "Descending", "Min Price", "Max Price"]
});
var sortMode = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["atom"])({
  key: "sortMode",
  "default": "Ascending"
});
var searchValue = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["atom"])({
  key: "searchValue",
  "default": ""
});
var cart = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["atom"])({
  key: "cart",
  "default": {}
});
var cartLength = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["atom"])({
  key: "cartLength",
  "default": 0
});
var cartTotal = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["atom"])({
  key: "cartTotal",
  "default": 0
});
var withDelivery = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["atom"])({
  key: "withDelivery",
  "default": false
});
var deliveryFee = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["atom"])({
  key: "deliveryFee",
  "default": 5
});
var formState = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["atom"])({
  key: "formState",
  "default": {}
}); //SELECTORS

var itemsList = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["selector"])({
  key: "itemsList",
  get: function () {
    var _get2 = Object(_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee(_ref) {
      var _get, category, sort, search, url;

      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _get = _ref.get;
              category = _get(selectedCategory);
              sort = _get(sortMode);
              search = _get(searchValue);
              url = "/api?category=".concat(category, "&sort=").concat(sort);

              if (search.length > 0) {
                url += "&search=".concat(search);
              }

              _context.next = 8;
              return Object(_helpers__WEBPACK_IMPORTED_MODULE_4__["fetcher"])(url);

            case 8:
              return _context.abrupt("return", _context.sent);

            case 9:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    function get(_x) {
      return _get2.apply(this, arguments);
    }

    return get;
  }()
});
var refreshCart = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["selector"])({
  key: "refreshCart",
  set: function set(_ref2, _ref3) {
    var get = _ref2.get,
        _set = _ref2.set;
    var item = _ref3.item,
        n = _ref3.n;

    var currentCart = _objectSpread({}, get(cart));

    if (n === 1) {
      // add item to cart
      currentCart[item.id] = _objectSpread(_objectSpread({}, item), {}, {
        qty: 1
      });
    } else if (n > 0 && n <= item.stock) {
      // refresh item in cart
      currentCart[item.id] = _objectSpread(_objectSpread({}, item), {}, {
        qty: n
      });
    } else if (n < 1) {
      // remove item to cart
      delete currentCart[item.id];
    }

    var cartToArray = Object.values(currentCart);
    var total = 0;
    cartToArray.forEach(function (item) {
      var actualPrice = item.offerPrice || item.price;
      total += actualPrice * item.qty;
    });

    _set(cart, currentCart); //set cart state


    _set(cartLength, cartToArray.length); //set cart lenght


    _set(cartTotal, total); //set cart total

  }
});
var orderDetails = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["selector"])({
  key: "orderDetails",
  get: function get(_ref4) {
    var _get3 = _ref4.get;

    var cartItems = _get3(cart);

    var subTotal = _get3(cartTotal);

    var delivery = _get3(withDelivery);

    var shippingCost = _get3(deliveryFee);

    var formData = _get3(formState);

    var total = delivery ? subTotal + shippingCost : subTotal;
    return {
      cartItems: cartItems,
      subTotal: subTotal.toFixed(2),
      withDelivery: delivery,
      shippingCost: shippingCost.toFixed(2),
      total: total.toFixed(2),
      formData: formData
    };
  }
});
var resetState = Object(recoil__WEBPACK_IMPORTED_MODULE_3__["selector"])({
  key: "resetState",
  set: function set(_ref5) {
    var get = _ref5.get,
        _set2 = _ref5.set;

    _set2(selectedCategory, "all");

    _set2(sortMode, "Ascending");

    _set2(withDelivery, true);

    _set2(cart, {});

    _set2(cartLength, 0);

    _set2(cartTotal, 0);

    _set2(formState, {});
  }
});

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3JlY29pbC9zdGF0ZS5qcyJdLCJuYW1lcyI6WyJzZWxlY3RlZENhdGVnb3J5IiwiYXRvbSIsImtleSIsIm9yZGVyT3B0aW9ucyIsInNvcnRNb2RlIiwic2VhcmNoVmFsdWUiLCJjYXJ0IiwiY2FydExlbmd0aCIsImNhcnRUb3RhbCIsIndpdGhEZWxpdmVyeSIsImRlbGl2ZXJ5RmVlIiwiZm9ybVN0YXRlIiwiaXRlbXNMaXN0Iiwic2VsZWN0b3IiLCJnZXQiLCJjYXRlZ29yeSIsInNvcnQiLCJzZWFyY2giLCJ1cmwiLCJsZW5ndGgiLCJmZXRjaGVyIiwicmVmcmVzaENhcnQiLCJzZXQiLCJpdGVtIiwibiIsImN1cnJlbnRDYXJ0IiwiaWQiLCJxdHkiLCJzdG9jayIsImNhcnRUb0FycmF5IiwiT2JqZWN0IiwidmFsdWVzIiwidG90YWwiLCJmb3JFYWNoIiwiYWN0dWFsUHJpY2UiLCJvZmZlclByaWNlIiwicHJpY2UiLCJvcmRlckRldGFpbHMiLCJjYXJ0SXRlbXMiLCJzdWJUb3RhbCIsImRlbGl2ZXJ5Iiwic2hpcHBpbmdDb3N0IiwiZm9ybURhdGEiLCJ0b0ZpeGVkIiwicmVzZXRTdGF0ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7Q0FHQTs7QUFDTyxJQUFNQSxnQkFBZ0IsR0FBR0MsbURBQUksQ0FBQztBQUNuQ0MsS0FBRyxFQUFFLGtCQUQ4QjtBQUVuQyxhQUFTO0FBRjBCLENBQUQsQ0FBN0I7QUFLQSxJQUFNQyxZQUFZLEdBQUdGLG1EQUFJLENBQUM7QUFDL0JDLEtBQUcsRUFBRSxjQUQwQjtBQUUvQixhQUFTLENBQUMsV0FBRCxFQUFjLFlBQWQsRUFBNEIsV0FBNUIsRUFBeUMsV0FBekM7QUFGc0IsQ0FBRCxDQUF6QjtBQUtBLElBQU1FLFFBQVEsR0FBR0gsbURBQUksQ0FBQztBQUMzQkMsS0FBRyxFQUFFLFVBRHNCO0FBRTNCLGFBQVM7QUFGa0IsQ0FBRCxDQUFyQjtBQUtBLElBQU1HLFdBQVcsR0FBR0osbURBQUksQ0FBQztBQUM5QkMsS0FBRyxFQUFFLGFBRHlCO0FBRTlCLGFBQVM7QUFGcUIsQ0FBRCxDQUF4QjtBQUtBLElBQU1JLElBQUksR0FBR0wsbURBQUksQ0FBQztBQUN2QkMsS0FBRyxFQUFFLE1BRGtCO0FBRXZCLGFBQVM7QUFGYyxDQUFELENBQWpCO0FBS0EsSUFBTUssVUFBVSxHQUFHTixtREFBSSxDQUFDO0FBQzdCQyxLQUFHLEVBQUUsWUFEd0I7QUFFN0IsYUFBUztBQUZvQixDQUFELENBQXZCO0FBS0EsSUFBTU0sU0FBUyxHQUFHUCxtREFBSSxDQUFDO0FBQzVCQyxLQUFHLEVBQUUsV0FEdUI7QUFFNUIsYUFBUztBQUZtQixDQUFELENBQXRCO0FBS0EsSUFBTU8sWUFBWSxHQUFHUixtREFBSSxDQUFDO0FBQy9CQyxLQUFHLEVBQUUsY0FEMEI7QUFFL0IsYUFBUztBQUZzQixDQUFELENBQXpCO0FBS0EsSUFBTVEsV0FBVyxHQUFHVCxtREFBSSxDQUFDO0FBQzlCQyxLQUFHLEVBQUUsYUFEeUI7QUFFOUIsYUFBUztBQUZxQixDQUFELENBQXhCO0FBS0EsSUFBTVMsU0FBUyxHQUFHVixtREFBSSxDQUFDO0FBQzVCQyxLQUFHLEVBQUUsV0FEdUI7QUFFNUIsYUFBUztBQUZtQixDQUFELENBQXRCLEMsQ0FLUDs7QUFDTyxJQUFNVSxTQUFTLEdBQUdDLHVEQUFRLENBQUM7QUFDaENYLEtBQUcsRUFBRSxXQUQyQjtBQUVoQ1ksS0FBRztBQUFBLGlNQUFFO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBU0Esa0JBQVQsUUFBU0EsR0FBVDtBQUNHQyxzQkFESCxHQUNjRCxJQUFHLENBQUNkLGdCQUFELENBRGpCO0FBRUdnQixrQkFGSCxHQUVVRixJQUFHLENBQUNWLFFBQUQsQ0FGYjtBQUdHYSxvQkFISCxHQUdZSCxJQUFHLENBQUNULFdBQUQsQ0FIZjtBQUlDYSxpQkFKRCwyQkFJd0JILFFBSnhCLG1CQUl5Q0MsSUFKekM7O0FBTUgsa0JBQUlDLE1BQU0sQ0FBQ0UsTUFBUCxHQUFnQixDQUFwQixFQUF1QjtBQUNyQkQsbUJBQUcsc0JBQWVELE1BQWYsQ0FBSDtBQUNEOztBQVJFO0FBQUEscUJBVVVHLHdEQUFPLENBQUNGLEdBQUQsQ0FWakI7O0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFGOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBRjZCLENBQUQsQ0FBMUI7QUFnQkEsSUFBTUcsV0FBVyxHQUFHUix1REFBUSxDQUFDO0FBQ2xDWCxLQUFHLEVBQUUsYUFENkI7QUFFbENvQixLQUFHLEVBQUUsMkJBQStCO0FBQUEsUUFBNUJSLEdBQTRCLFNBQTVCQSxHQUE0QjtBQUFBLFFBQXZCUSxJQUF1QixTQUF2QkEsR0FBdUI7QUFBQSxRQUFkQyxJQUFjLFNBQWRBLElBQWM7QUFBQSxRQUFSQyxDQUFRLFNBQVJBLENBQVE7O0FBQ2xDLFFBQU1DLFdBQVcscUJBQVFYLEdBQUcsQ0FBQ1IsSUFBRCxDQUFYLENBQWpCOztBQUVBLFFBQUlrQixDQUFDLEtBQUssQ0FBVixFQUFhO0FBQ1g7QUFDQUMsaUJBQVcsQ0FBQ0YsSUFBSSxDQUFDRyxFQUFOLENBQVgsbUNBQTRCSCxJQUE1QjtBQUFrQ0ksV0FBRyxFQUFFO0FBQXZDO0FBQ0QsS0FIRCxNQUdPLElBQUlILENBQUMsR0FBRyxDQUFKLElBQVNBLENBQUMsSUFBSUQsSUFBSSxDQUFDSyxLQUF2QixFQUE4QjtBQUNuQztBQUNBSCxpQkFBVyxDQUFDRixJQUFJLENBQUNHLEVBQU4sQ0FBWCxtQ0FBNEJILElBQTVCO0FBQWtDSSxXQUFHLEVBQUVIO0FBQXZDO0FBQ0QsS0FITSxNQUdBLElBQUlBLENBQUMsR0FBRyxDQUFSLEVBQVc7QUFDaEI7QUFDQSxhQUFPQyxXQUFXLENBQUNGLElBQUksQ0FBQ0csRUFBTixDQUFsQjtBQUNEOztBQUVELFFBQU1HLFdBQVcsR0FBR0MsTUFBTSxDQUFDQyxNQUFQLENBQWNOLFdBQWQsQ0FBcEI7QUFDQSxRQUFJTyxLQUFLLEdBQUcsQ0FBWjtBQUNBSCxlQUFXLENBQUNJLE9BQVosQ0FBb0IsVUFBQ1YsSUFBRCxFQUFVO0FBQzVCLFVBQU1XLFdBQVcsR0FBR1gsSUFBSSxDQUFDWSxVQUFMLElBQW1CWixJQUFJLENBQUNhLEtBQTVDO0FBQ0FKLFdBQUssSUFBSUUsV0FBVyxHQUFHWCxJQUFJLENBQUNJLEdBQTVCO0FBQ0QsS0FIRDs7QUFLQUwsUUFBRyxDQUFDaEIsSUFBRCxFQUFPbUIsV0FBUCxDQUFILENBckJrQyxDQXFCVjs7O0FBQ3hCSCxRQUFHLENBQUNmLFVBQUQsRUFBYXNCLFdBQVcsQ0FBQ1YsTUFBekIsQ0FBSCxDQXRCa0MsQ0FzQkc7OztBQUNyQ0csUUFBRyxDQUFDZCxTQUFELEVBQVl3QixLQUFaLENBQUgsQ0F2QmtDLENBdUJYOztBQUN4QjtBQTFCaUMsQ0FBRCxDQUE1QjtBQTZCQSxJQUFNSyxZQUFZLEdBQUd4Qix1REFBUSxDQUFDO0FBQ25DWCxLQUFHLEVBQUUsY0FEOEI7QUFFbkNZLEtBQUcsRUFBRSxvQkFBYTtBQUFBLFFBQVZBLEtBQVUsU0FBVkEsR0FBVTs7QUFDaEIsUUFBTXdCLFNBQVMsR0FBR3hCLEtBQUcsQ0FBQ1IsSUFBRCxDQUFyQjs7QUFDQSxRQUFNaUMsUUFBUSxHQUFHekIsS0FBRyxDQUFDTixTQUFELENBQXBCOztBQUNBLFFBQU1nQyxRQUFRLEdBQUcxQixLQUFHLENBQUNMLFlBQUQsQ0FBcEI7O0FBQ0EsUUFBTWdDLFlBQVksR0FBRzNCLEtBQUcsQ0FBQ0osV0FBRCxDQUF4Qjs7QUFDQSxRQUFNZ0MsUUFBUSxHQUFHNUIsS0FBRyxDQUFDSCxTQUFELENBQXBCOztBQUVBLFFBQU1xQixLQUFLLEdBQUdRLFFBQVEsR0FBR0QsUUFBUSxHQUFHRSxZQUFkLEdBQTZCRixRQUFuRDtBQUVBLFdBQU87QUFDTEQsZUFBUyxFQUFUQSxTQURLO0FBRUxDLGNBQVEsRUFBRUEsUUFBUSxDQUFDSSxPQUFULENBQWlCLENBQWpCLENBRkw7QUFHTGxDLGtCQUFZLEVBQUUrQixRQUhUO0FBSUxDLGtCQUFZLEVBQUVBLFlBQVksQ0FBQ0UsT0FBYixDQUFxQixDQUFyQixDQUpUO0FBS0xYLFdBQUssRUFBRUEsS0FBSyxDQUFDVyxPQUFOLENBQWMsQ0FBZCxDQUxGO0FBTUxELGNBQVEsRUFBUkE7QUFOSyxLQUFQO0FBUUQ7QUFuQmtDLENBQUQsQ0FBN0I7QUFzQkEsSUFBTUUsVUFBVSxHQUFHL0IsdURBQVEsQ0FBQztBQUNqQ1gsS0FBRyxFQUFFLFlBRDRCO0FBRWpDb0IsS0FBRyxFQUFFLG9CQUFrQjtBQUFBLFFBQWZSLEdBQWUsU0FBZkEsR0FBZTtBQUFBLFFBQVZRLEtBQVUsU0FBVkEsR0FBVTs7QUFDckJBLFNBQUcsQ0FBQ3RCLGdCQUFELEVBQW1CLEtBQW5CLENBQUg7O0FBQ0FzQixTQUFHLENBQUNsQixRQUFELEVBQVcsV0FBWCxDQUFIOztBQUNBa0IsU0FBRyxDQUFDYixZQUFELEVBQWUsSUFBZixDQUFIOztBQUNBYSxTQUFHLENBQUNoQixJQUFELEVBQU8sRUFBUCxDQUFIOztBQUNBZ0IsU0FBRyxDQUFDZixVQUFELEVBQWEsQ0FBYixDQUFIOztBQUNBZSxTQUFHLENBQUNkLFNBQUQsRUFBWSxDQUFaLENBQUg7O0FBQ0FjLFNBQUcsQ0FBQ1gsU0FBRCxFQUFZLEVBQVosQ0FBSDtBQUNEO0FBVmdDLENBQUQsQ0FBM0IiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguZDc2YjExMWRjYWFkYzEyYTgyZjcuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGF0b20sIHNlbGVjdG9yIH0gZnJvbSBcInJlY29pbFwiO1xyXG5pbXBvcnQgeyBmZXRjaGVyIH0gZnJvbSBcIi4uL2hlbHBlcnNcIjtcclxuXHJcbi8vQVRPTVNcclxuZXhwb3J0IGNvbnN0IHNlbGVjdGVkQ2F0ZWdvcnkgPSBhdG9tKHtcclxuICBrZXk6IFwic2VsZWN0ZWRDYXRlZ29yeVwiLFxyXG4gIGRlZmF1bHQ6IFwiYWxsXCIsXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IG9yZGVyT3B0aW9ucyA9IGF0b20oe1xyXG4gIGtleTogXCJvcmRlck9wdGlvbnNcIixcclxuICBkZWZhdWx0OiBbXCJBc2NlbmRpbmdcIiwgXCJEZXNjZW5kaW5nXCIsIFwiTWluIFByaWNlXCIsIFwiTWF4IFByaWNlXCJdLFxyXG59KTtcclxuXHJcbmV4cG9ydCBjb25zdCBzb3J0TW9kZSA9IGF0b20oe1xyXG4gIGtleTogXCJzb3J0TW9kZVwiLFxyXG4gIGRlZmF1bHQ6IFwiQXNjZW5kaW5nXCIsXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IHNlYXJjaFZhbHVlID0gYXRvbSh7XHJcbiAga2V5OiBcInNlYXJjaFZhbHVlXCIsXHJcbiAgZGVmYXVsdDogXCJcIixcclxufSk7XHJcblxyXG5leHBvcnQgY29uc3QgY2FydCA9IGF0b20oe1xyXG4gIGtleTogXCJjYXJ0XCIsXHJcbiAgZGVmYXVsdDoge30sXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IGNhcnRMZW5ndGggPSBhdG9tKHtcclxuICBrZXk6IFwiY2FydExlbmd0aFwiLFxyXG4gIGRlZmF1bHQ6IDAsXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IGNhcnRUb3RhbCA9IGF0b20oe1xyXG4gIGtleTogXCJjYXJ0VG90YWxcIixcclxuICBkZWZhdWx0OiAwLFxyXG59KTtcclxuXHJcbmV4cG9ydCBjb25zdCB3aXRoRGVsaXZlcnkgPSBhdG9tKHtcclxuICBrZXk6IFwid2l0aERlbGl2ZXJ5XCIsXHJcbiAgZGVmYXVsdDogZmFsc2UsXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IGRlbGl2ZXJ5RmVlID0gYXRvbSh7XHJcbiAga2V5OiBcImRlbGl2ZXJ5RmVlXCIsXHJcbiAgZGVmYXVsdDogNSxcclxufSk7XHJcblxyXG5leHBvcnQgY29uc3QgZm9ybVN0YXRlID0gYXRvbSh7XHJcbiAga2V5OiBcImZvcm1TdGF0ZVwiLFxyXG4gIGRlZmF1bHQ6IHt9LFxyXG59KTtcclxuXHJcbi8vU0VMRUNUT1JTXHJcbmV4cG9ydCBjb25zdCBpdGVtc0xpc3QgPSBzZWxlY3Rvcih7XHJcbiAga2V5OiBcIml0ZW1zTGlzdFwiLFxyXG4gIGdldDogYXN5bmMgKHsgZ2V0IH0pID0+IHtcclxuICAgIGNvbnN0IGNhdGVnb3J5ID0gZ2V0KHNlbGVjdGVkQ2F0ZWdvcnkpO1xyXG4gICAgY29uc3Qgc29ydCA9IGdldChzb3J0TW9kZSk7XHJcbiAgICBjb25zdCBzZWFyY2ggPSBnZXQoc2VhcmNoVmFsdWUpO1xyXG4gICAgbGV0IHVybCA9IGAvYXBpP2NhdGVnb3J5PSR7Y2F0ZWdvcnl9JnNvcnQ9JHtzb3J0fWA7XHJcblxyXG4gICAgaWYgKHNlYXJjaC5sZW5ndGggPiAwKSB7XHJcbiAgICAgIHVybCArPSBgJnNlYXJjaD0ke3NlYXJjaH1gO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBhd2FpdCBmZXRjaGVyKHVybCk7XHJcbiAgfSxcclxufSk7XHJcblxyXG5leHBvcnQgY29uc3QgcmVmcmVzaENhcnQgPSBzZWxlY3Rvcih7XHJcbiAga2V5OiBcInJlZnJlc2hDYXJ0XCIsXHJcbiAgc2V0OiAoeyBnZXQsIHNldCB9LCB7IGl0ZW0sIG4gfSkgPT4ge1xyXG4gICAgY29uc3QgY3VycmVudENhcnQgPSB7IC4uLmdldChjYXJ0KSB9O1xyXG5cclxuICAgIGlmIChuID09PSAxKSB7XHJcbiAgICAgIC8vIGFkZCBpdGVtIHRvIGNhcnRcclxuICAgICAgY3VycmVudENhcnRbaXRlbS5pZF0gPSB7IC4uLml0ZW0sIHF0eTogMSB9O1xyXG4gICAgfSBlbHNlIGlmIChuID4gMCAmJiBuIDw9IGl0ZW0uc3RvY2spIHtcclxuICAgICAgLy8gcmVmcmVzaCBpdGVtIGluIGNhcnRcclxuICAgICAgY3VycmVudENhcnRbaXRlbS5pZF0gPSB7IC4uLml0ZW0sIHF0eTogbiB9O1xyXG4gICAgfSBlbHNlIGlmIChuIDwgMSkge1xyXG4gICAgICAvLyByZW1vdmUgaXRlbSB0byBjYXJ0XHJcbiAgICAgIGRlbGV0ZSBjdXJyZW50Q2FydFtpdGVtLmlkXTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBjYXJ0VG9BcnJheSA9IE9iamVjdC52YWx1ZXMoY3VycmVudENhcnQpO1xyXG4gICAgbGV0IHRvdGFsID0gMDtcclxuICAgIGNhcnRUb0FycmF5LmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgY29uc3QgYWN0dWFsUHJpY2UgPSBpdGVtLm9mZmVyUHJpY2UgfHwgaXRlbS5wcmljZTtcclxuICAgICAgdG90YWwgKz0gYWN0dWFsUHJpY2UgKiBpdGVtLnF0eTtcclxuICAgIH0pO1xyXG5cclxuICAgIHNldChjYXJ0LCBjdXJyZW50Q2FydCk7IC8vc2V0IGNhcnQgc3RhdGVcclxuICAgIHNldChjYXJ0TGVuZ3RoLCBjYXJ0VG9BcnJheS5sZW5ndGgpOyAvL3NldCBjYXJ0IGxlbmdodFxyXG4gICAgc2V0KGNhcnRUb3RhbCwgdG90YWwpOyAvL3NldCBjYXJ0IHRvdGFsXHJcbiAgfSxcclxufSk7XHJcblxyXG5leHBvcnQgY29uc3Qgb3JkZXJEZXRhaWxzID0gc2VsZWN0b3Ioe1xyXG4gIGtleTogXCJvcmRlckRldGFpbHNcIixcclxuICBnZXQ6ICh7IGdldCB9KSA9PiB7XHJcbiAgICBjb25zdCBjYXJ0SXRlbXMgPSBnZXQoY2FydCk7XHJcbiAgICBjb25zdCBzdWJUb3RhbCA9IGdldChjYXJ0VG90YWwpO1xyXG4gICAgY29uc3QgZGVsaXZlcnkgPSBnZXQod2l0aERlbGl2ZXJ5KTtcclxuICAgIGNvbnN0IHNoaXBwaW5nQ29zdCA9IGdldChkZWxpdmVyeUZlZSk7XHJcbiAgICBjb25zdCBmb3JtRGF0YSA9IGdldChmb3JtU3RhdGUpO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsID0gZGVsaXZlcnkgPyBzdWJUb3RhbCArIHNoaXBwaW5nQ29zdCA6IHN1YlRvdGFsO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIGNhcnRJdGVtcyxcclxuICAgICAgc3ViVG90YWw6IHN1YlRvdGFsLnRvRml4ZWQoMiksXHJcbiAgICAgIHdpdGhEZWxpdmVyeTogZGVsaXZlcnksXHJcbiAgICAgIHNoaXBwaW5nQ29zdDogc2hpcHBpbmdDb3N0LnRvRml4ZWQoMiksXHJcbiAgICAgIHRvdGFsOiB0b3RhbC50b0ZpeGVkKDIpLFxyXG4gICAgICBmb3JtRGF0YSxcclxuICAgIH07XHJcbiAgfSxcclxufSk7XHJcblxyXG5leHBvcnQgY29uc3QgcmVzZXRTdGF0ZSA9IHNlbGVjdG9yKHtcclxuICBrZXk6IFwicmVzZXRTdGF0ZVwiLFxyXG4gIHNldDogKHsgZ2V0LCBzZXQgfSkgPT4ge1xyXG4gICAgc2V0KHNlbGVjdGVkQ2F0ZWdvcnksIFwiYWxsXCIpO1xyXG4gICAgc2V0KHNvcnRNb2RlLCBcIkFzY2VuZGluZ1wiKTtcclxuICAgIHNldCh3aXRoRGVsaXZlcnksIHRydWUpO1xyXG4gICAgc2V0KGNhcnQsIHt9KTtcclxuICAgIHNldChjYXJ0TGVuZ3RoLCAwKTtcclxuICAgIHNldChjYXJ0VG90YWwsIDApO1xyXG4gICAgc2V0KGZvcm1TdGF0ZSwge30pO1xyXG4gIH0sXHJcbn0pO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9
webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/commons/Sidebar.jsx":
/*!********************************************!*\
  !*** ./src/components/commons/Sidebar.jsx ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Sidebar; });
/* harmony import */ var _babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @chakra-ui/core */ "./node_modules/@chakra-ui/core/dist/es/index.js");
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons/bi */ "./node_modules/react-icons/bi/index.esm.js");
/* harmony import */ var _others_CustomRadio__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../others/CustomRadio */ "./src/components/others/CustomRadio.jsx");
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/recoil.js");
/* harmony import */ var _recoil_state__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../recoil/state */ "./src/recoil/state.js");
/* harmony import */ var _hooks_useIsDesktop__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../hooks/useIsDesktop */ "./src/hooks/useIsDesktop.js");


var _jsxFileName = "E:\\nodesjs\\next-grocery-store\\src\\components\\commons\\Sidebar.jsx",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;







function Sidebar(_ref) {
  _s();

  var showSidebar = _ref.showSidebar,
      setSidebar = _ref.setSidebar;

  var _useRecoilState = Object(recoil__WEBPACK_IMPORTED_MODULE_5__["useRecoilState"])(_recoil_state__WEBPACK_IMPORTED_MODULE_6__["selectedCategory"]),
      _useRecoilState2 = Object(_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useRecoilState, 2),
      category = _useRecoilState2[0],
      setCategory = _useRecoilState2[1];

  var isDesktop = Object(_hooks_useIsDesktop__WEBPACK_IMPORTED_MODULE_7__["default"])(); //close sidebar on select when is mobile

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    if (!isDesktop) {
      setSidebar(false);
    }
  }, [category]);
  return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    w: ["100%", "100%", "280px"],
    h: "calc(100vh - 100px)",
    bg: "white",
    position: "fixed",
    transform: !showSidebar ? ["translateX(-100%)", "translateX(-100%)", "translateX(-280px)"] : "translateX(0)",
    transition: "transform .3s ease",
    left: "0",
    top: "100px",
    py: "5",
    zIndex: "1100",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 5
    }
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["RadioButtonGroup"], {
    defaultValue: "all",
    value: category,
    onChange: function onChange(val) {
      return setCategory(val);
    },
    isInline: true,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }
  }, __jsx(_others_CustomRadio__WEBPACK_IMPORTED_MODULE_4__["default"], {
    value: "all",
    title: "Todos los productos",
    icon: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiMinus"],
      size: "24px",
      mr: "10",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 68
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 9
    }
  }), __jsx(_others_CustomRadio__WEBPACK_IMPORTED_MODULE_4__["default"], {
    value: "fruits",
    title: "Frutas",
    icon: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiMinus"],
      size: "24px",
      mr: "10",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 58
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 9
    }
  }), __jsx(_others_CustomRadio__WEBPACK_IMPORTED_MODULE_4__["default"], {
    value: "vegetable",
    title: "Vegetales",
    icon: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiMinus"],
      size: "24px",
      mr: "10",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 64
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 9
    }
  }), __jsx(_others_CustomRadio__WEBPACK_IMPORTED_MODULE_4__["default"], {
    value: "meat",
    title: "Carnes",
    icon: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiMinus"],
      size: "24px",
      mr: "10",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 56
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37,
      columnNumber: 9
    }
  }), __jsx(_others_CustomRadio__WEBPACK_IMPORTED_MODULE_4__["default"], {
    value: "bakery",
    title: "Bakery",
    icon: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiMinus"],
      size: "24px",
      mr: "10",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 58
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 9
    }
  }), __jsx(_others_CustomRadio__WEBPACK_IMPORTED_MODULE_4__["default"], {
    value: "drink",
    title: "Drinks",
    icon: __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
      as: react_icons_bi__WEBPACK_IMPORTED_MODULE_3__["BiMinus"],
      size: "24px",
      mr: "10",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 57
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 9
    }
  })));
}

_s(Sidebar, "RBRUYHPI16XM+a5OtuX2oprfe/k=", false, function () {
  return [recoil__WEBPACK_IMPORTED_MODULE_5__["useRecoilState"], _hooks_useIsDesktop__WEBPACK_IMPORTED_MODULE_7__["default"]];
});

_c = Sidebar;

var _c;

$RefreshReg$(_c, "Sidebar");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvY29tbW9ucy9TaWRlYmFyLmpzeCJdLCJuYW1lcyI6WyJTaWRlYmFyIiwic2hvd1NpZGViYXIiLCJzZXRTaWRlYmFyIiwidXNlUmVjb2lsU3RhdGUiLCJzZWxlY3RlZENhdGVnb3J5IiwiY2F0ZWdvcnkiLCJzZXRDYXRlZ29yeSIsImlzRGVza3RvcCIsInVzZUlzRGVza3RvcCIsInVzZUVmZmVjdCIsInZhbCIsIkJpTWludXMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVlLFNBQVNBLE9BQVQsT0FBOEM7QUFBQTs7QUFBQSxNQUEzQkMsV0FBMkIsUUFBM0JBLFdBQTJCO0FBQUEsTUFBZEMsVUFBYyxRQUFkQSxVQUFjOztBQUFBLHdCQUMzQkMsNkRBQWMsQ0FBQ0MsOERBQUQsQ0FEYTtBQUFBO0FBQUEsTUFDcERDLFFBRG9EO0FBQUEsTUFDMUNDLFdBRDBDOztBQUUzRCxNQUFNQyxTQUFTLEdBQUdDLG1FQUFZLEVBQTlCLENBRjJELENBSTNEOztBQUNBQyx5REFBUyxDQUFDLFlBQU07QUFDZCxRQUFJLENBQUNGLFNBQUwsRUFBZ0I7QUFDZEwsZ0JBQVUsQ0FBQyxLQUFELENBQVY7QUFDRDtBQUNGLEdBSlEsRUFJTixDQUFDRyxRQUFELENBSk0sQ0FBVDtBQU1BLFNBQ0UsTUFBQyxtREFBRDtBQUNFLEtBQUMsRUFBRSxDQUFDLE1BQUQsRUFBUyxNQUFULEVBQWlCLE9BQWpCLENBREw7QUFFRSxLQUFDLEVBQUMscUJBRko7QUFHRSxNQUFFLEVBQUMsT0FITDtBQUlFLFlBQVEsRUFBQyxPQUpYO0FBS0UsYUFBUyxFQUFFLENBQUNKLFdBQUQsR0FBZSxDQUFDLG1CQUFELEVBQXNCLG1CQUF0QixFQUEyQyxvQkFBM0MsQ0FBZixHQUFrRixlQUwvRjtBQU1FLGNBQVUsRUFBQyxvQkFOYjtBQU9FLFFBQUksRUFBQyxHQVBQO0FBUUUsT0FBRyxFQUFDLE9BUk47QUFTRSxNQUFFLEVBQUMsR0FUTDtBQVVFLFVBQU0sRUFBQyxNQVZUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FZRSxNQUFDLGdFQUFEO0FBQWtCLGdCQUFZLEVBQUMsS0FBL0I7QUFBcUMsU0FBSyxFQUFFSSxRQUE1QztBQUFzRCxZQUFRLEVBQUUsa0JBQUNLLEdBQUQ7QUFBQSxhQUFTSixXQUFXLENBQUNJLEdBQUQsQ0FBcEI7QUFBQSxLQUFoRTtBQUEyRixZQUFRLE1BQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLDJEQUFEO0FBQWEsU0FBSyxFQUFDLEtBQW5CO0FBQXlCLFNBQUssRUFBQyxxQkFBL0I7QUFBcUQsUUFBSSxFQUFFLE1BQUMsbURBQUQ7QUFBSyxRQUFFLEVBQUVDLHNEQUFUO0FBQWtCLFVBQUksRUFBQyxNQUF2QjtBQUE4QixRQUFFLEVBQUMsSUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBREYsRUFFRSxNQUFDLDJEQUFEO0FBQWEsU0FBSyxFQUFDLFFBQW5CO0FBQTRCLFNBQUssRUFBQyxRQUFsQztBQUEyQyxRQUFJLEVBQUUsTUFBQyxtREFBRDtBQUFLLFFBQUUsRUFBRUEsc0RBQVQ7QUFBa0IsVUFBSSxFQUFDLE1BQXZCO0FBQThCLFFBQUUsRUFBQyxJQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFGRixFQUdFLE1BQUMsMkRBQUQ7QUFBYSxTQUFLLEVBQUMsV0FBbkI7QUFBK0IsU0FBSyxFQUFDLFdBQXJDO0FBQWlELFFBQUksRUFBRSxNQUFDLG1EQUFEO0FBQUssUUFBRSxFQUFFQSxzREFBVDtBQUFrQixVQUFJLEVBQUMsTUFBdkI7QUFBOEIsUUFBRSxFQUFDLElBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUhGLEVBSUUsTUFBQywyREFBRDtBQUFhLFNBQUssRUFBQyxNQUFuQjtBQUEwQixTQUFLLEVBQUMsUUFBaEM7QUFBeUMsUUFBSSxFQUFFLE1BQUMsbURBQUQ7QUFBSyxRQUFFLEVBQUVBLHNEQUFUO0FBQWtCLFVBQUksRUFBQyxNQUF2QjtBQUE4QixRQUFFLEVBQUMsSUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSkYsRUFLRSxNQUFDLDJEQUFEO0FBQWEsU0FBSyxFQUFDLFFBQW5CO0FBQTRCLFNBQUssRUFBQyxRQUFsQztBQUEyQyxRQUFJLEVBQUUsTUFBQyxtREFBRDtBQUFLLFFBQUUsRUFBRUEsc0RBQVQ7QUFBa0IsVUFBSSxFQUFDLE1BQXZCO0FBQThCLFFBQUUsRUFBQyxJQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFMRixFQU1FLE1BQUMsMkRBQUQ7QUFBYSxTQUFLLEVBQUMsT0FBbkI7QUFBMkIsU0FBSyxFQUFDLFFBQWpDO0FBQTBDLFFBQUksRUFBRSxNQUFDLG1EQUFEO0FBQUssUUFBRSxFQUFFQSxzREFBVDtBQUFrQixVQUFJLEVBQUMsTUFBdkI7QUFBOEIsUUFBRSxFQUFDLElBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU5GLENBWkYsQ0FERjtBQXVCRDs7R0FsQ3VCWCxPO1VBQ1VHLHFELEVBQ2RLLDJEOzs7S0FGSVIsTyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC5lNGQ5OTdhMDY2MzUzZDA3MDI2ZS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQm94LCBSYWRpb0J1dHRvbkdyb3VwIH0gZnJvbSBcIkBjaGFrcmEtdWkvY29yZVwiO1xyXG5pbXBvcnQgeyBCaU1pbnVzIH0gZnJvbSBcInJlYWN0LWljb25zL2JpXCI7XHJcbmltcG9ydCBDdXN0b21SYWRpbyBmcm9tIFwiLi4vb3RoZXJzL0N1c3RvbVJhZGlvXCI7XHJcbmltcG9ydCB7IHVzZVJlY29pbFN0YXRlIH0gZnJvbSBcInJlY29pbFwiO1xyXG5pbXBvcnQgeyBzZWxlY3RlZENhdGVnb3J5IH0gZnJvbSBcIi4uLy4uL3JlY29pbC9zdGF0ZVwiO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHVzZUlzRGVza3RvcCBmcm9tIFwiLi4vLi4vaG9va3MvdXNlSXNEZXNrdG9wXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTaWRlYmFyKHsgc2hvd1NpZGViYXIsIHNldFNpZGViYXIgfSkge1xyXG4gIGNvbnN0IFtjYXRlZ29yeSwgc2V0Q2F0ZWdvcnldID0gdXNlUmVjb2lsU3RhdGUoc2VsZWN0ZWRDYXRlZ29yeSk7XHJcbiAgY29uc3QgaXNEZXNrdG9wID0gdXNlSXNEZXNrdG9wKCk7XHJcblxyXG4gIC8vY2xvc2Ugc2lkZWJhciBvbiBzZWxlY3Qgd2hlbiBpcyBtb2JpbGVcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFpc0Rlc2t0b3ApIHtcclxuICAgICAgc2V0U2lkZWJhcihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfSwgW2NhdGVnb3J5XSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Qm94XHJcbiAgICAgIHc9e1tcIjEwMCVcIiwgXCIxMDAlXCIsIFwiMjgwcHhcIl19XHJcbiAgICAgIGg9XCJjYWxjKDEwMHZoIC0gMTAwcHgpXCJcclxuICAgICAgYmc9XCJ3aGl0ZVwiXHJcbiAgICAgIHBvc2l0aW9uPVwiZml4ZWRcIlxyXG4gICAgICB0cmFuc2Zvcm09eyFzaG93U2lkZWJhciA/IFtcInRyYW5zbGF0ZVgoLTEwMCUpXCIsIFwidHJhbnNsYXRlWCgtMTAwJSlcIiwgXCJ0cmFuc2xhdGVYKC0yODBweClcIl0gOiBcInRyYW5zbGF0ZVgoMClcIn1cclxuICAgICAgdHJhbnNpdGlvbj1cInRyYW5zZm9ybSAuM3MgZWFzZVwiXHJcbiAgICAgIGxlZnQ9XCIwXCJcclxuICAgICAgdG9wPVwiMTAwcHhcIlxyXG4gICAgICBweT1cIjVcIlxyXG4gICAgICB6SW5kZXg9XCIxMTAwXCJcclxuICAgID5cclxuICAgICAgPFJhZGlvQnV0dG9uR3JvdXAgZGVmYXVsdFZhbHVlPVwiYWxsXCIgdmFsdWU9e2NhdGVnb3J5fSBvbkNoYW5nZT17KHZhbCkgPT4gc2V0Q2F0ZWdvcnkodmFsKX0gaXNJbmxpbmU+XHJcbiAgICAgICAgPEN1c3RvbVJhZGlvIHZhbHVlPVwiYWxsXCIgdGl0bGU9XCJUb2RvcyBsb3MgcHJvZHVjdG9zXCIgaWNvbj17PEJveCBhcz17QmlNaW51c30gc2l6ZT1cIjI0cHhcIiBtcj1cIjEwXCIgLz59IC8+XHJcbiAgICAgICAgPEN1c3RvbVJhZGlvIHZhbHVlPVwiZnJ1aXRzXCIgdGl0bGU9XCJGcnV0YXNcIiBpY29uPXs8Qm94IGFzPXtCaU1pbnVzfSBzaXplPVwiMjRweFwiIG1yPVwiMTBcIiAvPn0gLz5cclxuICAgICAgICA8Q3VzdG9tUmFkaW8gdmFsdWU9XCJ2ZWdldGFibGVcIiB0aXRsZT1cIlZlZ2V0YWxlc1wiIGljb249ezxCb3ggYXM9e0JpTWludXN9IHNpemU9XCIyNHB4XCIgbXI9XCIxMFwiIC8+fSAvPlxyXG4gICAgICAgIDxDdXN0b21SYWRpbyB2YWx1ZT1cIm1lYXRcIiB0aXRsZT1cIkNhcm5lc1wiIGljb249ezxCb3ggYXM9e0JpTWludXN9IHNpemU9XCIyNHB4XCIgbXI9XCIxMFwiIC8+fSAvPlxyXG4gICAgICAgIDxDdXN0b21SYWRpbyB2YWx1ZT1cImJha2VyeVwiIHRpdGxlPVwiQmFrZXJ5XCIgaWNvbj17PEJveCBhcz17QmlNaW51c30gc2l6ZT1cIjI0cHhcIiBtcj1cIjEwXCIgLz59IC8+XHJcbiAgICAgICAgPEN1c3RvbVJhZGlvIHZhbHVlPVwiZHJpbmtcIiB0aXRsZT1cIkRyaW5rc1wiIGljb249ezxCb3ggYXM9e0JpTWludXN9IHNpemU9XCIyNHB4XCIgbXI9XCIxMFwiIC8+fSAvPlxyXG4gICAgICA8L1JhZGlvQnV0dG9uR3JvdXA+XHJcbiAgICA8L0JveD5cclxuICApO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=